﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

public class JSONObject
{
    public enum Type
    {
        NULL,
        STRING,
        NUMBER,
        OBJECT,
        ARRAY,
        BOOL,
        BAKED
    }

    public delegate void AddJSONContents(JSONObject self);

    public delegate void FieldNotFound(string name);

    public delegate void GetFieldResponse(JSONObject obj);

    private const int MAX_DEPTH = 100;

    private const string INFINITY = "\"INFINITY\"";

    private const string NEGINFINITY = "\"NEGINFINITY\"";

    private const string NaN = "\"NaN\"";

    public static readonly char[] WHITESPACE = new char[]
    {
        ' ',
        '\r',
        '\n',
        '\t',
        '﻿',
        '\t'
    };

    public JSONObject.Type type;

    public List<JSONObject> list;

    public List<string> keys;

    public string str;

    public float n;

    public bool useInt;

    public long i;

    public bool b;

    private const float maxFrameTime = 0.008f;

    private static readonly Stopwatch printWatch = new Stopwatch();

    public bool isContainer
    {
        get
        {
            return this.type == JSONObject.Type.ARRAY || this.type == JSONObject.Type.OBJECT;
        }
    }

    public int Count
    {
        get
        {
            if (this.list == null)
            {
                return -1;
            }
            return this.list.Count;
        }
    }

    public float f
    {
        get
        {
            return this.n;
        }
    }

    public static JSONObject nullJO
    {
        get
        {
            return JSONObject.Create(JSONObject.Type.NULL);
        }
    }

    public static JSONObject obj
    {
        get
        {
            return JSONObject.Create(JSONObject.Type.OBJECT);
        }
    }

    public static JSONObject arr
    {
        get
        {
            return JSONObject.Create(JSONObject.Type.ARRAY);
        }
    }

    public bool IsNumber
    {
        get
        {
            return this.type == JSONObject.Type.NUMBER;
        }
    }

    public bool IsNull
    {
        get
        {
            return this.type == JSONObject.Type.NULL;
        }
    }

    public bool IsString
    {
        get
        {
            return this.type == JSONObject.Type.STRING;
        }
    }

    public bool IsBool
    {
        get
        {
            return this.type == JSONObject.Type.BOOL;
        }
    }

    public bool IsArray
    {
        get
        {
            return this.type == JSONObject.Type.ARRAY;
        }
    }

    public bool IsObject
    {
        get
        {
            return this.type == JSONObject.Type.OBJECT || this.type == JSONObject.Type.BAKED;
        }
    }

    public JSONObject this[int index]
    {
        get
        {
            if (this.list.Count > index)
            {
                return this.list[index];
            }
            return null;
        }
        set
        {
            if (this.list.Count > index)
            {
                this.list[index] = value;
            }
        }
    }

    public JSONObject this[string index]
    {
        get
        {
            return this.GetField(index);
        }
        set
        {
            this.SetField(index, value);
        }
    }

    public JSONObject(JSONObject.Type t)
    {
        this.type = t;
        if (t != JSONObject.Type.OBJECT)
        {
            if (t == JSONObject.Type.ARRAY)
            {
                this.list = new List<JSONObject>();
                return;
            }
        }
        else
        {
            this.list = new List<JSONObject>();
            this.keys = new List<string>();
        }
    }

    public JSONObject(bool b)
    {
        this.type = JSONObject.Type.BOOL;
        this.b = b;
    }

    public JSONObject(float f)
    {
        this.type = JSONObject.Type.NUMBER;
        this.n = f;
    }

    public JSONObject(int i)
    {
        this.type = JSONObject.Type.NUMBER;
        this.i = (long)i;
        this.useInt = true;
        this.n = (float)i;
    }

    public JSONObject(long l)
    {
        this.type = JSONObject.Type.NUMBER;
        this.i = l;
        this.useInt = true;
        this.n = (float)l;
    }

    public JSONObject(Dictionary<string, string> dic)
    {
        this.type = JSONObject.Type.OBJECT;
        this.keys = new List<string>();
        this.list = new List<JSONObject>();
        foreach (KeyValuePair<string, string> current in dic)
        {
            this.keys.Add(current.Key);
            this.list.Add(JSONObject.CreateStringObject(current.Value));
        }
    }

    public JSONObject(Dictionary<string, JSONObject> dic)
    {
        this.type = JSONObject.Type.OBJECT;
        this.keys = new List<string>();
        this.list = new List<JSONObject>();
        foreach (KeyValuePair<string, JSONObject> current in dic)
        {
            this.keys.Add(current.Key);
            this.list.Add(current.Value);
        }
    }

    public JSONObject(JSONObject.AddJSONContents content)
    {
        content(this);
    }

    public JSONObject(JSONObject[] objs)
    {
        this.type = JSONObject.Type.ARRAY;
        this.list = new List<JSONObject>(objs);
    }

    public static JSONObject StringObject(string val)
    {
        return JSONObject.CreateStringObject(val);
    }

    public void Absorb(JSONObject obj)
    {
        this.list.AddRange(obj.list);
        this.keys.AddRange(obj.keys);
        this.str = obj.str;
        this.n = obj.n;
        this.useInt = obj.useInt;
        this.i = obj.i;
        this.b = obj.b;
        this.type = obj.type;
    }

    public static JSONObject Create()
    {
        return new JSONObject();
    }

    public static JSONObject Create(JSONObject.Type t)
    {
        JSONObject jSONObject = JSONObject.Create();
        jSONObject.type = t;
        if (t != JSONObject.Type.OBJECT)
        {
            if (t == JSONObject.Type.ARRAY)
            {
                jSONObject.list = new List<JSONObject>();
            }
        }
        else
        {
            jSONObject.list = new List<JSONObject>();
            jSONObject.keys = new List<string>();
        }
        return jSONObject;
    }

    public static JSONObject Create(bool val)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.type = JSONObject.Type.BOOL;
        expr_05.b = val;
        return expr_05;
    }

    public static JSONObject Create(float val)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.type = JSONObject.Type.NUMBER;
        expr_05.n = val;
        return expr_05;
    }

    public static JSONObject Create(int val)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.type = JSONObject.Type.NUMBER;
        expr_05.n = (float)val;
        expr_05.useInt = true;
        expr_05.i = (long)val;
        return expr_05;
    }

    public static JSONObject Create(long val)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.type = JSONObject.Type.NUMBER;
        expr_05.n = (float)val;
        expr_05.useInt = true;
        expr_05.i = val;
        return expr_05;
    }

    public static JSONObject CreateStringObject(string val)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.type = JSONObject.Type.STRING;
        expr_05.str = val;
        return expr_05;
    }

    public static JSONObject CreateBakedObject(string val)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.type = JSONObject.Type.BAKED;
        expr_05.str = val;
        return expr_05;
    }

    public static JSONObject Create(string val, int maxDepth = -2, bool storeExcessLevels = false, bool strict = false)
    {
        JSONObject expr_05 = JSONObject.Create();
        expr_05.Parse(val, maxDepth, storeExcessLevels, strict);
        return expr_05;
    }

    public static JSONObject Create(JSONObject.AddJSONContents content)
    {
        JSONObject jSONObject = JSONObject.Create();
        content(jSONObject);
        return jSONObject;
    }

    public static JSONObject Create(Dictionary<string, string> dic)
    {
        JSONObject jSONObject = JSONObject.Create();
        jSONObject.type = JSONObject.Type.OBJECT;
        jSONObject.keys = new List<string>();
        jSONObject.list = new List<JSONObject>();
        foreach (KeyValuePair<string, string> current in dic)
        {
            jSONObject.keys.Add(current.Key);
            jSONObject.list.Add(JSONObject.CreateStringObject(current.Value));
        }
        return jSONObject;
    }

    public JSONObject()
    {
    }

    public JSONObject(string str, int maxDepth = -2, bool storeExcessLevels = false, bool strict = false)
    {
        this.Parse(str, maxDepth, storeExcessLevels, strict);
    }

    private void Parse(string str, int maxDepth = -2, bool storeExcessLevels = false, bool strict = false)
    {
        if (string.IsNullOrEmpty(str))
        {
            this.type = JSONObject.Type.NULL;
            return;
        }
        str = str.Trim(JSONObject.WHITESPACE);
        if (strict && str[0] != '[' && str[0] != '{')
        {
            this.type = JSONObject.Type.NULL;
            return;
        }
        if (str.Length <= 0)
        {
            this.type = JSONObject.Type.NULL;
            return;
        }
        if (string.Compare(str, "true", true) == 0)
        {
            this.type = JSONObject.Type.BOOL;
            this.b = true;
            return;
        }
        if (string.Compare(str, "false", true) == 0)
        {
            this.type = JSONObject.Type.BOOL;
            this.b = false;
            return;
        }
        if (string.Compare(str, "null", true) == 0)
        {
            this.type = JSONObject.Type.NULL;
            return;
        }
        if (str == "\"INFINITY\"")
        {
            this.type = JSONObject.Type.NUMBER;
            this.n = float.PositiveInfinity;
            return;
        }
        if (str == "\"NEGINFINITY\"")
        {
            this.type = JSONObject.Type.NUMBER;
            this.n = float.NegativeInfinity;
            return;
        }
        if (str == "\"NaN\"")
        {
            this.type = JSONObject.Type.NUMBER;
            this.n = float.NaN;
            return;
        }
        if (str[0] == '"')
        {
            this.type = JSONObject.Type.STRING;
            this.str = str.Substring(1, str.Length - 2);
            return;
        }
        int num = 1;
        int num2 = 0;
        char c = str[num2];
        if (c != '[')
        {
            if (c != '{')
            {
                try
                {
                    this.n = Convert.ToSingle(str);
                    if (!str.Contains("."))
                    {
                        this.i = Convert.ToInt64(str);
                        this.useInt = true;
                    }
                    this.type = JSONObject.Type.NUMBER;
                }
                catch (FormatException)
                {
                    this.type = JSONObject.Type.NULL;
                }
                return;
            }
            this.type = JSONObject.Type.OBJECT;
            this.keys = new List<string>();
            this.list = new List<JSONObject>();
        }
        else
        {
            this.type = JSONObject.Type.ARRAY;
            this.list = new List<JSONObject>();
        }
        string item = "";
        bool flag = false;
        bool flag2 = false;
        int num3 = 0;
        while (++num2 < str.Length)
        {
            if (Array.IndexOf<char>(JSONObject.WHITESPACE, str[num2]) <= -1)
            {
                if (str[num2] == '\\')
                {
                    num2++;
                }
                else
                {
                    if (str[num2] == '"')
                    {
                        if (flag)
                        {
                            if (!flag2 && num3 == 0 && this.type == JSONObject.Type.OBJECT)
                            {
                                item = str.Substring(num + 1, num2 - num - 1);
                            }
                            flag = false;
                        }
                        else
                        {
                            if (num3 == 0 && this.type == JSONObject.Type.OBJECT)
                            {
                                num = num2;
                            }
                            flag = true;
                        }
                    }
                    if (!flag)
                    {
                        if (this.type == JSONObject.Type.OBJECT && num3 == 0 && str[num2] == ':')
                        {
                            num = num2 + 1;
                            flag2 = true;
                        }
                        if (str[num2] == '[' || str[num2] == '{')
                        {
                            num3++;
                        }
                        else if (str[num2] == ']' || str[num2] == '}')
                        {
                            num3--;
                        }
                        if ((str[num2] == ',' && num3 == 0) || num3 < 0)
                        {
                            flag2 = false;
                            string text = str.Substring(num, num2 - num).Trim(JSONObject.WHITESPACE);
                            if (text.Length > 0)
                            {
                                if (this.type == JSONObject.Type.OBJECT)
                                {
                                    this.keys.Add(item);
                                }
                                if (maxDepth != -1)
                                {
                                    this.list.Add(JSONObject.Create(text, (maxDepth < -1) ? -2 : (maxDepth - 1), false, false));
                                }
                                else if (storeExcessLevels)
                                {
                                    this.list.Add(JSONObject.CreateBakedObject(text));
                                }
                            }
                            num = num2 + 1;
                        }
                    }
                }
            }
        }
    }

    public void Add(bool val)
    {
        this.Add(JSONObject.Create(val));
    }

    public void Add(float val)
    {
        this.Add(JSONObject.Create(val));
    }

    public void Add(int val)
    {
        this.Add(JSONObject.Create(val));
    }

    public void Add(string str)
    {
        this.Add(JSONObject.CreateStringObject(str));
    }

    public void Add(JSONObject.AddJSONContents content)
    {
        this.Add(JSONObject.Create(content));
    }

    public void Add(JSONObject obj)
    {
        if (obj)
        {
            if (this.type != JSONObject.Type.ARRAY)
            {
                this.type = JSONObject.Type.ARRAY;
                if (this.list == null)
                {
                    this.list = new List<JSONObject>();
                }
            }
            this.list.Add(obj);
        }
    }

    public void AddField(string name, bool val)
    {
        this.AddField(name, JSONObject.Create(val));
    }

    public void AddField(string name, float val)
    {
        this.AddField(name, JSONObject.Create(val));
    }

    public void AddField(string name, int val)
    {
        this.AddField(name, JSONObject.Create(val));
    }

    public void AddField(string name, long val)
    {
        this.AddField(name, JSONObject.Create(val));
    }

    public void AddField(string name, JSONObject.AddJSONContents content)
    {
        this.AddField(name, JSONObject.Create(content));
    }

    public void AddField(string name, string val)
    {
        this.AddField(name, JSONObject.CreateStringObject(val));
    }

    public void AddField(string name, JSONObject obj)
    {
        if (obj)
        {
            if (this.type != JSONObject.Type.OBJECT)
            {
                if (this.keys == null)
                {
                    this.keys = new List<string>();
                }
                if (this.type == JSONObject.Type.ARRAY)
                {
                    for (int i = 0; i < this.list.Count; i++)
                    {
                        this.keys.Add(string.Concat(i));
                    }
                }
                else if (this.list == null)
                {
                    this.list = new List<JSONObject>();
                }
                this.type = JSONObject.Type.OBJECT;
            }
            this.keys.Add(name);
            this.list.Add(obj);
        }
    }

    public void SetField(string name, string val)
    {
        this.SetField(name, JSONObject.CreateStringObject(val));
    }

    public void SetField(string name, bool val)
    {
        this.SetField(name, JSONObject.Create(val));
    }

    public void SetField(string name, float val)
    {
        this.SetField(name, JSONObject.Create(val));
    }

    public void SetField(string name, int val)
    {
        this.SetField(name, JSONObject.Create(val));
    }

    public void SetField(string name, JSONObject obj)
    {
        if (this.HasField(name))
        {
            this.list.Remove(this[name]);
            this.keys.Remove(name);
        }
        this.AddField(name, obj);
    }

    public void RemoveField(string name)
    {
        if (this.keys.IndexOf(name) > -1)
        {
            this.list.RemoveAt(this.keys.IndexOf(name));
            this.keys.Remove(name);
        }
    }

    public bool GetField(out bool field, string name, bool fallback)
    {
        field = fallback;
        return this.GetField(ref field, name, null);
    }

    public bool GetField(ref bool field, string name, JSONObject.FieldNotFound fail = null)
    {
        if (this.type == JSONObject.Type.OBJECT)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                field = this.list[num].b;
                return true;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
        return false;
    }

    public bool GetField(out float field, string name, float fallback)
    {
        field = fallback;
        return this.GetField(ref field, name, null);
    }

    public bool GetField(ref float field, string name, JSONObject.FieldNotFound fail = null)
    {
        if (this.type == JSONObject.Type.OBJECT)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                field = this.list[num].n;
                return true;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
        return false;
    }

    public bool GetField(out int field, string name, int fallback)
    {
        field = fallback;
        return this.GetField(ref field, name, null);
    }

    public bool GetField(ref int field, string name, JSONObject.FieldNotFound fail = null)
    {
        if (this.IsObject)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                field = (int)this.list[num].n;
                return true;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
        return false;
    }

    public bool GetField(out long field, string name, long fallback)
    {
        field = fallback;
        return this.GetField(ref field, name, null);
    }

    public bool GetField(ref long field, string name, JSONObject.FieldNotFound fail = null)
    {
        if (this.IsObject)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                field = (long)this.list[num].n;
                return true;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
        return false;
    }

    public bool GetField(out uint field, string name, uint fallback)
    {
        field = fallback;
        return this.GetField(ref field, name, null);
    }

    public bool GetField(ref uint field, string name, JSONObject.FieldNotFound fail = null)
    {
        if (this.IsObject)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                field = (uint)this.list[num].n;
                return true;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
        return false;
    }

    public bool GetField(out string field, string name, string fallback)
    {
        field = fallback;
        return this.GetField(ref field, name, null);
    }

    public bool GetField(ref string field, string name, JSONObject.FieldNotFound fail = null)
    {
        if (this.IsObject)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                field = this.list[num].str;
                return true;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
        return false;
    }

    public void GetField(string name, JSONObject.GetFieldResponse response, JSONObject.FieldNotFound fail = null)
    {
        if (response != null && this.IsObject)
        {
            int num = this.keys.IndexOf(name);
            if (num >= 0)
            {
                response(this.list[num]);
                return;
            }
        }
        if (fail != null)
        {
            fail(name);
        }
    }

    public JSONObject GetField(string name)
    {
        if (this.IsObject)
        {
            for (int i = 0; i < this.keys.Count; i++)
            {
                if (this.keys[i] == name)
                {
                    return this.list[i];
                }
            }
        }
        return null;
    }

    public bool HasFields(string[] names)
    {
        if (!this.IsObject)
        {
            return false;
        }
        for (int i = 0; i < names.Length; i++)
        {
            if (!this.keys.Contains(names[i]))
            {
                return false;
            }
        }
        return true;
    }

    public bool HasField(string name)
    {
        if (!this.IsObject)
        {
            return false;
        }
        for (int i = 0; i < this.keys.Count; i++)
        {
            if (this.keys[i] == name)
            {
                return true;
            }
        }
        return false;
    }

    public void Clear()
    {
        this.type = JSONObject.Type.NULL;
        if (this.list != null)
        {
            this.list.Clear();
        }
        if (this.keys != null)
        {
            this.keys.Clear();
        }
        this.str = "";
        this.n = 0f;
        this.b = false;
    }

    public JSONObject Copy()
    {
        return JSONObject.Create(this.Print(true), -2, false, false);
    }

    public void Merge(JSONObject obj)
    {
    }

    public void Bake()
    {
        if (this.type != JSONObject.Type.BAKED)
        {
            this.str = this.Print(true);
            this.type = JSONObject.Type.BAKED;
        }
    }

    public IEnumerable BakeAsync()
    {
        yield break;
    }

    public string Print(bool pretty = true)
    {
        StringBuilder stringBuilder = new StringBuilder();
        this.Stringify(0, stringBuilder, pretty);
        return stringBuilder.ToString();
    }

    public IEnumerable<string> PrintAsync(bool pretty = false)
    {
        yield break;
    }

    private IEnumerable StringifyAsync(int depth, StringBuilder builder, bool pretty = false)
    {
        //JSONObject.< StringifyAsync > d__111 expr_07 = new JSONObject.< StringifyAsync > d__111(-2);
        //expr_07.<> 4__this = this;
        //expr_07.<> 3__depth = depth;
        //expr_07.<> 3__builder = builder;
        //expr_07.<> 3__pretty = pretty;
        //return expr_07;
        return "";

    }

    private void Stringify(int depth, StringBuilder builder, bool pretty = true)
    {
    }

    public override string ToString()
    {
        return this.Print(true);
    }

    public string ToString(bool pretty)
    {
        return this.Print(pretty);
    }

    public Dictionary<string, string> ToDictionary()
    {
        if (this.type == JSONObject.Type.OBJECT)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            for (int i = 0; i < this.list.Count; i++)
            {
                JSONObject jSONObject = this.list[i];
                switch (jSONObject.type)
                {
                    case JSONObject.Type.STRING:
                        dictionary.Add(this.keys[i], jSONObject.str);
                        break;
                    case JSONObject.Type.NUMBER:
                        dictionary.Add(this.keys[i], string.Concat(jSONObject.n));
                        break;
                    case JSONObject.Type.BOOL:
                        dictionary.Add(this.keys[i], jSONObject.b.ToString() ?? "");
                        break;
                }
            }
            return dictionary;
        }
        return null;
    }

    public static implicit operator bool (JSONObject o)
    {
        return o != null;
    }
}
