using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using Util;

namespace LayaExport
{
    public class DataManager
    {
        public enum ComponentType
        {
            Transform,
            Camera,
            DirectionalLight,
            MeshFilter,
            MeshRenderer,
            SkinnedMeshRenderer,
            Animation,
            Animator,
            ParticleSystem,
            Terrain,
            BoxCollider,
            SphereCollider,
            Rigidbody,
            TrailRenderer
        }

        public struct FrameData
        {
            public Vector3 localPosition;

            public Quaternion localRotation;

            public Vector3 localScale;
        }

        public struct VertexData
        {
            public int index;

            public Vector3 vertice;

            public Vector3 normal;

            public Color color;

            public Vector2 uv;

            public Vector2 uv2;

            public Vector4 boneWeight;

            public Vector4 boneIndex;

            public Vector4 tangent;
        }

        public struct TerrainVertexData
        {
            public Vector3 vertice;

            public Vector3 normal;

            public Vector2 uv;
        }

        public struct AniNodeFrameData
        {
            public ushort startTimeIndex;

            public List<float> inTangentNumbers;

            public List<float> outTangentNumbers;

            public List<float> valueNumbers;
        }

        public struct AniNodeData
        {
            public ushort pathLength;

            public List<ushort> pathIndex;

            public short conpomentTypeIndex;

            public ushort propertyNameIndex;

            public byte frameDataLengthIndex;

            public ushort keyFrameCount;

            public List<DataManager.AniNodeFrameData> aniNodeFrameDatas;
        }

        public struct CustomAnimationCurve
        {
            public Keyframe[] keys;
        }

        public struct CustomAnimationClipCurveData
        {
            public DataManager.CustomAnimationCurve curve;

            public string path;

            public string propertyName;

            public Type type;
        }

        private static List<Dictionary<GameObject, string>> layaAutoGameObjectsList = new List<Dictionary<GameObject, string>>();

        private static int LayaAutoGOListIndex = 0;

        public static GameObject pathFindGameObject;

        public static string VERSION = "1.7.16 beta";

        public static bool LayaAuto = false;

        public static int Type;

        public static bool IgnoreTangent;

        public static bool IgnoreColor;

        public static bool ConvertNonPNGAndJPG;

        public static bool ConvertOriginPNG;

        public static bool ConvertOriginJPG;

        public static bool ConvertLightMap;

        public static bool ConvertToPNG;

        public static bool ConvertToJPG;

        public static float ConvertQuality;

        public static bool SimplifyBone;

        public static bool ConvertTerrainToMesh;

        public static int TerrainToMeshResolution;

        public static bool IgnoreNullGameObject;

        public static bool IgnoreNotActiveGameObject;

        public static bool OptimizeGameObject;

        public static bool BatchMade;

        public static bool CoverOriginalFile;

        public static bool CustomizeDirectory;

        public static string CustomizeDirectoryName;

        public static string SAVEPATH;

        public static bool OptimizeMeshName;

        public static float ScaleFactor;

        private static bool curNodeHasLegalChild;

        private static bool curNodeHasNotLegalChild;

        private static bool curNodeHasLocalParticleChild;

        private static int MaxBoneCount = 24;

        private static float precision = 0.01f;

        private static int[] VertexStructure = new int[7];

        private static string sceneName;

        private static List<string> ConvertOriginalTextureTypeList;

        private static int directionalLightTotalCount = 1;

        private static int directionalLightCurCount = 0;

        public static void saveLayaAutoData()
        {
            DataManager.layaAutoGameObjectsList.Clear();
            if (DataManager.BatchMade && DataManager.Type == 1)
            {
                using (Dictionary<string, JSONObject>.Enumerator enumerator = DataManager.getLayaAutoSpriteNode().GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        KeyValuePair<string, JSONObject> current = enumerator.Current;
                        string text = DataManager.SAVEPATH + "/" + DataManager.cleanIllegalChar(current.Key, true) + ".lh";
                        if (!File.Exists(text) || DataManager.CoverOriginalFile)
                        {
                            FileUtil.saveFile(text, current.Value);
                        }
                    }
                    goto IL_ED;
                }
            }
            string text2 = "";
            if (DataManager.Type == 0)
            {
                text2 = DataManager.SAVEPATH + "/" + DataManager.sceneName + ".ls";
            }
            else if (DataManager.Type == 1)
            {
                text2 = DataManager.SAVEPATH + "/" + DataManager.sceneName + ".lh";
            }
            if (File.Exists(text2) && !DataManager.CoverOriginalFile)
            {
                return;
            }
            FileUtil.saveFile(text2, DataManager.getLayaAutoSceneNode());
        IL_ED:
            Debug.Log(" -- Exporting Data is Finished -- ");
        }

        public static JSONObject getLayaAutoSceneNode()
        {
            JSONObject sceneNode = DataManager.getSceneNode();
            JSONObject arg_1E_0 = sceneNode.GetField("customProps");
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            arg_1E_0.AddField("gameObjects", jSONObject);
            foreach (KeyValuePair<GameObject, string> current in DataManager.layaAutoGameObjectsList[0])
            {
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject2.AddField("name", current.Key.get_name());
                jSONObject2.AddField("renderSprite", current.Value);
                jSONObject.Add(jSONObject2);
            }
            return sceneNode;
        }

        public static Dictionary<string, JSONObject> getLayaAutoSpriteNode()
        {
            Dictionary<string, JSONObject> dictionary = new Dictionary<string, JSONObject>();
            Dictionary<string, JSONObject> arg_0D_0 = DataManager.saveSpriteNode();
            int num = 0;
            foreach (KeyValuePair<string, JSONObject> current in arg_0D_0)
            {
                JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject.AddField("renderTree", current.Value);
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject.AddField("gameObjects", jSONObject2);
                foreach (KeyValuePair<GameObject, string> current2 in DataManager.layaAutoGameObjectsList[num++])
                {
                    JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject3.AddField("name", current2.Key.get_name());
                    jSONObject3.AddField("renderSprite", current2.Value);
                    jSONObject2.Add(jSONObject3);
                }
                dictionary.Add(current.Key, jSONObject);
            }
            return dictionary;
        }

        public static bool IsLayaAutoGameObjects(GameObject gameObject)
        {
            return gameObject.get_tag() == "Laya3D" && !DataManager.layaAutoGameObjectsList[DataManager.LayaAutoGOListIndex].ContainsKey(gameObject);
        }

        public static bool IsCustomGameObject(GameObject gameObject)
        {
            bool result = false;
            if (gameObject.get_transform().get_parent() != null)
            {
                return result;
            }
            if (gameObject.get_name() == "pathFind")
            {
                DataManager.pathFindGameObject = gameObject;
                result = true;
            }
            return result;
        }

        public static void getData()
        {
            DataManager.sceneName = SceneManager.GetActiveScene().get_name();
            DataManager.sceneName = DataManager.cleanIllegalChar(DataManager.sceneName, true);
            if (DataManager.sceneName == "")
            {
                DataManager.sceneName = "layaScene";
            }
            string text;
            if (DataManager.CustomizeDirectory && DataManager.CustomizeDirectoryName != "")
            {
                DataManager.CustomizeDirectoryName = DataManager.cleanIllegalChar(DataManager.CustomizeDirectoryName, true);
                text = "/" + DataManager.CustomizeDirectoryName;
            }
            else
            {
                text = "/LayaScene_" + DataManager.sceneName;
            }
            DataManager.SAVEPATH += text;
            DataManager.ConvertOriginalTextureTypeList = new List<string>();
            if (DataManager.ConvertNonPNGAndJPG)
            {
                DataManager.ConvertOriginalTextureTypeList.Add(".tga");
                DataManager.ConvertOriginalTextureTypeList.Add(".TGA");
                DataManager.ConvertOriginalTextureTypeList.Add(".psd");
                DataManager.ConvertOriginalTextureTypeList.Add(".PSD");
                DataManager.ConvertOriginalTextureTypeList.Add(".gif");
                DataManager.ConvertOriginalTextureTypeList.Add(".GIF");
                DataManager.ConvertOriginalTextureTypeList.Add(".tif");
                DataManager.ConvertOriginalTextureTypeList.Add(".TIF");
                DataManager.ConvertOriginalTextureTypeList.Add(".bmp");
                DataManager.ConvertOriginalTextureTypeList.Add(".BMP");
                DataManager.ConvertOriginalTextureTypeList.Add(".exr");
                DataManager.ConvertOriginalTextureTypeList.Add(".EXR");
            }
            if (DataManager.ConvertOriginPNG)
            {
                DataManager.ConvertOriginalTextureTypeList.Add(".png");
                DataManager.ConvertOriginalTextureTypeList.Add(".PNG");
            }
            if (DataManager.ConvertOriginJPG)
            {
                DataManager.ConvertOriginalTextureTypeList.Add(".jpg");
                DataManager.ConvertOriginalTextureTypeList.Add(".JPG");
            }
            DataManager.directionalLightCurCount = 0;
            DataManager.recodeLayaJSFile(text + "/" + DataManager.sceneName);
            if (DataManager.LayaAuto)
            {
                DataManager.saveLayaAutoData();
                return;
            }
            DataManager.saveData();
        }

        public static void saveData()
        {
            if (DataManager.BatchMade && DataManager.Type == 1)
            {
                using (Dictionary<string, JSONObject>.Enumerator enumerator = DataManager.saveSpriteNode().GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        KeyValuePair<string, JSONObject> current = enumerator.Current;
                        string text = DataManager.SAVEPATH + "/" + DataManager.cleanIllegalChar(current.Key, true) + ".lh";
                        if (!File.Exists(text) || DataManager.CoverOriginalFile)
                        {
                            FileUtil.saveFile(text, current.Value);
                        }
                    }
                    goto IL_E3;
                }
            }
            string text2 = "";
            if (DataManager.Type == 0)
            {
                text2 = DataManager.SAVEPATH + "/" + DataManager.sceneName + ".ls";
            }
            else if (DataManager.Type == 1)
            {
                text2 = DataManager.SAVEPATH + "/" + DataManager.sceneName + ".lh";
            }
            if (File.Exists(text2) && !DataManager.CoverOriginalFile)
            {
                return;
            }
            FileUtil.saveFile(text2, DataManager.getSceneNode());
        IL_E3:
            Debug.Log(" -- Exporting Data is Finished -- ");
        }

        public static JSONObject getSceneNode()
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            if (DataManager.Type == 0)
            {
                jSONObject.AddField("type", "Scene");
            }
            else if (DataManager.Type == 1)
            {
                jSONObject.AddField("type", "Sprite3D");
            }
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject2.AddField("name", DataManager.sceneName);
            jSONObject.AddField("props", jSONObject2);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            if (DataManager.Type == 0)
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject3.AddField("skyBox", jSONObject4);
                Material skybox = RenderSettings.get_skybox();
                if (skybox != null)
                {
                    string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(skybox.GetInstanceID()).Split(new char[]
                    {
                        '.'
                    })[0], false) + ".lmat";
                    string text2 = DataManager.SAVEPATH + "/" + text;
                    if (skybox.get_shader().get_name() == "Skybox/6 Sided")
                    {
                        jSONObject4.AddField("ltcPath", text);
                        if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                        {
                            DataManager.saveLayaSkyBoxData(skybox, text2);
                        }
                    }
                }
                DataManager.saveLightMapFile(jSONObject3);
                Color ambientLight = RenderSettings.get_ambientLight();
                JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(ambientLight.r);
                jSONObject5.Add(ambientLight.g);
                jSONObject5.Add(ambientLight.b);
                jSONObject3.AddField("ambientColor", jSONObject5);
                jSONObject2.AddField("enableFog", RenderSettings.get_fog());
                JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                Color fogColor = RenderSettings.get_fogColor();
                jSONObject6.Add(fogColor.r);
                jSONObject6.Add(fogColor.g);
                jSONObject6.Add(fogColor.b);
                jSONObject3.AddField("fogColor", jSONObject6);
                jSONObject2.AddField("fogStart", RenderSettings.get_fogStartDistance());
                jSONObject2.AddField("fogRange", RenderSettings.get_fogEndDistance() - RenderSettings.get_fogStartDistance());
            }
            else if (DataManager.Type == 1)
            {
                Vector3 vector = new Vector3(0f, 0f, 0f);
                Quaternion quaternion = new Quaternion(0f, 0f, 0f, -1f);
                Vector3 vector2 = new Vector3(1f, 1f, 1f);
                JSONObject jSONObject7 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject7.Add(vector.x);
                jSONObject7.Add(vector.y);
                jSONObject7.Add(vector.z);
                jSONObject3.AddField("translate", jSONObject7);
                JSONObject jSONObject8 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject8.Add(quaternion.x);
                jSONObject8.Add(quaternion.y);
                jSONObject8.Add(quaternion.z);
                jSONObject8.Add(quaternion.w);
                jSONObject3.AddField("rotation", jSONObject8);
                JSONObject jSONObject9 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject9.Add(vector2.x);
                jSONObject9.Add(vector2.y);
                jSONObject9.Add(vector2.z);
                jSONObject3.AddField("scale", jSONObject9);
            }
            jSONObject.AddField("customProps", jSONObject3);
            GameObject[] rootGameObjects = SceneManager.GetActiveScene().GetRootGameObjects();
            if (rootGameObjects.Length != 0)
            {
                JSONObject jSONObject10 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject.AddField("child", jSONObject10);
                string gameObjectPath = DataManager.sceneName;
                Dictionary<GameObject, string> item = new Dictionary<GameObject, string>();
                DataManager.layaAutoGameObjectsList.Add(item);
                for (int i = 0; i < rootGameObjects.Length; i++)
                {
                    DataManager.getGameObjectData(rootGameObjects[i].get_gameObject(), gameObjectPath, jSONObject10, false);
                }
            }
            else
            {
                jSONObject.AddField("child", new JSONObject(JSONObject.Type.ARRAY));
            }
            return jSONObject;
        }

        public static Dictionary<string, JSONObject> saveSpriteNode()
        {
            GameObject[] rootGameObjects = SceneManager.GetActiveScene().GetRootGameObjects();
            Dictionary<string, JSONObject> dictionary = new Dictionary<string, JSONObject>();
            if (rootGameObjects.Length != 0)
            {
                for (int i = 0; i < rootGameObjects.Length; i++)
                {
                    DataManager.LayaAutoGOListIndex = i;
                    Dictionary<GameObject, string> item = new Dictionary<GameObject, string>();
                    DataManager.layaAutoGameObjectsList.Add(item);
                    List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(rootGameObjects[i]);
                    DataManager.checkChildIsLegal(rootGameObjects[i], true);
                    if ((rootGameObjects[i].get_activeInHierarchy() || !DataManager.IgnoreNotActiveGameObject) && ((!DataManager.OptimizeGameObject && !DataManager.IgnoreNullGameObject) || list.Count > 1 || DataManager.curNodeHasLegalChild))
                    {
                        JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject.AddField("type", "Sprite3D");
                        JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject2.AddField("name", SceneManager.GetActiveScene().get_name());
                        jSONObject.AddField("props", jSONObject2);
                        JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        Vector3 vector = new Vector3(0f, 0f, 0f);
                        Quaternion quaternion = new Quaternion(0f, 0f, 0f, -1f);
                        Vector3 vector2 = new Vector3(1f, 1f, 1f);
                        JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject4.Add(vector.x);
                        jSONObject4.Add(vector.y);
                        jSONObject4.Add(vector.z);
                        jSONObject3.AddField("translate", jSONObject4);
                        JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject5.Add(quaternion.x);
                        jSONObject5.Add(quaternion.y);
                        jSONObject5.Add(quaternion.z);
                        jSONObject5.Add(quaternion.w);
                        jSONObject3.AddField("rotation", jSONObject5);
                        JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject6.Add(vector2.x);
                        jSONObject6.Add(vector2.y);
                        jSONObject6.Add(vector2.z);
                        jSONObject3.AddField("scale", jSONObject6);
                        jSONObject.AddField("customProps", jSONObject3);
                        JSONObject jSONObject7 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject.AddField("child", jSONObject7);
                        string gameObjectPath = DataManager.sceneName;
                        DataManager.getGameObjectData(rootGameObjects[i].get_gameObject(), gameObjectPath, jSONObject7, false);
                        dictionary.Add(rootGameObjects[i].get_name(), jSONObject);
                    }
                }
            }
            return dictionary;
        }

        public static void getGameObjectData(GameObject gameObject, string gameObjectPath, JSONObject parentsChildNodes, bool ignoreNullChild = false)
        {
            List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject);
            DataManager.checkChildIsLegal(gameObject, true);
            if (!gameObject.get_activeInHierarchy() && DataManager.IgnoreNotActiveGameObject)
            {
                return;
            }
            if (DataManager.LayaAuto && DataManager.IsCustomGameObject(gameObject))
            {
                return;
            }
            if ((DataManager.OptimizeGameObject || DataManager.IgnoreNullGameObject) && list.Count <= 1 && !DataManager.curNodeHasLegalChild)
            {
                return;
            }
            if (list.Count <= 1 & ignoreNullChild)
            {
                return;
            }
            if (list.IndexOf(DataManager.ComponentType.DirectionalLight) != -1 && DataManager.directionalLightCurCount >= DataManager.directionalLightTotalCount)
            {
                return;
            }
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            Vector3 localPosition = gameObject.get_transform().get_localPosition();
            Quaternion localRotation = gameObject.get_transform().get_localRotation();
            Vector3 localScale = gameObject.get_transform().get_localScale();
            string gameObjectPath2 = gameObjectPath;
            DataManager.getComponentsData(gameObject, jSONObject, jSONObject2, localPosition, localRotation, localScale, ref gameObjectPath2);
            DataManager.checkChildHasLocalParticle(gameObject, true);
            if (gameObject.get_transform().get_childCount() > 0 && list.IndexOf(DataManager.ComponentType.Animation) == -1 && list.IndexOf(DataManager.ComponentType.Animator) == -1)
            {
                if (DataManager.OptimizeGameObject && DataManager.selectParentbyType(gameObject, DataManager.ComponentType.Animator) == null && DataManager.selectParentbyType(gameObject, DataManager.ComponentType.Animation) == null && !DataManager.curNodeHasLocalParticleChild)
                {
                    DataManager.getSimpleGameObjectData(gameObject, gameObjectPath2, jSONObject2);
                }
                else
                {
                    for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                    {
                        DataManager.getGameObjectData(gameObject.get_transform().GetChild(i).get_gameObject(), gameObjectPath2, jSONObject2, false);
                    }
                }
            }
            jSONObject.AddField("child", jSONObject2);
            parentsChildNodes.Add(jSONObject);
        }

        public static void getSimpleGameObjectData(GameObject gameObject, string gameObjectPath, JSONObject parentsChildNodes)
        {
            List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject);
            Transform[] componentsInChildren = gameObject.GetComponentsInChildren<Transform>();
            for (int i = 0; i < componentsInChildren.Length; i++)
            {
                JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                GameObject gameObject2 = componentsInChildren[i].get_gameObject();
                List<DataManager.ComponentType> list2 = DataManager.componentsOnGameObject(gameObject2);
                DataManager.checkChildIsLegal(gameObject2, true);
                if (i == componentsInChildren.Length - 1)
                {
                    new List<string>();
                }
                if (!(gameObject2 == gameObject) && (gameObject2.get_activeInHierarchy() || !DataManager.IgnoreNotActiveGameObject) && !(DataManager.selectParentbyType(gameObject2, DataManager.ComponentType.Animator) != null) && (list.IndexOf(DataManager.ComponentType.DirectionalLight) == -1 || DataManager.directionalLightCurCount < DataManager.directionalLightTotalCount) && (!DataManager.IgnoreNullGameObject || list2.Count > 1 || DataManager.curNodeHasLegalChild))
                {
                    Matrix4x4 matrix4x = gameObject.get_transform().get_worldToLocalMatrix() * gameObject2.get_transform().get_localToWorldMatrix();
                    Vector3 position = matrix4x.GetColumn(3);
                    Quaternion rotation = Quaternion.LookRotation(matrix4x.GetColumn(2), matrix4x.GetColumn(1));
                    Vector3 scale = new Vector3(matrix4x.GetColumn(0).get_magnitude(), matrix4x.GetColumn(1).get_magnitude(), matrix4x.GetColumn(2).get_magnitude());
                    MathUtil.Decompose(matrix4x.get_transpose(), out scale, out rotation, out position);
                    string text = gameObjectPath;
                    DataManager.getComponentsData(gameObject2, jSONObject, jSONObject2, position, rotation, scale, ref text);
                    jSONObject.AddField("child", jSONObject2);
                    parentsChildNodes.Add(jSONObject);
                }
            }
        }

        public static void getSkinAniGameObjectData(GameObject gameObject, string gameObjectPath, JSONObject parentsChildNodes, List<string> linkSprite = null)
        {
            DataManager.componentsOnGameObject(gameObject);
            Transform[] componentsInChildren = gameObject.GetComponentsInChildren<Transform>();
            for (int i = 0; i < componentsInChildren.Length; i++)
            {
                JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                GameObject gameObject2 = componentsInChildren[i].get_gameObject();
                List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject2);
                DataManager.checkChildIsLegal(gameObject2, true);
                if (!(gameObject2 == gameObject) && (list.Count <= 1 || !(gameObject2.get_transform().get_parent().get_gameObject() != gameObject)) && !(DataManager.selectParentbyType(gameObject2, DataManager.ComponentType.Animator) != gameObject) && (list.Count > 1 || DataManager.isHasLegalChild(gameObject2)))
                {
                    if (DataManager.isHasLegalChild(gameObject2))
                    {
                        for (int j = 0; j < gameObject2.get_transform().get_childCount(); j++)
                        {
                            DataManager.getGameObjectData(gameObject2.get_transform().GetChild(j).get_gameObject(), gameObjectPath, jSONObject2, true);
                            if (linkSprite != null && linkSprite.IndexOf(gameObject2.get_name()) == -1)
                            {
                                linkSprite.Add(gameObject2.get_name());
                            }
                        }
                    }
                    Matrix4x4 matrix4x = gameObject.get_transform().get_worldToLocalMatrix() * gameObject2.get_transform().get_localToWorldMatrix();
                    Vector3 position = matrix4x.GetColumn(3);
                    Quaternion rotation = Quaternion.LookRotation(matrix4x.GetColumn(2), matrix4x.GetColumn(1));
                    Vector3 scale = new Vector3(matrix4x.GetColumn(0).get_magnitude(), matrix4x.GetColumn(1).get_magnitude(), matrix4x.GetColumn(2).get_magnitude());
                    MathUtil.Decompose(matrix4x.get_transpose(), out scale, out rotation, out position);
                    string text = gameObjectPath;
                    DataManager.getComponentsData(gameObject2, jSONObject, jSONObject2, position, rotation, scale, ref text);
                    jSONObject.AddField("child", jSONObject2);
                    parentsChildNodes.Add(jSONObject);
                }
            }
        }

        public static void getComponentsData(GameObject gameObject, JSONObject node, JSONObject child, Vector3 position, Quaternion rotation, Vector3 scale, ref string goPath)
        {
            List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject);
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            node.AddField("type", "");
            if (list.IndexOf(DataManager.ComponentType.Transform) != -1)
            {
                node.SetField("type", "Sprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.BoxCollider) != -1)
            {
                node.SetField("type", "Sprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.SphereCollider) != -1)
            {
                node.SetField("type", "Sprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.Rigidbody) != -1)
            {
                node.SetField("type", "Sprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.Animation) != -1)
            {
                node.SetField("type", "Sprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.Animator) != -1)
            {
                node.SetField("type", "Sprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.DirectionalLight) != -1)
            {
                node.SetField("type", "DirectionLight");
            }
            if (list.IndexOf(DataManager.ComponentType.Camera) != -1)
            {
                node.SetField("type", "Camera");
            }
            if (list.IndexOf(DataManager.ComponentType.MeshFilter) != -1)
            {
                node.SetField("type", "MeshSprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.MeshRenderer) != -1)
            {
                node.SetField("type", "MeshSprite3D");
            }
            if (list.IndexOf(DataManager.ComponentType.SkinnedMeshRenderer) != -1)
            {
                if (DataManager.selectParentbyType(gameObject, DataManager.ComponentType.Animation) != null)
                {
                    node.SetField("type", "MeshSprite3D");
                }
                else
                {
                    node.SetField("type", "SkinnedMeshSprite3D");
                }
            }
            if (list.IndexOf(DataManager.ComponentType.ParticleSystem) != -1)
            {
                node.SetField("type", "ShuriKenParticle3D");
            }
            if (list.IndexOf(DataManager.ComponentType.Terrain) != -1)
            {
                if (DataManager.ConvertTerrainToMesh)
                {
                    node.SetField("type", "MeshSprite3D");
                }
                else
                {
                    node.SetField("type", "Terrain");
                }
            }
            if (list.IndexOf(DataManager.ComponentType.TrailRenderer) != -1)
            {
                node.SetField("type", "TrailSprite3D");
            }
            node.AddField("props", jSONObject);
            jSONObject.AddField("isStatic", gameObject.get_isStatic());
            jSONObject.AddField("name", gameObject.get_name());
            goPath = goPath + "/" + gameObject.get_name();
            node.AddField("customProps", jSONObject2);
            if (gameObject.get_layer() == 31)
            {
                Debug.LogWarning("LayaUnityPlugin : layer must less than 31 !");
            }
            else
            {
                jSONObject2.AddField("layer", gameObject.get_layer());
            }
            node.AddField("components", jSONObject3);
            if (DataManager.IsLayaAutoGameObjects(gameObject))
            {
                DataManager.layaAutoGameObjectsList[DataManager.LayaAutoGOListIndex].Add(gameObject, goPath);
            }
            if (list.IndexOf(DataManager.ComponentType.Transform) != -1)
            {
                DataManager.getTransformComponentData(gameObject, jSONObject2, position, rotation, scale);
            }
            if (list.IndexOf(DataManager.ComponentType.BoxCollider) != -1)
            {
                DataManager.getBoxColliderComponentData(gameObject, jSONObject3);
            }
            if (list.IndexOf(DataManager.ComponentType.SphereCollider) != -1)
            {
                DataManager.getSphereColliderComponentData(gameObject, jSONObject3);
            }
            if (list.IndexOf(DataManager.ComponentType.Rigidbody) != -1)
            {
                DataManager.getRigidbodyComponentData(gameObject, jSONObject3);
            }
            if (list.IndexOf(DataManager.ComponentType.Animation) != -1)
            {
                DataManager.saveLsaniData(gameObject);
                for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                {
                    DataManager.getGameObjectData(gameObject.get_transform().GetChild(i).get_gameObject(), goPath, child, false);
                }
            }
            if (list.IndexOf(DataManager.ComponentType.Animator) != -1)
            {
                Object arg_329_0 = gameObject.GetComponent<Animator>().get_avatar();
                List<string> linkSprite = new List<string>();
                if (arg_329_0 != null)
                {
                    DataManager.getSkinAniGameObjectData(gameObject, goPath, child, linkSprite);
                }
                else
                {
                    for (int j = 0; j < gameObject.get_transform().get_childCount(); j++)
                    {
                        DataManager.getGameObjectData(gameObject.get_transform().GetChild(j).get_gameObject(), goPath, child, false);
                    }
                }
                DataManager.getAnimatorComponentData(gameObject, jSONObject3, linkSprite);
            }
            if (list.IndexOf(DataManager.ComponentType.DirectionalLight) != -1)
            {
                DataManager.getDirectionalLightComponentData(gameObject, jSONObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.Camera) != -1)
            {
                DataManager.getCameraComponentData(gameObject, jSONObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.MeshFilter) != -1)
            {
                DataManager.getMeshFilterComponentData(gameObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.MeshRenderer) != -1)
            {
                DataManager.getMeshRendererComponentData(gameObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.SkinnedMeshRenderer) != -1)
            {
                DataManager.getSkinnedMeshRendererComponentData(gameObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.ParticleSystem) != -1)
            {
                DataManager.getParticleSystemComponentData(gameObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.Terrain) != -1)
            {
                DataManager.getTerrainComponentData(gameObject, jSONObject2);
            }
            if (list.IndexOf(DataManager.ComponentType.TrailRenderer) != -1)
            {
                DataManager.getTrailRendererComponentData(gameObject, jSONObject, jSONObject2);
            }
        }

        public static void getTransformComponentData(GameObject gameObject, JSONObject customProps, Vector3 position, Quaternion rotation, Vector3 scale)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("translate", jSONObject);
            customProps.AddField("rotation", jSONObject2);
            customProps.AddField("scale", jSONObject3);
            List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject);
            jSONObject.Add(position.x * -1f);
            jSONObject.Add(position.y);
            jSONObject.Add(position.z);
            if (list.IndexOf(DataManager.ComponentType.Terrain) == -1)
            {
                if (list.IndexOf(DataManager.ComponentType.Camera) != -1 || list.IndexOf(DataManager.ComponentType.DirectionalLight) != -1)
                {
                    rotation *= new Quaternion(0f, 1f, 0f, 0f);
                }
                jSONObject2.Add(rotation.x * -1f);
                jSONObject2.Add(rotation.y);
                jSONObject2.Add(rotation.z);
                jSONObject2.Add(rotation.w * -1f);
                jSONObject3.Add(scale.x);
                jSONObject3.Add(scale.y);
                jSONObject3.Add(scale.z);
                return;
            }
            jSONObject2.Add(0);
            jSONObject2.Add(0);
            jSONObject2.Add(0);
            jSONObject2.Add(-1);
            jSONObject3.Add(1);
            jSONObject3.Add(1);
            jSONObject3.Add(1);
        }

        public static void getCameraComponentData(GameObject gameObject, JSONObject props, JSONObject customProps)
        {
            Camera component = gameObject.GetComponent<Camera>();
            if (component.get_clearFlags() == 1)
            {
                props.AddField("clearFlag", 1);
            }
            else if (component.get_clearFlags() == 2 || component.get_clearFlags() == 2)
            {
                props.AddField("clearFlag", 0);
            }
            else if (component.get_clearFlags() == 3)
            {
                props.AddField("clearFlag", 2);
            }
            else
            {
                props.AddField("clearFlag", 3);
            }
            props.AddField("orthographic", component.get_orthographic());
            if (component.get_orthographic())
            {
                props.AddField("orthographicVerticalSize", component.get_orthographicSize() * 2f);
            }
            else
            {
                props.AddField("fieldOfView", component.get_fieldOfView());
            }
            props.AddField("nearPlane", component.get_nearClipPlane());
            props.AddField("farPlane", component.get_farClipPlane());
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            Rect rect = component.get_rect();
            jSONObject.Add(rect.get_x());
            jSONObject.Add(rect.get_y());
            jSONObject.Add(rect.get_width());
            jSONObject.Add(rect.get_height());
            customProps.AddField("viewport", jSONObject);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            Color backgroundColor = component.get_backgroundColor();
            jSONObject2.Add(backgroundColor.r);
            jSONObject2.Add(backgroundColor.g);
            jSONObject2.Add(backgroundColor.b);
            jSONObject2.Add(backgroundColor.a);
            customProps.AddField("clearColor", jSONObject2);
            Skybox[] components = gameObject.GetComponents<Skybox>();
            if (components.Length != 0)
            {
                JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("skyBox", jSONObject3);
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject3.AddField("sharedMaterial", jSONObject4);
                for (int i = 0; i < components.Length; i++)
                {
                    Skybox skybox = components[i];
                    if (skybox.get_enabled())
                    {
                        Material material = skybox.get_material();
                        if (material != null)
                        {
                            string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(material.GetInstanceID()).Split(new char[]
                            {
                                '.'
                            })[0], false) + ".lmat";
                            string text2 = DataManager.SAVEPATH + "/" + text;
                            if (material.get_shader().get_name() == "Skybox/6 Sided")
                            {
                                jSONObject4.AddField("type", "Laya.SkyBoxMaterial");
                                jSONObject4.AddField("path", text);
                                if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                                {
                                    DataManager.saveLayaSkyBoxData(material, text2);
                                    return;
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }

        public static void getDirectionalLightComponentData(GameObject gameObject, JSONObject props, JSONObject customProps)
        {
            Light component = gameObject.GetComponent<Light>();
            props.AddField("intensity", component.get_intensity());
            switch (component.get_lightmapBakeType())
            {
                case 1:
                    props.AddField("lightmapBakedType", 1);
                    goto IL_6F;
                case 2:
                    props.AddField("lightmapBakedType", 2);
                    goto IL_6F;
                case 4:
                    props.AddField("lightmapBakedType", 0);
                    goto IL_6F;
            }
            props.AddField("lightmapBakedType", 0);
        IL_6F:
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            Color color = component.get_color();
            jSONObject.Add(color.r);
            jSONObject.Add(color.g);
            jSONObject.Add(color.b);
            customProps.AddField("color", jSONObject);
            DataManager.directionalLightCurCount++;
        }

        public static void getMeshFilterComponentData(GameObject gameObject, JSONObject customProps)
        {
            Mesh sharedMesh = gameObject.GetComponent<MeshFilter>().get_sharedMesh();
            if (!(sharedMesh != null))
            {
                Debug.LogWarning("LayaUnityPlugin : " + gameObject.get_name() + "'s Mesh data can't be null!");
                return;
            }
            string str = DataManager.cleanIllegalChar(sharedMesh.get_name(), true);
            string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(sharedMesh.GetInstanceID()).Split(new char[]
            {
                '.'
            })[0], false) + "-" + str;
            if (!DataManager.OptimizeMeshName)
            {
                text = string.Concat(new object[]
                {
                    text,
                    "[",
                    sharedMesh.GetInstanceID(),
                    "].lm"
                });
            }
            else
            {
                text += ".lm";
            }
            string text2 = DataManager.SAVEPATH + "/" + text;
            customProps.AddField("meshPath", text);
            if (File.Exists(text2) && !DataManager.CoverOriginalFile)
            {
                return;
            }
            DataManager.saveLmFile(sharedMesh, text2);
        }

        public static void getMeshRendererComponentData(GameObject gameObject, JSONObject customProps)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            if (DataManager.Type == 0)
            {
                MeshRenderer component = gameObject.GetComponent<MeshRenderer>();
                if (component.get_lightmapIndex() > -1)
                {
                    customProps.AddField("lightmapIndex", component.get_lightmapIndex());
                    customProps.AddField("lightmapScaleOffset", jSONObject);
                    jSONObject.Add(component.get_lightmapScaleOffset().x);
                    jSONObject.Add(component.get_lightmapScaleOffset().y);
                    jSONObject.Add(component.get_lightmapScaleOffset().z);
                    jSONObject.Add(-component.get_lightmapScaleOffset().w);
                }
            }
            Material[] sharedMaterials = gameObject.GetComponent<MeshRenderer>().get_sharedMaterials();
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("materials", jSONObject2);
            for (int i = 0; i < sharedMaterials.Length; i++)
            {
                Material material = sharedMaterials[i];
                if (!(material == null))
                {
                    string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(material.GetInstanceID()).Split(new char[]
                    {
                        '.'
                    })[0], false) + ".lmat";
                    string text2 = DataManager.SAVEPATH + "/" + text;
                    string name = material.get_shader().get_name();
                    if (name.Split(new char[]
                    {
                        '/'
                    })[0] == "LayaAir3D")
                    {
                        JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        if (name.Split(new char[]
                        {
                            '/'
                        })[1] == "BlinnPhong")
                        {
                            jSONObject3.AddField("type", "Laya.BlinnPhongMaterial");
                        }
                        else if (name.Split(new char[]
                        {
                            '/'
                        })[1] == "PBR(Standard)")
                        {
                            jSONObject3.AddField("type", "Laya.PBRStandardMaterial");
                        }
                        else if (name.Split(new char[]
                        {
                            '/'
                        })[1] == "PBR(Specular)")
                        {
                            jSONObject3.AddField("type", "Laya.PBRSpecularMaterial");
                        }
                        jSONObject3.AddField("path", text);
                        jSONObject2.Add(jSONObject3);
                        if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                        {
                            DataManager.saveLayaLmatData(material, text2);
                        }
                    }
                    else
                    {
                        JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject4.AddField("type", "Laya.StandardMaterial");
                        jSONObject4.AddField("path", text);
                        jSONObject2.Add(jSONObject4);
                        if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                        {
                            DataManager.saveLmatFile(material, text2, DataManager.ComponentType.MeshRenderer);
                        }
                    }
                }
            }
        }

        public static void getSkinnedMeshRendererComponentData(GameObject gameObject, JSONObject customProps)
        {
            SkinnedMeshRenderer component = gameObject.GetComponent<SkinnedMeshRenderer>();
            if (DataManager.selectParentbyType(gameObject, DataManager.ComponentType.Animation) == null)
            {
                customProps.AddField("rootBone", component.get_rootBone() ? component.get_rootBone().get_name() : "");
                Bounds localBounds = component.get_localBounds();
                Vector3 center = localBounds.get_center();
                Vector3 vector = new Vector3(-center.x, center.y, center.z);
                Vector3 extents = localBounds.get_extents();
                Vector3 vector2 = vector - extents;
                Vector3 vector3 = vector + extents;
                float val = Vector3.Distance(vector2, vector3) / 2f;
                JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("boundBox", jSONObject);
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject2.Add(vector2.x);
                jSONObject2.Add(vector2.y);
                jSONObject2.Add(vector2.z);
                jSONObject.AddField("min", jSONObject2);
                JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject3.Add(vector3.x);
                jSONObject3.Add(vector3.y);
                jSONObject3.Add(vector3.z);
                jSONObject.AddField("max", jSONObject3);
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("boundSphere", jSONObject4);
                JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(vector.x);
                jSONObject5.Add(vector.y);
                jSONObject5.Add(vector.z);
                jSONObject4.AddField("center", jSONObject5);
                jSONObject4.AddField("radius", val);
            }
            Material[] sharedMaterials = component.get_sharedMaterials();
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("materials", jSONObject6);
            for (int i = 0; i < sharedMaterials.Length; i++)
            {
                Material material = sharedMaterials[i];
                if (!(material == null))
                {
                    string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(material.GetInstanceID()).Split(new char[]
                    {
                        '.'
                    })[0], false) + ".lmat";
                    string text2 = DataManager.SAVEPATH + "/" + text;
                    string name = material.get_shader().get_name();
                    if (name.Split(new char[]
                    {
                        '/'
                    })[0] == "LayaAir3D")
                    {
                        JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
                        if (name.Split(new char[]
                        {
                            '/'
                        })[1] == "BlinnPhong")
                        {
                            jSONObject7.AddField("type", "Laya.BlinnPhongMaterial");
                        }
                        else if (name.Split(new char[]
                        {
                            '/'
                        })[1] == "PBR(Standard)")
                        {
                            jSONObject7.AddField("type", "Laya.PBRStandardMaterial");
                        }
                        else if (name.Split(new char[]
                        {
                            '/'
                        })[1] == "PBR(Specular)")
                        {
                            jSONObject7.AddField("type", "Laya.PBRSpecularMaterial");
                        }
                        jSONObject7.AddField("path", text);
                        jSONObject6.Add(jSONObject7);
                        if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                        {
                            DataManager.saveLayaLmatData(material, text2);
                        }
                    }
                    else
                    {
                        JSONObject jSONObject8 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject8.AddField("type", "Laya.StandardMaterial");
                        jSONObject8.AddField("path", text);
                        jSONObject6.Add(jSONObject8);
                        if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                        {
                            DataManager.saveLmatFile(material, text2, DataManager.ComponentType.MeshRenderer);
                        }
                    }
                }
            }
            Mesh sharedMesh = component.get_sharedMesh();
            if (!(sharedMesh != null))
            {
                Debug.LogWarning("LayaUnityPlugin : " + gameObject.get_name() + "'s Mesh data can't be null!");
                return;
            }
            string str = DataManager.cleanIllegalChar(sharedMesh.get_name(), true);
            string text3 = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(sharedMesh.GetInstanceID()).Split(new char[]
            {
                '.'
            })[0], false) + "-" + str;
            if (!DataManager.OptimizeMeshName)
            {
                text3 = string.Concat(new object[]
                {
                    text3,
                    "[",
                    sharedMesh.GetInstanceID(),
                    "].lm"
                });
            }
            else
            {
                text3 += ".lm";
            }
            string text4 = DataManager.SAVEPATH + "/" + text3;
            customProps.AddField("meshPath", text3);
            if (File.Exists(text4) && !DataManager.CoverOriginalFile)
            {
                return;
            }
            DataManager.saveSkinLmFile(component, text4);
        }

        public static void getAnimatorComponentData(GameObject gameObject, JSONObject component, List<string> linkSprite)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject obj = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
            Avatar avatar = gameObject.GetComponent<Animator>().get_avatar();
            if (avatar != null)
            {
                string assetPath = AssetDatabase.GetAssetPath(avatar.GetInstanceID());
                string text = string.Concat(new string[]
                {
                    DataManager.cleanIllegalChar(assetPath.Split(new char[]
                    {
                        '.'
                    })[0], false),
                    "-",
                    DataManager.cleanIllegalChar(gameObject.get_name(), true),
                    "-",
                    avatar.get_name(),
                    ".lav"
                });
                string text2 = DataManager.SAVEPATH + "/" + text;
                if (File.Exists(text2) && !DataManager.CoverOriginalFile)
                {
                    return;
                }
                JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                DataManager.getLavData(gameObject, jSONObject5, gameObject);
                jSONObject4.AddField("version", "LAYAAVATAR:01");
                jSONObject4.AddField("rootNode", jSONObject5[0]);
                FileUtil.saveFile(text2, jSONObject4);
                jSONObject.AddField("avatar", jSONObject2);
                jSONObject2.AddField("path", text);
                jSONObject2.AddField("linkSprites", jSONObject3);
                for (int i = 0; i < linkSprite.Count; i++)
                {
                    JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                    jSONObject6.Add(linkSprite[i]);
                    jSONObject3.AddField(linkSprite[i], jSONObject6);
                }
            }
            DataManager.saveLaniData(gameObject, obj);
            jSONObject.AddField("clipPaths", obj);
            jSONObject.AddField("playOnWake", true);
            component.AddField("Animator", jSONObject);
        }

        public static void getParticleSystemComponentData(GameObject gameObject, JSONObject customProps)
        {
            ParticleSystem component = gameObject.GetComponent<ParticleSystem>();
            ParticleSystemRenderer component2 = gameObject.GetComponent<ParticleSystemRenderer>();
            int val = 0;
            customProps.AddField("isPerformanceMode", true);
            customProps.AddField("duration", component.get_main().get_duration());
            customProps.AddField("looping", component.get_main().get_loop());
            customProps.AddField("prewarm", false);
            if (component.get_main().get_startDelay().get_mode().ToString() == "Constant")
            {
                val = 0;
            }
            else if (component.get_main().get_startDelay().get_mode().ToString() == "TwoConstants")
            {
                val = 1;
            }
            customProps.AddField("startDelayType", val);
            customProps.AddField("startDelay", component.get_main().get_startDelay().get_constant());
            customProps.AddField("startDelayMin", component.get_main().get_startDelay().get_constantMin());
            customProps.AddField("startDelayMax", component.get_main().get_startDelay().get_constantMax());
            if (component.get_main().get_startLifetime().get_mode().ToString() == "Constant")
            {
                val = 0;
            }
            else if (component.get_main().get_startLifetime().get_mode().ToString() == "Curves")
            {
                val = 1;
            }
            else if (component.get_main().get_startLifetime().get_mode().ToString() == "TwoConstants")
            {
                val = 2;
            }
            else if (component.get_main().get_startLifetime().get_mode().ToString() == "MinMaxCurves")
            {
                val = 3;
            }
            customProps.AddField("startLifetimeType", val);
            customProps.AddField("startLifetimeConstant", component.get_main().get_startLifetime().get_constant());
            customProps.AddField("startLifetimeConstantMin", component.get_main().get_startLifetime().get_constantMin());
            customProps.AddField("startLifetimeConstantMax", component.get_main().get_startLifetime().get_constantMax());
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("startLifetimeGradient", jSONObject);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            if (component.get_main().get_startLifetime().get_curve() != null)
            {
                for (int i = 0; i < component.get_main().get_startLifetime().get_curve().get_length(); i++)
                {
                    jSONObject3.Clear();
                    jSONObject2.Add(jSONObject3);
                    jSONObject3.AddField("key", component.get_main().get_startLifetime().get_curve().get_Item(i).get_time());
                    jSONObject3.AddField("value", component.get_main().get_startLifetime().get_curve().get_Item(i).get_value());
                }
            }
            jSONObject.AddField("startLifetimes", jSONObject2);
            jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("startLifetimeGradientMin", jSONObject);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            if (component.get_main().get_startLifetime().get_curveMin() != null)
            {
                for (int i = 0; i < component.get_main().get_startLifetime().get_curveMin().get_length(); i++)
                {
                    jSONObject3.Clear();
                    jSONObject2.Add(jSONObject3);
                    jSONObject3.AddField("key", component.get_main().get_startLifetime().get_curveMin().get_Item(i).get_time());
                    jSONObject3.AddField("value", component.get_main().get_startLifetime().get_curveMin().get_Item(i).get_value());
                }
            }
            jSONObject.AddField("startLifetimes", jSONObject2);
            jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("startLifetimeGradientMax", jSONObject);
            if (component.get_main().get_startLifetime().get_curveMax() != null)
            {
                for (int i = 0; i < component.get_main().get_startLifetime().get_curveMax().get_length(); i++)
                {
                    jSONObject3.Clear();
                    jSONObject2.Add(jSONObject3);
                    jSONObject3.AddField("key", component.get_main().get_startLifetime().get_curveMax().get_Item(i).get_time());
                    jSONObject3.AddField("value", component.get_main().get_startLifetime().get_curveMax().get_Item(i).get_value());
                }
            }
            jSONObject.AddField("startLifetimes", jSONObject2);
            if (component.get_main().get_startSpeed().get_mode().ToString() == "Constant")
            {
                val = 0;
            }
            else if (component.get_main().get_startSpeed().get_mode().ToString() == "Curve")
            {
                val = 1;
            }
            else if (component.get_main().get_startSpeed().get_mode().ToString() == "TwoConstants")
            {
                val = 2;
            }
            else if (component.get_main().get_startSpeed().get_mode().ToString() == "TwoCurves")
            {
                val = 3;
            }
            customProps.AddField("startSpeedType", val);
            customProps.AddField("startSpeedConstant", component.get_main().get_startSpeed().get_constant());
            customProps.AddField("startSpeedConstantMin", component.get_main().get_startSpeed().get_constantMin());
            customProps.AddField("startSpeedConstantMax", component.get_main().get_startSpeed().get_constantMax());
            if (component.get_main().get_startSizeX().get_mode().ToString() == "Constant")
            {
                val = 0;
            }
            else if (component.get_main().get_startSizeX().get_mode().ToString() == "Curve")
            {
                val = 1;
            }
            else if (component.get_main().get_startSizeX().get_mode().ToString() == "TwoConstants")
            {
                val = 2;
            }
            else if (component.get_main().get_startSizeX().get_mode().ToString() == "TwoCurves")
            {
                val = 3;
            }
            customProps.AddField("threeDStartSize", component.get_main().get_startSize3D());
            customProps.AddField("startSizeType", val);
            customProps.AddField("startSizeConstant", component.get_main().get_startSize().get_constant());
            customProps.AddField("startSizeConstantMin", component.get_main().get_startSize().get_constantMin());
            customProps.AddField("startSizeConstantMax", component.get_main().get_startSize().get_constantMax());
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startSizeX().get_constant());
            jSONObject2.Add(component.get_main().get_startSizeY().get_constant());
            jSONObject2.Add(component.get_main().get_startSizeZ().get_constant());
            customProps.AddField("startSizeConstantSeparate", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startSizeX().get_constantMin());
            jSONObject2.Add(component.get_main().get_startSizeY().get_constantMin());
            jSONObject2.Add(component.get_main().get_startSizeZ().get_constantMin());
            customProps.AddField("startSizeConstantMinSeparate", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startSizeX().get_constantMax());
            jSONObject2.Add(component.get_main().get_startSizeY().get_constantMax());
            jSONObject2.Add(component.get_main().get_startSizeZ().get_constantMax());
            customProps.AddField("startSizeConstantMaxSeparate", jSONObject2);
            customProps.AddField("threeDStartRotation", component.get_main().get_startRotation3D());
            if (component.get_main().get_startRotationX().get_mode().ToString() == "Constant")
            {
                val = 0;
            }
            else if (component.get_main().get_startRotationX().get_mode().ToString() == "Curve")
            {
                val = 1;
            }
            else if (component.get_main().get_startRotationX().get_mode().ToString() == "TwoConstants")
            {
                val = 2;
            }
            else if (component.get_main().get_startRotationX().get_mode().ToString() == "TwoCurves")
            {
                val = 3;
            }
            customProps.AddField("startRotationType", val);
            customProps.AddField("startRotationConstant", component.get_main().get_startRotation().get_constant() * 180f / 3.14159274f);
            customProps.AddField("startRotationConstantMin", component.get_main().get_startRotation().get_constantMin() * 180f / 3.14159274f);
            customProps.AddField("startRotationConstantMax", component.get_main().get_startRotation().get_constantMax() * 180f / 3.14159274f);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startRotationX().get_constant() * 180f / 3.14159274f);
            jSONObject2.Add(-1f * (component.get_main().get_startRotationY().get_constant() * 180f / 3.14159274f));
            jSONObject2.Add(-1f * (component.get_main().get_startRotationZ().get_constant() * 180f / 3.14159274f));
            customProps.AddField("startRotationConstantSeparate", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startRotationX().get_constantMin() * 180f / 3.14159274f);
            jSONObject2.Add(-1f * (component.get_main().get_startRotationY().get_constantMin() * 180f / 3.14159274f));
            jSONObject2.Add(-1f * (component.get_main().get_startRotationZ().get_constantMin() * 180f / 3.14159274f));
            customProps.AddField("startRotationConstantMinSeparate", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startRotationX().get_constantMax() * 180f / 3.14159274f);
            jSONObject2.Add(-1f * (component.get_main().get_startRotationY().get_constantMax() * 180f / 3.14159274f));
            jSONObject2.Add(-1f * (component.get_main().get_startRotationZ().get_constantMax() * 180f / 3.14159274f));
            customProps.AddField("startRotationConstantMaxSeparate", jSONObject2);
            customProps.AddField("randomizeRotationDirection", component.get_main().get_randomizeRotationDirection() * 180f / 3.14159274f);
            if (component.get_main().get_startColor().get_mode().ToString() == "Color")
            {
                val = 0;
            }
            else if (component.get_main().get_startColor().get_mode().ToString() == "Gradient")
            {
                val = 1;
            }
            else if (component.get_main().get_startColor().get_mode().ToString() == "TwoColors")
            {
                val = 2;
            }
            else if (component.get_main().get_startColor().get_mode().ToString() == "TwoGradients")
            {
                val = 3;
            }
            else if (component.get_main().get_startColor().get_mode().ToString() == "RandomColor")
            {
                val = 4;
            }
            customProps.AddField("startColorType", val);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startColor().get_color().r);
            jSONObject2.Add(component.get_main().get_startColor().get_color().g);
            jSONObject2.Add(component.get_main().get_startColor().get_color().b);
            jSONObject2.Add(component.get_main().get_startColor().get_color().a);
            customProps.AddField("startColorConstant", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMin().r);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMin().g);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMin().b);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMin().a);
            customProps.AddField("startColorConstantMin", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMax().r);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMax().g);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMax().b);
            jSONObject2.Add(component.get_main().get_startColor().get_colorMax().a);
            customProps.AddField("startColorConstantMax", jSONObject2);
            jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.Add(Physics.get_gravity().x);
            jSONObject2.Add(Physics.get_gravity().y);
            jSONObject2.Add(Physics.get_gravity().z);
            customProps.AddField("gravity", jSONObject2);
            customProps.AddField("gravityModifier", component.get_main().get_gravityModifier().get_constant());
            if (component.get_main().get_simulationSpace().ToString() == "World")
            {
                val = 0;
            }
            else if (component.get_main().get_simulationSpace().ToString() == "Local")
            {
                val = 1;
            }
            customProps.AddField("simulationSpace", val);
            if (component.get_main().get_scalingMode().ToString() == "Hierarchy")
            {
                val = 0;
            }
            else if (component.get_main().get_scalingMode().ToString() == "Local")
            {
                val = 1;
            }
            else if (component.get_main().get_scalingMode().ToString() == "Shape")
            {
                val = 2;
            }
            customProps.AddField("scaleMode", val);
            customProps.AddField("playOnAwake", component.get_main().get_playOnAwake());
            customProps.AddField("maxParticles", component.get_main().get_maxParticles());
            customProps.AddField("autoRandomSeed", component.get_useAutoRandomSeed());
            customProps.AddField("randomSeed", (long)((ulong)component.get_randomSeed()));
            if (component.get_emission().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("emission", jSONObject4);
                jSONObject4.AddField("enable", component.get_emission().get_enabled());
                if (component.get_emission().get_rateOverTime().get_mode().ToString() == "Constant")
                {
                    val = 0;
                }
                else if (component.get_emission().get_rateOverTime().get_mode().ToString() == "Curve")
                {
                    val = 1;
                }
                else if (component.get_emission().get_rateOverTime().get_mode().ToString() == "TwoConstants")
                {
                    val = 2;
                }
                else if (component.get_emission().get_rateOverTime().get_mode().ToString() == "TwoCurves")
                {
                    val = 3;
                }
                jSONObject4.AddField("emissionRate", component.get_emission().get_rateOverTime().get_constant());
                jSONObject4.AddField("emissionRateTip", "Time");
                jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                ParticleSystem.Burst[] array = new ParticleSystem.Burst[component.get_emission().get_burstCount()];
                component.get_emission().GetBursts(array);
                for (int i = 0; i < array.Length; i++)
                {
                    jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject3.AddField("time", array[i].get_time());
                    jSONObject3.AddField("min", (int)array[i].get_minCount());
                    jSONObject3.AddField("max", (int)array[i].get_maxCount());
                    jSONObject2.Add(jSONObject3);
                }
                jSONObject4.AddField("bursts", jSONObject2);
            }
            if (component.get_shape().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("shape", jSONObject4);
                jSONObject4.AddField("enable", component.get_shape().get_enabled());
                if (component.get_shape().get_shapeType().ToString() == "Sphere" || component.get_shape().get_shapeType().ToString() == "SphereShell")
                {
                    val = 0;
                }
                else if (component.get_shape().get_shapeType().ToString() == "Hemisphere" || component.get_shape().get_shapeType().ToString() == "HemisphereShell")
                {
                    val = 1;
                }
                else if (component.get_shape().get_shapeType().ToString() == "Cone" || component.get_shape().get_shapeType().ToString() == "ConeShell" || component.get_shape().get_shapeType().ToString() == "ConeBase" || component.get_shape().get_shapeType().ToString() == "ConeBaseShell" || component.get_shape().get_shapeType().ToString() == "ConeVolume" || component.get_shape().get_shapeType().ToString() == "ConeVolumeShell")
                {
                    val = 2;
                }
                else if (component.get_shape().get_shapeType().ToString() == "Box")
                {
                    val = 3;
                }
                else if (component.get_shape().get_shapeType().ToString() == "Mesh")
                {
                    val = 4;
                }
                else if (component.get_shape().get_shapeType().ToString() == "MeshRenderer")
                {
                    val = 5;
                }
                else if (component.get_shape().get_shapeType().ToString() == "SkinnedMeshRenderer")
                {
                    val = 6;
                }
                else if (component.get_shape().get_shapeType().ToString() == "Circle" || component.get_shape().get_shapeType().ToString() == "CircleEdge")
                {
                    val = 7;
                }
                else if (component.get_shape().get_shapeType().ToString() == "SingleSidedEdge")
                {
                    val = 8;
                }
                jSONObject4.AddField("shapeType", val);
                jSONObject4.AddField("sphereRadius", component.get_shape().get_radius());
                if (component.get_shape().get_shapeType().ToString() == "SphereShell")
                {
                    jSONObject4.AddField("sphereEmitFromShell", true);
                }
                else
                {
                    jSONObject4.AddField("sphereEmitFromShell", false);
                }
                jSONObject4.AddField("sphereRandomDirection", component.get_shape().get_randomDirectionAmount());
                jSONObject4.AddField("hemiSphereRadius", component.get_shape().get_radius());
                if (component.get_shape().get_shapeType().ToString() == "HemisphereShell")
                {
                    jSONObject4.AddField("hemiSphereEmitFromShell", true);
                }
                else
                {
                    jSONObject4.AddField("hemiSphereEmitFromShell", false);
                }
                jSONObject4.AddField("hemiSphereRandomDirection", component.get_shape().get_randomDirectionAmount());
                jSONObject4.AddField("coneAngle", component.get_shape().get_angle());
                jSONObject4.AddField("coneRadius", component.get_shape().get_radius());
                jSONObject4.AddField("coneLength", component.get_shape().get_length());
                if (component.get_shape().get_shapeType().ToString() == "Cone")
                {
                    val = 0;
                }
                else if (component.get_shape().get_shapeType().ToString() == "ConeShell")
                {
                    val = 1;
                }
                else if (component.get_shape().get_shapeType().ToString() == "ConeVolume")
                {
                    val = 2;
                }
                else if (component.get_shape().get_shapeType().ToString() == "ConeVolumeShell")
                {
                    val = 3;
                }
                jSONObject4.AddField("coneEmitType", val);
                jSONObject4.AddField("coneRandomDirection", component.get_shape().get_randomDirectionAmount());
                jSONObject4.AddField("boxX", component.get_shape().get_box().x);
                jSONObject4.AddField("boxY", component.get_shape().get_box().y);
                jSONObject4.AddField("boxZ", component.get_shape().get_box().z);
                jSONObject4.AddField("boxRandomDirection", component.get_shape().get_randomDirectionAmount());
                jSONObject4.AddField("circleRadius", component.get_shape().get_radius());
                jSONObject4.AddField("circleArc", component.get_shape().get_arc());
                if (component.get_shape().get_shapeType().ToString() == "CircleEdge")
                {
                    jSONObject4.AddField("circleEmitFromEdge", true);
                }
                else
                {
                    jSONObject4.AddField("circleEmitFromEdge", false);
                }
                jSONObject4.AddField("circleRandomDirection", component.get_shape().get_randomDirectionAmount());
            }
            if (component.get_velocityOverLifetime().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("velocityOverLifetime", jSONObject4);
                jSONObject4.AddField("enable", component.get_velocityOverLifetime().get_enabled());
                if (component.get_velocityOverLifetime().get_space().ToString() == "Local")
                {
                    val = 0;
                }
                else if (component.get_velocityOverLifetime().get_space().ToString() == "World")
                {
                    val = 1;
                }
                jSONObject4.AddField("space", val);
                jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject4.AddField("velocity", jSONObject);
                if (component.get_velocityOverLifetime().get_x().get_mode().ToString() == "Constant")
                {
                    val = 0;
                }
                else if (component.get_velocityOverLifetime().get_x().get_mode().ToString() == "Curve")
                {
                    val = 1;
                }
                else if (component.get_velocityOverLifetime().get_x().get_mode().ToString() == "TwoConstants")
                {
                    val = 2;
                }
                else if (component.get_velocityOverLifetime().get_x().get_mode().ToString() == "TwoCurves")
                {
                    val = 3;
                }
                jSONObject.AddField("type", val);
                JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_velocityOverLifetime().get_x().get_constant() * -1f);
                jSONObject5.Add(component.get_velocityOverLifetime().get_y().get_constant());
                jSONObject5.Add(component.get_velocityOverLifetime().get_z().get_constant());
                jSONObject.AddField("constant", jSONObject5);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_x(), jSONObject, "gradientX", "velocitys", 0, component.get_velocityOverLifetime().get_x().get_curveMultiplier(), -1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_y(), jSONObject, "gradientY", "velocitys", 0, component.get_velocityOverLifetime().get_y().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_z(), jSONObject, "gradientZ", "velocitys", 0, component.get_velocityOverLifetime().get_z().get_curveMultiplier(), 1f);
                jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_velocityOverLifetime().get_x().get_constantMin() * -1f);
                jSONObject5.Add(component.get_velocityOverLifetime().get_y().get_constantMin());
                jSONObject5.Add(component.get_velocityOverLifetime().get_z().get_constantMin());
                jSONObject.AddField("constantMin", jSONObject5);
                jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_velocityOverLifetime().get_x().get_constantMax() * -1f);
                jSONObject5.Add(component.get_velocityOverLifetime().get_y().get_constantMax());
                jSONObject5.Add(component.get_velocityOverLifetime().get_z().get_constantMax());
                jSONObject.AddField("constantMax", jSONObject5);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_x(), jSONObject, "gradientXMin", "velocitys", -1, component.get_velocityOverLifetime().get_x().get_curveMultiplier(), -1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_x(), jSONObject, "gradientXMax", "velocitys", 1, component.get_velocityOverLifetime().get_x().get_curveMultiplier(), -1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_y(), jSONObject, "gradientYMin", "velocitys", -1, component.get_velocityOverLifetime().get_y().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_y(), jSONObject, "gradientYMax", "velocitys", 1, component.get_velocityOverLifetime().get_y().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_z(), jSONObject, "gradientZMin", "velocitys", -1, component.get_velocityOverLifetime().get_z().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_velocityOverLifetime().get_z(), jSONObject, "gradientZMax", "velocitys", 1, component.get_velocityOverLifetime().get_z().get_curveMultiplier(), 1f);
            }
            if (component.get_colorOverLifetime().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("colorOverLifetime", jSONObject4);
                jSONObject4.AddField("enable", component.get_colorOverLifetime().get_enabled());
                jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject4.AddField("color", jSONObject);
                if (component.get_colorOverLifetime().get_color().get_mode().ToString() == "Gradient")
                {
                    val = 1;
                }
                else if (component.get_colorOverLifetime().get_color().get_mode().ToString() == "TwoGradients")
                {
                    val = 3;
                }
                jSONObject.AddField("type", val);
                jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_color().r);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_color().g);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_color().b);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_color().a);
                jSONObject.AddField("constant", jSONObject2);
                DataManager.saveParticleFrameData(component.get_colorOverLifetime().get_color().get_gradient(), jSONObject, "gradient");
                jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMin().r);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMin().g);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMin().b);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMin().a);
                jSONObject.AddField("constantMin", jSONObject2);
                jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMax().r);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMax().g);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMax().b);
                jSONObject2.Add(component.get_colorOverLifetime().get_color().get_colorMax().a);
                jSONObject.AddField("constantMax", jSONObject2);
                DataManager.saveParticleFrameData(component.get_colorOverLifetime().get_color().get_gradientMin(), jSONObject, "gradientMin");
                DataManager.saveParticleFrameData(component.get_colorOverLifetime().get_color().get_gradientMax(), jSONObject, "gradientMax");
            }
            if (component.get_sizeOverLifetime().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("sizeOverLifetime", jSONObject4);
                jSONObject4.AddField("enable", component.get_sizeOverLifetime().get_enabled());
                jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject4.AddField("size", jSONObject);
                if (component.get_sizeOverLifetime().get_size().get_mode().ToString() == "Curve")
                {
                    val = 0;
                }
                else if (component.get_sizeOverLifetime().get_size().get_mode().ToString() == "TwoConstants")
                {
                    val = 1;
                }
                else if (component.get_sizeOverLifetime().get_size().get_mode().ToString() == "TwoCurves")
                {
                    val = 2;
                }
                jSONObject.AddField("type", val);
                jSONObject.AddField("separateAxes", component.get_sizeOverLifetime().get_separateAxes());
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_size(), jSONObject, "gradient", "sizes", 0, component.get_sizeOverLifetime().get_size().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_x(), jSONObject, "gradientX", "sizes", 0, component.get_sizeOverLifetime().get_x().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_y(), jSONObject, "gradientY", "sizes", 0, component.get_sizeOverLifetime().get_y().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_z(), jSONObject, "gradientZ", "sizes", 0, component.get_sizeOverLifetime().get_z().get_curveMultiplier(), 1f);
                jSONObject.AddField("constantMin", component.get_sizeOverLifetime().get_size().get_constantMin());
                jSONObject.AddField("constantMax", component.get_sizeOverLifetime().get_size().get_constantMax());
                JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_sizeOverLifetime().get_x().get_constantMin());
                jSONObject5.Add(component.get_sizeOverLifetime().get_y().get_constantMin());
                jSONObject5.Add(component.get_sizeOverLifetime().get_z().get_constantMin());
                jSONObject.AddField("constantMinSeparate", jSONObject5);
                jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_sizeOverLifetime().get_x().get_constantMax());
                jSONObject5.Add(component.get_sizeOverLifetime().get_y().get_constantMax());
                jSONObject5.Add(component.get_sizeOverLifetime().get_z().get_constantMax());
                jSONObject.AddField("constantMaxSeparate", jSONObject5);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_size(), jSONObject, "gradientMin", "sizes", -1, component.get_sizeOverLifetime().get_size().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_size(), jSONObject, "gradientMax", "sizes", 1, component.get_sizeOverLifetime().get_size().get_curveMultiplier(), 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_x(), jSONObject, "gradientXMin", "sizes", -1, 1f, 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_x(), jSONObject, "gradientXMax", "sizes", 1, 1f, 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_y(), jSONObject, "gradientYMin", "sizes", -1, 1f, 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_y(), jSONObject, "gradientYMax", "sizes", 1, 1f, 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_z(), jSONObject, "gradientZMin", "sizes", -1, 1f, 1f);
                DataManager.saveParticleFrameData(component.get_sizeOverLifetime().get_z(), jSONObject, "gradientZMax", "sizes", 1, 1f, 1f);
            }
            if (component.get_rotationOverLifetime().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("rotationOverLifetime", jSONObject4);
                jSONObject4.AddField("enable", component.get_rotationOverLifetime().get_enabled());
                jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject4.AddField("angularVelocity", jSONObject);
                if (component.get_rotationOverLifetime().get_z().get_mode().ToString() == "Constant")
                {
                    val = 0;
                }
                else if (component.get_rotationOverLifetime().get_z().get_mode().ToString() == "Curve")
                {
                    val = 1;
                }
                else if (component.get_rotationOverLifetime().get_z().get_mode().ToString() == "TwoConstants")
                {
                    val = 2;
                }
                else if (component.get_rotationOverLifetime().get_z().get_mode().ToString() == "TwoCurves")
                {
                    val = 3;
                }
                jSONObject.AddField("type", val);
                jSONObject.AddField("separateAxes", component.get_rotationOverLifetime().get_separateAxes());
                jSONObject.AddField("constant", component.get_rotationOverLifetime().get_z().get_constant() * 180f / 3.14159274f);
                jSONObject.AddField("constantMin", component.get_rotationOverLifetime().get_z().get_constantMin() * 180f / 3.14159274f);
                jSONObject.AddField("constantMax", component.get_rotationOverLifetime().get_z().get_constantMax() * 180f / 3.14159274f);
                JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_rotationOverLifetime().get_x().get_constantMin() * 180f / 3.14159274f);
                jSONObject5.Add(component.get_rotationOverLifetime().get_y().get_constantMin() * 180f / 3.14159274f);
                jSONObject5.Add(component.get_rotationOverLifetime().get_z().get_constantMin() * 180f / 3.14159274f);
                jSONObject.AddField("constantMinSeparate", jSONObject5);
                jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.Add(component.get_rotationOverLifetime().get_x().get_constantMax() * 180f / 3.14159274f);
                jSONObject5.Add(component.get_rotationOverLifetime().get_y().get_constantMax() * 180f / 3.14159274f);
                jSONObject5.Add(component.get_rotationOverLifetime().get_z().get_constantMax() * 180f / 3.14159274f);
                jSONObject.AddField("constantMaxSeparate", jSONObject5);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradient", "angularVelocitys", 0, component.get_rotationOverLifetime().get_z().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientX", "angularVelocitys", 0, component.get_rotationOverLifetime().get_x().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientY", "angularVelocitys", 0, component.get_rotationOverLifetime().get_y().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientZ", "angularVelocitys", 0, component.get_rotationOverLifetime().get_z().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientMin", "angularVelocitys", -1, component.get_rotationOverLifetime().get_z().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientMax", "angularVelocitys", 1, component.get_rotationOverLifetime().get_z().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientXMin", "angularVelocitys", -1, component.get_rotationOverLifetime().get_x().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientXMax", "angularVelocitys", 1, component.get_rotationOverLifetime().get_x().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientYMin", "angularVelocitys", -1, component.get_rotationOverLifetime().get_y().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientYMax", "angularVelocitys", 1, component.get_rotationOverLifetime().get_y().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientZMin", "angularVelocitys", -1, component.get_rotationOverLifetime().get_z().get_curveMultiplier() * 180f / 3.14159274f, 1f);
                DataManager.saveParticleFrameData(component.get_rotationOverLifetime().get_z(), jSONObject, "gradientZMax", "angularVelocitys", 1, component.get_rotationOverLifetime().get_z().get_curveMultiplier() * 180f / 3.14159274f, 1f);
            }
            if (component.get_textureSheetAnimation().get_enabled())
            {
                JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
                customProps.AddField("textureSheetAnimation", jSONObject4);
                jSONObject4.AddField("enable", component.get_textureSheetAnimation().get_enabled());
                jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject4.AddField("tiles", jSONObject2);
                jSONObject2.Add(component.get_textureSheetAnimation().get_numTilesX());
                jSONObject2.Add(component.get_textureSheetAnimation().get_numTilesY());
                float num = 0f;
                ParticleSystemAnimationType animation = component.get_textureSheetAnimation().get_animation();
                if (animation != null)
                {
                    if (animation == 1)
                    {
                        val = 1;
                        num = (float)component.get_textureSheetAnimation().get_numTilesX();
                    }
                    else
                    {
                        Debug.LogWarning("unknown type.");
                    }
                }
                else
                {
                    val = 0;
                    num = (float)(component.get_textureSheetAnimation().get_numTilesX() * component.get_textureSheetAnimation().get_numTilesY());
                }
                float curveMultiplier = num * component.get_textureSheetAnimation().get_frameOverTime().get_curveMultiplier();
                jSONObject4.AddField("type", val);
                jSONObject4.AddField("randomRow", component.get_textureSheetAnimation().get_useRandomRow());
                jSONObject4.AddField("rowIndex", component.get_textureSheetAnimation().get_rowIndex());
                jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject4.AddField("frame", jSONObject);
                if (component.get_textureSheetAnimation().get_frameOverTime().get_mode().ToString() == "Constant")
                {
                    val = 0;
                }
                else if (component.get_textureSheetAnimation().get_frameOverTime().get_mode().ToString() == "Curve")
                {
                    val = 1;
                }
                else if (component.get_textureSheetAnimation().get_frameOverTime().get_mode().ToString() == "TwoConstants")
                {
                    val = 2;
                }
                else if (component.get_textureSheetAnimation().get_frameOverTime().get_mode().ToString() == "TwoCurves")
                {
                    val = 3;
                }
                jSONObject.AddField("type", val);
                jSONObject.AddField("constant", component.get_textureSheetAnimation().get_frameOverTime().get_constant() * num);
                DataManager.saveParticleFrameData(component.get_textureSheetAnimation().get_frameOverTime(), jSONObject, "overTime", "frames", 0, curveMultiplier, 1f);
                jSONObject.AddField("constantMin", component.get_textureSheetAnimation().get_frameOverTime().get_constantMin() * num);
                jSONObject.AddField("constantMax", component.get_textureSheetAnimation().get_frameOverTime().get_constantMax() * num);
                DataManager.saveParticleFrameData(component.get_textureSheetAnimation().get_frameOverTime(), jSONObject, "overTimeMin", "frames", -1, curveMultiplier, 1f);
                DataManager.saveParticleFrameData(component.get_textureSheetAnimation().get_frameOverTime(), jSONObject, "overTimeMax", "frames", 1, curveMultiplier, 1f);
                jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject4.AddField("startFrame", jSONObject);
                jSONObject.AddField("type", 0);
                jSONObject.AddField("constant", component.get_textureSheetAnimation().get_startFrame().get_constant() * (float)(component.get_textureSheetAnimation().get_numTilesX() * component.get_textureSheetAnimation().get_numTilesY() - 1));
                jSONObject.AddField("constantMin", component.get_textureSheetAnimation().get_startFrame().get_constantMin() * (float)(component.get_textureSheetAnimation().get_numTilesX() * component.get_textureSheetAnimation().get_numTilesY() - 1));
                jSONObject.AddField("constantMax", component.get_textureSheetAnimation().get_startFrame().get_constantMax() * (float)(component.get_textureSheetAnimation().get_numTilesX() * component.get_textureSheetAnimation().get_numTilesY() - 1));
                jSONObject4.AddField("cycles", component.get_textureSheetAnimation().get_cycleCount());
                if (component.get_textureSheetAnimation().get_enabled())
                {
                    jSONObject4.AddField("enableUVChannels", 1);
                }
                else
                {
                    jSONObject4.AddField("enableUVChannels", 0);
                }
                jSONObject4.AddField("enableUVChannelsTip", component.get_textureSheetAnimation().get_uvChannelMask().ToString());
            }
            int num2 = 0;
            if (component2.get_renderMode().ToString() == "Billboard")
            {
                num2 = 0;
            }
            else if (component2.get_renderMode().ToString() == "Stretch")
            {
                num2 = 1;
            }
            else if (component2.get_renderMode().ToString() == "HorizontalBillboard")
            {
                num2 = 2;
            }
            else if (component2.get_renderMode().ToString() == "VerticalBillboard")
            {
                num2 = 3;
            }
            else if (component2.get_renderMode().ToString() == "Mesh")
            {
                num2 = 4;
            }
            customProps.AddField("renderMode", num2);
            customProps.AddField("stretchedBillboardCameraSpeedScale", component2.get_cameraVelocityScale());
            customProps.AddField("stretchedBillboardSpeedScale", component2.get_velocityScale());
            customProps.AddField("stretchedBillboardLengthScale", component2.get_lengthScale());
            customProps.AddField("sortingFudge", component2.get_sortingFudge());
            Material sharedMaterial = gameObject.GetComponent<Renderer>().get_sharedMaterial();
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
            if (sharedMaterial != null)
            {
                string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(sharedMaterial.GetInstanceID()).Split(new char[]
                {
                    '.'
                })[0], false) + ".lmat";
                string text2 = DataManager.SAVEPATH + "/" + text;
                JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject7.AddField("type", "Laya.ShurikenParticleMaterial");
                jSONObject7.AddField("path", text);
                jSONObject6.Add(jSONObject7);
                customProps.AddField("material", jSONObject7);
                if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                {
                    if (sharedMaterial.get_shader().get_name() == "LayaAir3D/ShurikenParticle")
                    {
                        DataManager.saveLayaParticleLmatData(sharedMaterial, text2);
                    }
                    else
                    {
                        DataManager.saveLmatFile(sharedMaterial, text2, DataManager.ComponentType.ParticleSystem);
                    }
                }
            }
            if (num2 == 4)
            {
                Mesh mesh = gameObject.GetComponent<ParticleSystemRenderer>().get_mesh();
                if (mesh != null)
                {
                    string str = DataManager.cleanIllegalChar(mesh.get_name(), true);
                    string text3 = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(mesh.GetInstanceID()).Split(new char[]
                    {
                        '.'
                    })[0], false) + "-" + str + ".lm";
                    string text4 = DataManager.SAVEPATH + "/" + text3;
                    customProps.AddField("meshPath", text3);
                    if (!File.Exists(text4) || DataManager.CoverOriginalFile)
                    {
                        DataManager.saveLmFile(mesh, text4);
                        return;
                    }
                }
                else
                {
                    customProps.AddField("meshPath", "");
                    Debug.LogWarning("LayaUnityPlugin : " + gameObject.get_name() + "'s Render Mesh can't be null!");
                }
            }
        }

        public static void getTerrainComponentData(GameObject gameObject, JSONObject customProps)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            Terrain component = gameObject.GetComponent<Terrain>();
            if (DataManager.ConvertTerrainToMesh)
            {
                DataManager.saveTerrainLmFile(gameObject, customProps, 3);
                DataManager.saveTerrainLmatData(gameObject, customProps);
            }
            else
            {
                DataManager.saveTerrainData(DataManager.SAVEPATH, customProps, null);
            }
            if (component.get_lightmapIndex() > -1)
            {
                customProps.AddField("lightmapIndex", component.get_lightmapIndex());
                customProps.AddField("lightmapScaleOffset", jSONObject);
                jSONObject.Add(component.get_lightmapScaleOffset().x);
                jSONObject.Add(component.get_lightmapScaleOffset().y);
                jSONObject.Add(component.get_lightmapScaleOffset().z);
                jSONObject.Add(-component.get_lightmapScaleOffset().w);
            }
        }

        public static void getBoxColliderComponentData(GameObject gameObject, JSONObject component)
        {
            BoxCollider[] components = gameObject.GetComponents<BoxCollider>();
            for (int i = 0; i < components.Length; i++)
            {
                BoxCollider boxCollider = components[i];
                JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject.AddField("isTrigger", boxCollider.get_isTrigger());
                Vector3 center = boxCollider.get_center();
                jSONObject2.Add(center.x);
                jSONObject2.Add(center.y);
                jSONObject2.Add(center.z);
                jSONObject.AddField("center", jSONObject2);
                Vector3 size = boxCollider.get_size();
                jSONObject3.Add(size.x);
                jSONObject3.Add(size.y);
                jSONObject3.Add(size.z);
                jSONObject.AddField("size", jSONObject3);
                component.AddField("BoxCollider", jSONObject);
            }
        }

        public static void getSphereColliderComponentData(GameObject gameObject, JSONObject component)
        {
            SphereCollider[] components = gameObject.GetComponents<SphereCollider>();
            for (int i = 0; i < components.Length; i++)
            {
                SphereCollider sphereCollider = components[i];
                JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
                JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject.AddField("isTrigger", sphereCollider.get_isTrigger());
                Vector3 center = sphereCollider.get_center();
                jSONObject2.Add(center.x);
                jSONObject2.Add(center.y);
                jSONObject2.Add(center.z);
                jSONObject.AddField("center", jSONObject2);
                jSONObject.AddField("radius", sphereCollider.get_radius());
                component.AddField("SphereCollider", jSONObject);
            }
        }

        public static void getRigidbodyComponentData(GameObject gameObject, JSONObject component)
        {
            gameObject.GetComponent<Rigidbody>();
            JSONObject obj = new JSONObject(JSONObject.Type.OBJECT);
            component.AddField("Rigidbody", obj);
        }

        public static void getTrailRendererComponentData(GameObject gameObject, JSONObject props, JSONObject customProps)
        {
            TrailRenderer component = gameObject.GetComponent<TrailRenderer>();
            props.AddField("time", component.get_time());
            props.AddField("minVertexDistance", component.get_minVertexDistance());
            props.AddField("widthMultiplier", component.get_widthMultiplier());
            if (component.get_textureMode() == null)
            {
                props.AddField("textureMode", 0);
            }
            else
            {
                props.AddField("textureMode", 1);
            }
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("widthCurve", jSONObject);
            Keyframe[] keys = component.get_widthCurve().get_keys();
            for (int i = 0; i < keys.Length; i++)
            {
                Keyframe keyframe = keys[i];
                JSONObject jSONObject2;
                if (i == 0 && keyframe.get_time() != 0f)
                {
                    jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject2.AddField("time", 0);
                    jSONObject2.AddField("inTangent", 0);
                    jSONObject2.AddField("outTangent", 0);
                    jSONObject2.AddField("value", keyframe.get_value());
                    jSONObject.Add(jSONObject2);
                }
                jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject2.AddField("time", keyframe.get_time());
                jSONObject2.AddField("inTangent", keyframe.get_inTangent());
                jSONObject2.AddField("outTangent", keyframe.get_inTangent());
                jSONObject2.AddField("value", keyframe.get_value());
                jSONObject.Add(jSONObject2);
                if (i == keys.Length - 1 && keyframe.get_time() != 1f)
                {
                    jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject2.AddField("time", 1);
                    jSONObject2.AddField("inTangent", 0);
                    jSONObject2.AddField("outTangent", 0);
                    jSONObject2.AddField("value", keyframe.get_value());
                    jSONObject.Add(jSONObject2);
                }
            }
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            customProps.AddField("colorGradient", jSONObject3);
            Gradient colorGradient = component.get_colorGradient();
            if (colorGradient.get_mode() == null)
            {
                jSONObject3.AddField("mode", 0);
            }
            else
            {
                jSONObject3.AddField("mode", 1);
            }
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject3.AddField("colorKeys", jSONObject4);
            GradientColorKey[] colorKeys = colorGradient.get_colorKeys();
            for (int j = 0; j < colorKeys.Length; j++)
            {
                GradientColorKey gradientColorKey = colorKeys[j];
                JSONObject jSONObject5;
                JSONObject jSONObject6;
                Color color;
                if (j == 0 && gradientColorKey.time != 0f)
                {
                    jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject5.AddField("time", 0);
                    jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                    jSONObject5.AddField("value", jSONObject6);
                    color = gradientColorKey.color;
                    jSONObject6.Add(color.r);
                    jSONObject6.Add(color.g);
                    jSONObject6.Add(color.b);
                    jSONObject4.Add(jSONObject5);
                }
                jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject5.AddField("time", gradientColorKey.time);
                jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject5.AddField("value", jSONObject6);
                color = gradientColorKey.color;
                jSONObject6.Add(color.r);
                jSONObject6.Add(color.g);
                jSONObject6.Add(color.b);
                jSONObject4.Add(jSONObject5);
                if (j == colorKeys.Length - 1 && gradientColorKey.time != 1f)
                {
                    jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject5.AddField("time", 1);
                    jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                    jSONObject5.AddField("value", jSONObject6);
                    color = gradientColorKey.color;
                    jSONObject6.Add(color.r);
                    jSONObject6.Add(color.g);
                    jSONObject6.Add(color.b);
                    jSONObject4.Add(jSONObject5);
                }
            }
            JSONObject jSONObject7 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject3.AddField("alphaKeys", jSONObject7);
            GradientAlphaKey[] alphaKeys = colorGradient.get_alphaKeys();
            for (int k = 0; k < alphaKeys.Length; k++)
            {
                GradientAlphaKey gradientAlphaKey = alphaKeys[k];
                JSONObject jSONObject8;
                if (k == 0 && gradientAlphaKey.time != 0f)
                {
                    jSONObject8 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject8.AddField("time", 0);
                    jSONObject8.AddField("value", gradientAlphaKey.alpha);
                    jSONObject7.Add(jSONObject8);
                }
                jSONObject8 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject8.AddField("time", gradientAlphaKey.time);
                jSONObject8.AddField("value", gradientAlphaKey.alpha);
                jSONObject7.Add(jSONObject8);
                if (k == alphaKeys.Length - 1 && gradientAlphaKey.time != 1f)
                {
                    jSONObject8 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject8.AddField("time", 1);
                    jSONObject8.AddField("value", gradientAlphaKey.alpha);
                    jSONObject7.Add(jSONObject8);
                }
            }
            Material[] sharedMaterials = component.get_sharedMaterials();
            JSONObject jSONObject9 = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("materials", jSONObject9);
            for (int l = 0; l < sharedMaterials.Length; l++)
            {
                Material material = sharedMaterials[l];
                if (!(material == null))
                {
                    string text = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(material.GetInstanceID()).Split(new char[]
                    {
                        '.'
                    })[0], false) + ".lmat";
                    string text2 = DataManager.SAVEPATH + "/" + text;
                    string name = material.get_shader().get_name();
                    if (name.Split(new char[]
                    {
                        '/'
                    })[0] == "LayaAir3D" && name.Split(new char[]
                    {
                        '/'
                    })[1] == "Trail")
                    {
                        JSONObject jSONObject10 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject10.AddField("type", "Laya.TrailMaterial");
                        jSONObject10.AddField("path", text);
                        jSONObject9.Add(jSONObject10);
                        if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                        {
                            DataManager.saveLayaParticleLmatData(material, text2);
                        }
                    }
                }
            }
        }

        public static void getLavData(GameObject gameObject, JSONObject parentsChildNodes, GameObject animatorGameObject)
        {
            DataManager.checkChildIsNotLegal(gameObject, true);
            if (!gameObject.get_activeInHierarchy() && DataManager.IgnoreNotActiveGameObject)
            {
                return;
            }
            if ((DataManager.selectParentbyType(gameObject, DataManager.ComponentType.Animator) != animatorGameObject || DataManager.componentsOnGameObject(gameObject).IndexOf(DataManager.ComponentType.Animator) != -1) && gameObject != animatorGameObject)
            {
                return;
            }
            if (!DataManager.curNodeHasNotLegalChild)
            {
                return;
            }
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
            Vector3 localPosition = gameObject.get_transform().get_localPosition();
            Quaternion localRotation = gameObject.get_transform().get_localRotation();
            Vector3 localScale = gameObject.get_transform().get_localScale();
            jSONObject2.AddField("name", gameObject.get_name());
            jSONObject.AddField("props", jSONObject2);
            jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject.AddField("customProps", jSONObject3);
            jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject3.AddField("translate", jSONObject4);
            jSONObject4.Add(localPosition.x * -1f);
            jSONObject4.Add(localPosition.y);
            jSONObject4.Add(localPosition.z);
            jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject3.AddField("rotation", jSONObject5);
            jSONObject5.Add(localRotation.x * -1f);
            jSONObject5.Add(localRotation.y);
            jSONObject5.Add(localRotation.z);
            jSONObject5.Add(localRotation.w * -1f);
            jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject3.AddField("scale", jSONObject6);
            jSONObject6.Add(localScale.x);
            jSONObject6.Add(localScale.y);
            jSONObject6.Add(localScale.z);
            if (gameObject.get_transform().get_childCount() > 0)
            {
                JSONObject jSONObject7 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject.AddField("child", jSONObject7);
                for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                {
                    DataManager.getLavData(gameObject.get_transform().GetChild(i).get_gameObject(), jSONObject7, animatorGameObject);
                }
            }
            else
            {
                jSONObject.AddField("child", new JSONObject(JSONObject.Type.ARRAY));
            }
            parentsChildNodes.Add(jSONObject);
        }

        public static void saveLmFile(Mesh mesh, string savePath)
        {
            string item = DataManager.cleanIllegalChar(mesh.get_name(), true);
            ushort num = (ushort)mesh.get_subMeshCount();
            int num2 = (int)(num + 1);
            FileStream fileStream = FileUtil.saveFile(savePath, null);
            ushort num3 = 0;
            string text = "";
            for (int i = 0; i < DataManager.VertexStructure.Length; i++)
            {
                DataManager.VertexStructure[i] = 0;
            }
            Vector3[] vertices = mesh.get_vertices();
            Vector3[] normals = mesh.get_normals();
            Color[] colors = mesh.get_colors();
            Vector2[] uv = mesh.get_uv();
            Vector2[] uv2 = mesh.get_uv2();
            Vector4[] tangents = mesh.get_tangents();
            if (vertices != null && vertices.Length != 0)
            {
                DataManager.VertexStructure[0] = 1;
                text += "POSITION";
                num3 += 12;
            }
            if (normals != null && normals.Length != 0)
            {
                DataManager.VertexStructure[1] = 1;
                text += ",NORMAL";
                num3 += 12;
            }
            if (colors != null && colors.Length != 0 && !DataManager.IgnoreColor)
            {
                DataManager.VertexStructure[2] = 1;
                text += ",COLOR";
                num3 += 16;
            }
            if (uv != null && uv.Length != 0)
            {
                DataManager.VertexStructure[3] = 1;
                text += ",UV";
                num3 += 8;
            }
            if (uv2 != null && uv2.Length != 0)
            {
                DataManager.VertexStructure[4] = 1;
                text += ",UV1";
                num3 += 8;
            }
            if (tangents != null && tangents.Length != 0 && !DataManager.IgnoreTangent)
            {
                DataManager.VertexStructure[6] = 1;
                text += ",TANGENT";
                num3 += 16;
            }
            int[] array = new int[(int)num];
            int[] array2 = new int[(int)num];
            for (int i = 0; i < (int)num; i++)
            {
                int[] indices = mesh.GetIndices(i);
                array[i] = indices[0];
                array2[i] = indices.Length;
            }
            long[] array3 = new long[(int)num];
            long[] array4 = new long[(int)num];
            long[] array5 = new long[(int)num];
            List<string> list = new List<string>();
            list.Add("MESH");
            list.Add("SUBMESH");
            string data = "LAYAMODEL:0301";
            FileUtil.WriteData(fileStream, data);
            long arg_224_0 = fileStream.Position;
            long position = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long position2 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)num2
            });
            for (int i = 0; i < num2; i++)
            {
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
            }
            long position3 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new ushort[1]);
            long position4 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list.IndexOf("MESH")
            });
            list.Add(item);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list.IndexOf(item)
            });
            FileUtil.WriteData(fileStream, new ushort[]
            {
                1
            });
            long position5 = fileStream.Position;
            for (int i = 0; i < 1; i++)
            {
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                list.Add(text);
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list.IndexOf(text)
                });
            }
            long position6 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long arg_382_0 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long num4 = fileStream.Position - position4;
            for (int i = 0; i < (int)num; i++)
            {
                array3[i] = fileStream.Position;
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list.IndexOf("SUBMESH")
                });
                FileUtil.WriteData(fileStream, new ushort[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    1
                });
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                array4[i] = fileStream.Position;
                array5[i] = array4[i] - array3[i];
            }
            long position7 = fileStream.Position;
            for (int i = 0; i < list.Count; i++)
            {
                FileUtil.WriteData(fileStream, list[i]);
            }
            long num5 = fileStream.Position - position7;
            long position8 = fileStream.Position;
            for (int j = 0; j < mesh.get_vertexCount(); j++)
            {
                Vector3 vector = vertices[j];
                FileUtil.WriteData(fileStream, new float[]
                {
                    vector.x * -1f,
                    vector.y,
                    vector.z
                });
                if (DataManager.VertexStructure[1] == 1)
                {
                    Vector3 vector2 = normals[j];
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        vector2.x * -1f,
                        vector2.y,
                        vector2.z
                    });
                }
                if (DataManager.VertexStructure[2] == 1)
                {
                    Color color = colors[j];
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        color.r,
                        color.g,
                        color.b,
                        color.a
                    });
                }
                if (DataManager.VertexStructure[3] == 1)
                {
                    Vector2 vector3 = uv[j];
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        vector3.x,
                        vector3.y * -1f + 1f
                    });
                }
                if (DataManager.VertexStructure[4] == 1)
                {
                    Vector2 vector4 = uv2[j];
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        vector4.x,
                        vector4.y * -1f
                    });
                }
                if (DataManager.VertexStructure[6] == 1)
                {
                    Vector4 vector5 = tangents[j];
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        vector5.x * -1f,
                        vector5.y,
                        vector5.z,
                        vector5.w
                    });
                }
            }
            long num6 = fileStream.Position - position8;
            long position9 = fileStream.Position;
            int[] triangles = mesh.get_triangles();
            for (int j = 0; j < triangles.Length; j++)
            {
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)triangles[j]
                });
            }
            long num7 = fileStream.Position - position9;
            uint num8 = 0u;
            for (int i = 0; i < (int)num; i++)
            {
                fileStream.Position = array3[i] + 4L;
                uint num9;
                uint num10;
                uint num11;
                uint num12;
                if (num == 1)
                {
                    num9 = 0u;
                    num10 = (uint)(num6 / (long)((ulong)num3));
                    num11 = 0u;
                    num12 = (uint)(num7 / 2L);
                }
                else if (i == 0)
                {
                    num9 = 0u;
                    num10 = (uint)array[i + 1];
                    num11 = num8;
                    num12 = (uint)array2[i];
                }
                else if (i < (int)(num - 1))
                {
                    num9 = (uint)array[i];
                    num10 = (uint)(array[i + 1] - array[i]);
                    num11 = num8;
                    num12 = (uint)array2[i];
                }
                else
                {
                    num9 = (uint)array[i];
                    num10 = (uint)(num6 / (long)((ulong)num3) - (long)array[i]);
                    num11 = num8;
                    num12 = (uint)array2[i];
                }
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num9
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num10
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num11
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num12
                });
                num8 += num12;
                fileStream.Position += 2L;
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num11
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num12
                });
            }
            fileStream.Position = position5;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position8 - position7)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num6
            });
            fileStream.Position = position6;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position9 - position7)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num7
            });
            fileStream.Position = position3;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list.Count
            });
            long arg_8A5_0 = fileStream.Position;
            fileStream.Position = position2 + 2L;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)position4
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num4
            });
            for (int i = 0; i < (int)num; i++)
            {
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)array3[i]
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)array5[i]
                });
            }
            fileStream.Position = position;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)position7
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position7 + num5 + num6 + num7 + array5[0])
            });
            fileStream.Close();
        }

        public static void saveSkinLmFile(SkinnedMeshRenderer skinnedMeshRenderer, string savePath)
        {
            Mesh sharedMesh = skinnedMeshRenderer.get_sharedMesh();
            ushort num = 1;
            ushort num2 = (ushort)sharedMesh.get_subMeshCount();
            ushort num3 = 0;
            string text = "";
            string item = DataManager.cleanIllegalChar(sharedMesh.get_name(), true);
            for (int i = 0; i < DataManager.VertexStructure.Length; i++)
            {
                DataManager.VertexStructure[i] = 0;
            }
            if (sharedMesh.get_vertices() != null && sharedMesh.get_vertices().Length != 0)
            {
                DataManager.VertexStructure[0] = 1;
                text += "POSITION";
                num3 += 12;
            }
            if (sharedMesh.get_normals() != null && sharedMesh.get_normals().Length != 0)
            {
                DataManager.VertexStructure[1] = 1;
                text += ",NORMAL";
                num3 += 12;
            }
            if (sharedMesh.get_colors() != null && sharedMesh.get_colors().Length != 0 && !DataManager.IgnoreColor)
            {
                DataManager.VertexStructure[2] = 1;
                text += ",COLOR";
                num3 += 16;
            }
            if (sharedMesh.get_uv() != null && sharedMesh.get_uv().Length != 0)
            {
                DataManager.VertexStructure[3] = 1;
                text += ",UV";
                num3 += 8;
            }
            if (sharedMesh.get_uv2() != null && sharedMesh.get_uv2().Length != 0)
            {
                DataManager.VertexStructure[4] = 1;
                text += ",UV1";
                num3 += 8;
            }
            if (sharedMesh.get_boneWeights() != null && sharedMesh.get_boneWeights().Length != 0)
            {
                DataManager.VertexStructure[5] = 1;
                text += ",BLENDWEIGHT,BLENDINDICES";
                num3 += 32;
            }
            if (sharedMesh.get_tangents() != null && sharedMesh.get_tangents().Length != 0 && !DataManager.IgnoreTangent)
            {
                DataManager.VertexStructure[6] = 1;
                text += ",TANGENT";
                num3 += 16;
            }
            List<Transform> list = new List<Transform>();
            for (int j = 0; j < skinnedMeshRenderer.get_bones().Length; j++)
            {
                Transform item2 = skinnedMeshRenderer.get_bones()[j];
                if (list.IndexOf(item2) == -1)
                {
                    list.Add(item2);
                }
            }
            List<DataManager.VertexData> list2 = new List<DataManager.VertexData>();
            List<DataManager.VertexData> list3 = new List<DataManager.VertexData>();
            List<DataManager.VertexData> list4 = new List<DataManager.VertexData>();
            int[] array = new int[3];
            List<int> list5 = new List<int>();
            List<List<int>>[] array2 = new List<List<int>>[(int)num2];
            List<int> list6 = new List<int>();
            List<int> list7 = new List<int>();
            List<int>[] array3 = new List<int>[(int)num2];
            for (int i = 0; i < (int)num2; i++)
            {
                int[] indices = sharedMesh.GetIndices(i);
                array2[i] = new List<List<int>>();
                array3[i] = new List<int>();
                for (int j = 0; j < indices.Length; j += 3)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        int num4 = j + k;
                        int num5 = indices[num4];
                        array[k] = -1;
                        for (int l = 0; l < list3.Count; l++)
                        {
                            if (list3[l].index == num5)
                            {
                                array[k] = l;
                                break;
                            }
                        }
                        if (array[k] == -1)
                        {
                            DataManager.VertexData vertexData = DataManager.getVertexData(sharedMesh, num5);
                            list4.Add(vertexData);
                            for (int l = 0; l < 4; l++)
                            {
                                float num6 = vertexData.boneIndex.get_Item(l);
                                if (list6.IndexOf((int)num6) == -1 && list7.IndexOf((int)num6) == -1)
                                {
                                    list7.Add((int)num6);
                                }
                            }
                        }
                    }
                    if (list6.Count + list7.Count <= DataManager.MaxBoneCount)
                    {
                        for (int m = 0; m < list7.Count; m++)
                        {
                            list6.Add(list7[m]);
                        }
                        int num7 = 1;
                        for (int m = 0; m < 3; m++)
                        {
                            if (array[m] == -1)
                            {
                                list5.Add(list3.Count - 1 + num7++ + list2.Count);
                            }
                            else
                            {
                                list5.Add(array[m] + list2.Count);
                            }
                        }
                        for (int m = 0; m < list4.Count; m++)
                        {
                            list3.Add(list4[m]);
                        }
                    }
                    else
                    {
                        array3[i].Add(j);
                        array2[i].Add(list6);
                        for (int m = 0; m < list3.Count; m++)
                        {
                            DataManager.VertexData vertexData = list3[m];
                            for (int l = 0; l < 4; l++)
                            {
                                vertexData.boneIndex.set_Item(l, (float)list6.IndexOf((int)vertexData.boneIndex.get_Item(l)));
                            }
                            list2.Add(vertexData);
                        }
                        j -= 3;
                        list3 = new List<DataManager.VertexData>();
                        list6 = new List<int>();
                    }
                    if (j + 3 == indices.Length)
                    {
                        array3[i].Add(indices.Length);
                        array2[i].Add(list6);
                        for (int m = 0; m < list3.Count; m++)
                        {
                            DataManager.VertexData vertexData = list3[m];
                            for (int l = 0; l < 4; l++)
                            {
                                vertexData.boneIndex.set_Item(l, (float)list6.IndexOf((int)vertexData.boneIndex.get_Item(l)));
                            }
                            list2.Add(vertexData);
                        }
                        list3 = new List<DataManager.VertexData>();
                        list6 = new List<int>();
                    }
                    list7 = new List<int>();
                    list4 = new List<DataManager.VertexData>();
                }
            }
            int[] array4 = new int[(int)num2];
            int[] array5 = new int[(int)num2];
            int num8 = 0;
            for (int i = 0; i < (int)num2; i++)
            {
                int[] indices2 = sharedMesh.GetIndices(i);
                array4[i] = list5[num8];
                array5[i] = indices2.Length;
                num8 += indices2.Length;
            }
            long num9 = 0L;
            long num10 = 0L;
            long num11 = 0L;
            long[] array6 = new long[(int)num2];
            long[] array7 = new long[(int)num2];
            long[] array8 = new long[(int)num2];
            List<string> list8 = new List<string>();
            list8.Add("MESH");
            list8.Add("SUBMESH");
            FileStream fileStream = FileUtil.saveFile(savePath, null);
            string data = "LAYAMODEL:0301";
            FileUtil.WriteData(fileStream, data);
            long arg_5CC_0 = fileStream.Position;
            long position = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long position2 = fileStream.Position;
            int num12 = (int)(num2 + 1);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)num12
            });
            for (int i = 0; i < num12; i++)
            {
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
            }
            long position3 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new ushort[1]);
            long position4 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.IndexOf("MESH")
            });
            list8.Add(item);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.IndexOf(item)
            });
            FileUtil.WriteData(fileStream, new ushort[]
            {
                num
            });
            long position5 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            list8.Add(text);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.IndexOf(text)
            });
            long position6 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long position7 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list.Count
            });
            for (int i = 0; i < list.Count; i++)
            {
                list8.Add(list[i].get_name());
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list8.IndexOf(list[i].get_name())
                });
            }
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long num13 = fileStream.Position - position4;
            for (int i = 0; i < (int)num2; i++)
            {
                array6[i] = fileStream.Position;
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list8.IndexOf("SUBMESH")
                });
                FileUtil.WriteData(fileStream, new ushort[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)array2[i].Count
                });
                for (int j = 0; j < array2[i].Count; j++)
                {
                    FileUtil.WriteData(fileStream, new uint[1]);
                    FileUtil.WriteData(fileStream, new uint[1]);
                    FileUtil.WriteData(fileStream, new uint[1]);
                    FileUtil.WriteData(fileStream, new uint[1]);
                }
                array7[i] = fileStream.Position;
                array8[i] = array7[i] - array6[i];
            }
            long position8 = fileStream.Position;
            for (int i = 0; i < list8.Count; i++)
            {
                FileUtil.WriteData(fileStream, list8[i]);
            }
            long num14 = fileStream.Position - position8;
            long position9 = fileStream.Position;
            for (int j = 0; j < list2.Count; j++)
            {
                DataManager.VertexData vertexData = list2[j];
                Vector3 vertice = vertexData.vertice;
                FileUtil.WriteData(fileStream, new float[]
                {
                    vertice.x * -1f,
                    vertice.y,
                    vertice.z
                });
                if (DataManager.VertexStructure[1] == 1)
                {
                    Vector3 normal = vertexData.normal;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        normal.x * -1f,
                        normal.y,
                        normal.z
                    });
                }
                if (DataManager.VertexStructure[2] == 1)
                {
                    Color color = vertexData.color;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        color.r,
                        color.g,
                        color.b,
                        color.a
                    });
                }
                if (DataManager.VertexStructure[3] == 1)
                {
                    Vector2 uv = vertexData.uv;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        uv.x,
                        uv.y * -1f + 1f
                    });
                }
                if (DataManager.VertexStructure[4] == 1)
                {
                    Vector2 uv2 = vertexData.uv2;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        uv2.x,
                        uv2.y * -1f
                    });
                }
                if (DataManager.VertexStructure[5] == 1)
                {
                    Vector4 boneWeight = vertexData.boneWeight;
                    Vector4 boneIndex = vertexData.boneIndex;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        boneWeight.x,
                        boneWeight.y,
                        boneWeight.z,
                        boneWeight.w
                    });
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        boneIndex.x,
                        boneIndex.y,
                        boneIndex.z,
                        boneIndex.w
                    });
                }
                if (DataManager.VertexStructure[6] == 1)
                {
                    Vector4 tangent = vertexData.tangent;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        tangent.x * -1f,
                        tangent.y,
                        tangent.z,
                        tangent.w
                    });
                }
            }
            long num15 = fileStream.Position - position9;
            long position10 = fileStream.Position;
            for (int j = 0; j < list5.Count; j++)
            {
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list5[j]
                });
            }
            long num16 = fileStream.Position - position10;
            if (sharedMesh.get_bindposes() != null && sharedMesh.get_bindposes().Length != 0)
            {
                Matrix4x4[] array9 = new Matrix4x4[sharedMesh.get_bindposes().Length];
                for (int i = 0; i < sharedMesh.get_bindposes().Length; i++)
                {
                    array9[i] = sharedMesh.get_bindposes()[i];
                    array9[i] = array9[i].get_inverse();
                    Vector3 vector;
                    Quaternion quaternion;
                    Vector3 vector2;
                    MathUtil.Decompose(array9[i].get_transpose(), out vector, out quaternion, out vector2);
                    vector2.x *= -1f;
                    quaternion.x *= -1f;
                    quaternion.w *= -1f;
                    array9[i] = Matrix4x4.TRS(vector2, quaternion, vector);
                }
                num9 = fileStream.Position;
                for (int i = 0; i < sharedMesh.get_bindposes().Length; i++)
                {
                    Matrix4x4 matrix4x = array9[i];
                    for (int j = 0; j < 16; j++)
                    {
                        FileUtil.WriteData(fileStream, new float[]
                        {
                            matrix4x.get_Item(j)
                        });
                    }
                }
                num10 = fileStream.Position;
                for (int i = 0; i < sharedMesh.get_bindposes().Length; i++)
                {
                    Matrix4x4 inverse = array9[i].get_inverse();
                    for (int j = 0; j < 16; j++)
                    {
                        FileUtil.WriteData(fileStream, new float[]
                        {
                            inverse.get_Item(j)
                        });
                    }
                }
                num11 = fileStream.Position;
                for (int i = 0; i < (int)num2; i++)
                {
                    for (int j = 0; j < array2[i].Count; j++)
                    {
                        for (int k = 0; k < array2[i][j].Count; k++)
                        {
                            FileUtil.WriteData(fileStream, new byte[]
                            {
                                (byte)array2[i][j][k]
                            });
                        }
                    }
                }
                long arg_D55_0 = fileStream.Position;
            }
            uint num17 = 0u;
            long num18 = num11 - position8;
            for (int i = 0; i < (int)num2; i++)
            {
                fileStream.Position = array6[i] + 4L;
                uint num19;
                uint num20;
                uint num21;
                uint num22;
                if (num2 == 1)
                {
                    num19 = 0u;
                    num20 = (uint)(num15 / (long)((ulong)num3));
                    num21 = 0u;
                    num22 = (uint)(num16 / 2L);
                }
                else if (i == 0)
                {
                    num19 = 0u;
                    num20 = (uint)array4[i + 1];
                    num21 = num17;
                    num22 = (uint)array5[i];
                }
                else if (i < (int)(num2 - 1))
                {
                    num19 = (uint)array4[i];
                    num20 = (uint)(array4[i + 1] - array4[i]);
                    num21 = num17;
                    num22 = (uint)array5[i];
                }
                else
                {
                    num19 = (uint)array4[i];
                    num20 = (uint)(num15 / (long)((ulong)num3) - (long)array4[i]);
                    num21 = num17;
                    num22 = (uint)array5[i];
                }
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num19
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num20
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num21
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num22
                });
                num17 += num22;
                fileStream.Position += 2L;
                int num23 = 0;
                for (int j = 0; j < array2[i].Count; j++)
                {
                    FileUtil.WriteData(fileStream, new uint[]
                    {
                        (uint)(num23 + (int)num21)
                    });
                    FileUtil.WriteData(fileStream, new uint[]
                    {
                        (uint)(array3[i][j] - num23)
                    });
                    num23 = array3[i][j];
                    FileUtil.WriteData(fileStream, new uint[]
                    {
                        (uint)num18
                    });
                    FileUtil.WriteData(fileStream, new uint[]
                    {
                        (uint)array2[i][j].Count
                    });
                    num18 += (long)array2[i][j].Count;
                }
            }
            fileStream.Position = position5;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position9 - position8)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num15
            });
            fileStream.Position = position6;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position10 - position8)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num16
            });
            fileStream.Position = position7 + (long)((list.Count + 1) * 2);
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(num9 - position8)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(num10 - num9)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(num10 - position8)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(num11 - num10)
            });
            fileStream.Position = position3;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.Count
            });
            long arg_1012_0 = fileStream.Position;
            fileStream.Position = position2 + 2L;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)position4
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num13
            });
            for (int i = 0; i < (int)num2; i++)
            {
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)array6[i]
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)array8[i]
                });
            }
            fileStream.Position = position;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)position8
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position8 + num14 + num15 + num16 + array8[0])
            });
            fileStream.Close();
        }

        public static void saveTerrainLmFile(GameObject gameObject, JSONObject obj, int gameObjectType)
        {
            TerrainData terrainData = gameObject.GetComponent<Terrain>().get_terrainData();
            int num = terrainData.get_heightmapWidth();
            int num2 = terrainData.get_heightmapHeight();
            Vector3 size = terrainData.get_size();
            int terrainToMeshResolution = DataManager.TerrainToMeshResolution;
            Vector3 vector = new Vector3(size.x / (float)(num - 1) * (float)terrainToMeshResolution, size.y, size.z / (float)(num2 - 1) * (float)terrainToMeshResolution);
            Vector2 vector2 = new Vector2(1f / (float)(num - 1), 1f / (float)(num2 - 1));
            float[,] heights = terrainData.GetHeights(0, 0, num, num2);
            num = (num - 1) / terrainToMeshResolution + 1;
            num2 = (num2 - 1) / terrainToMeshResolution + 1;
            Vector3[] array = new Vector3[num * num2];
            Vector3[] array2 = new Vector3[num * num2];
            Vector2[] array3 = new Vector2[num * num2];
            int[] array4 = new int[(num - 1) * (num2 - 1) * 6];
            for (int i = 0; i < num2; i++)
            {
                for (int j = 0; j < num; j++)
                {
                    array[i * num + j] = Vector3.Scale(new Vector3((float)i, heights[j * terrainToMeshResolution, i * terrainToMeshResolution], (float)j), vector);
                    array3[i * num + j] = Vector2.Scale(new Vector2((float)(j * terrainToMeshResolution), 1f - (float)(i * terrainToMeshResolution)), vector2) - new Vector2(0f, 1f / (float)(terrainData.get_heightmapHeight() - 1));
                    float x = array3[i * num + j].x;
                    float y = array3[i * num + j].y;
                    array3[i * num + j] = new Vector2(x * Mathf.Cos(1.57079637f) - y * Mathf.Sin(1.57079637f), x * Mathf.Sin(1.57079637f) + y * Mathf.Cos(1.57079637f));
                }
            }
            int num3 = 0;
            for (int k = 0; k < num2 - 1; k++)
            {
                for (int l = 0; l < num - 1; l++)
                {
                    array4[num3++] = k * num + l;
                    array4[num3++] = k * num + l + 1;
                    array4[num3++] = (k + 1) * num + l;
                    array4[num3++] = (k + 1) * num + l;
                    array4[num3++] = k * num + l + 1;
                    array4[num3++] = (k + 1) * num + l + 1;
                }
            }
            for (int m = 0; m < array.Length; m++)
            {
                List<Vector3> list = new List<Vector3>();
                for (int n = 0; n < array4.Length; n += 3)
                {
                    if (array4[n] == m || array4[n + 1] == m || array4[n + 2] == m)
                    {
                        list.Add(array[array4[n]]);
                        list.Add(array[array4[n + 1]]);
                        list.Add(array[array4[n + 2]]);
                    }
                }
                float num4 = 0f;
                List<float> list2 = new List<float>();
                List<Vector3> list3 = new List<Vector3>();
                for (int num5 = 0; num5 < list.Count; num5 += 3)
                {
                    Vector3 vector3 = list[num5] - list[num5 + 1];
                    Vector3 vector4 = list[num5] - list[num5 + 2];
                    float num6 = Mathf.Sqrt(Mathf.Pow(list[num5].x - list[num5 + 1].x, 2f) + Mathf.Pow(list[num5].y - list[num5 + 1].y, 2f) + Mathf.Pow(list[num5].z - list[num5 + 1].z, 2f));
                    float num7 = Mathf.Sqrt(Mathf.Pow(list[num5].x - list[num5 + 2].x, 2f) + Mathf.Pow(list[num5].y - list[num5 + 2].y, 2f) + Mathf.Pow(list[num5].z - list[num5 + 2].z, 2f));
                    float num8 = Mathf.Sqrt(Mathf.Pow(list[num5 + 2].x - list[num5 + 1].x, 2f) + Mathf.Pow(list[num5 + 2].y - list[num5 + 1].y, 2f) + Mathf.Pow(list[num5 + 2].z - list[num5 + 1].z, 2f));
                    float num9 = (num6 + num7 + num8) / 2f;
                    float num10 = Mathf.Sqrt(num9 * (num9 - num6) * (num9 - num7) * (num9 - num8));
                    list2.Add(num10);
                    num4 += num10;
                    list3.Add(Vector3.Cross(vector3, vector4).get_normalized());
                }
                Vector3 vector5 = default(Vector3);
                for (int num11 = 0; num11 < list3.Count; num11++)
                {
                    vector5 += list3[num11] * list2[num11] / num4;
                }
                array2[m] = vector5.get_normalized();
            }
            int num12 = 65534;
            List<List<DataManager.TerrainVertexData>> list4 = new List<List<DataManager.TerrainVertexData>>();
            List<DataManager.TerrainVertexData> list5 = new List<DataManager.TerrainVertexData>();
            list4.Add(list5);
            List<List<int>> list6 = new List<List<int>>();
            List<int> list7 = new List<int>();
            list6.Add(list7);
            for (int num13 = 0; num13 < array4.Length; num13++)
            {
                if (list5.Count == num12)
                {
                    list5 = new List<DataManager.TerrainVertexData>();
                    list4.Add(list5);
                    list7 = new List<int>();
                    list6.Add(list7);
                }
                int num14 = array4[num13];
                DataManager.TerrainVertexData item;
                item.vertice = array[num14];
                item.normal = array2[num14];
                item.uv = array3[num14];
                int num15 = list5.IndexOf(item);
                if (num15 == -1)
                {
                    list5.Add(item);
                    list7.Add(list5.Count - 1);
                }
                else
                {
                    list7.Add(num15);
                }
            }
            int count = list4.Count;
            string text = DataManager.cleanIllegalChar("terrain_" + gameObject.get_name(), true);
            string text2 = "terrain/" + text + ".lm";
            obj.AddField("meshPath", text2);
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            obj.AddField("materials", jSONObject);
            string str = DataManager.cleanIllegalChar("terrain_" + gameObject.get_name(), true);
            string val = "terrain/" + str + ".lmat";
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject2.AddField("type", "Laya.ExtendTerrainMaterial");
            jSONObject2.AddField("path", val);
            for (int num16 = 0; num16 < count; num16++)
            {
                jSONObject.Add(jSONObject2);
            }
            string text3 = DataManager.SAVEPATH + "/" + text2;
            int num17 = 1 + count;
            ushort num18 = 32;
            string item2 = "POSITION,NORMAL,UV";
            if (File.Exists(text3) && !DataManager.CoverOriginalFile)
            {
                return;
            }
            long[] array5 = new long[count];
            long[] array6 = new long[count];
            long[] array7 = new long[count];
            long[] array8 = new long[count];
            long[] array9 = new long[count];
            List<string> list8 = new List<string>();
            list8.Add("MESH");
            list8.Add("SUBMESH");
            FileStream fileStream = FileUtil.saveFile(text3, null);
            string data = "LAYAMODEL:0301";
            FileUtil.WriteData(fileStream, data);
            long arg_81C_0 = fileStream.Position;
            long position = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long position2 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)num17
            });
            for (int num19 = 0; num19 < num17; num19++)
            {
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
            }
            long position3 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new ushort[1]);
            long position4 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.IndexOf("MESH")
            });
            list8.Add(text);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.IndexOf(text)
            });
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list4.Count
            });
            list8.Add(item2);
            for (int num19 = 0; num19 < list4.Count; num19++)
            {
                array5[num19] = fileStream.Position;
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list8.IndexOf(item2)
                });
            }
            long position5 = fileStream.Position;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long arg_994_0 = fileStream.Position;
            FileUtil.WriteData(fileStream, new ushort[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new uint[1]);
            long num20 = fileStream.Position - position4;
            for (int num19 = 0; num19 < count; num19++)
            {
                array7[num19] = fileStream.Position;
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)list8.IndexOf("SUBMESH")
                });
                FileUtil.WriteData(fileStream, new ushort[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    1
                });
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                FileUtil.WriteData(fileStream, new uint[1]);
                array8[num19] = fileStream.Position;
                array9[num19] = array8[num19] - array7[num19];
            }
            long position6 = fileStream.Position;
            for (int num19 = 0; num19 < list8.Count; num19++)
            {
                FileUtil.WriteData(fileStream, list8[num19]);
            }
            long num21 = fileStream.Position - position6;
            long position7 = fileStream.Position;
            for (int num19 = 0; num19 < list4.Count; num19++)
            {
                array6[num19] = fileStream.Position;
                List<DataManager.TerrainVertexData> list9 = list4[num19];
                for (int num22 = 0; num22 < list9.Count; num22++)
                {
                    DataManager.TerrainVertexData terrainVertexData = list9[num22];
                    Vector3 vertice = terrainVertexData.vertice;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        vertice.x * -1f,
                        vertice.y,
                        vertice.z
                    });
                    Vector3 normal = terrainVertexData.normal;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        normal.x * -1f,
                        normal.y,
                        normal.z
                    });
                    Vector2 uv = terrainVertexData.uv;
                    FileUtil.WriteData(fileStream, new float[]
                    {
                        uv.x,
                        uv.y * -1f + 1f
                    });
                }
            }
            long num23 = fileStream.Position - position7;
            long position8 = fileStream.Position;
            for (int num19 = 0; num19 < list6.Count; num19++)
            {
                List<int> list10 = list6[num19];
                for (int num22 = 0; num22 < list10.Count; num22++)
                {
                    FileUtil.WriteData(fileStream, new ushort[]
                    {
                        (ushort)list10[num22]
                    });
                }
            }
            long num24 = fileStream.Position - position8;
            uint num25 = 0u;
            uint num26 = 0u;
            for (int num19 = 0; num19 < count; num19++)
            {
                fileStream.Position = array7[num19] + 2L;
                FileUtil.WriteData(fileStream, new ushort[]
                {
                    (ushort)num19
                });
                uint num27 = num25;
                uint count2 = (uint)list4[num19].Count;
                uint num28 = num26;
                uint count3 = (uint)list6[num19].Count;
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num27
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    count2
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num28
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    count3
                });
                num25 += count2;
                num26 += count3;
                fileStream.Position += 2L;
                FileUtil.WriteData(fileStream, new uint[]
                {
                    num28
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    count3
                });
            }
            for (int num19 = 0; num19 < list4.Count; num19++)
            {
                fileStream.Position = array5[num19];
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)(array6[num19] - position6)
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)(list4[num19].Count * (int)num18)
                });
            }
            fileStream.Position = position5;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position8 - position6)
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num24
            });
            fileStream.Position = position3;
            FileUtil.WriteData(fileStream, new uint[1]);
            FileUtil.WriteData(fileStream, new ushort[]
            {
                (ushort)list8.Count
            });
            long arg_E3E_0 = fileStream.Position;
            fileStream.Position = position2 + 2L;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)position4
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)num20
            });
            for (int num19 = 0; num19 < count; num19++)
            {
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)array7[num19]
                });
                FileUtil.WriteData(fileStream, new uint[]
                {
                    (uint)array9[num19]
                });
            }
            fileStream.Position = position;
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)position6
            });
            FileUtil.WriteData(fileStream, new uint[]
            {
                (uint)(position6 + num21 + num23 + num24 + array9[0])
            });
            fileStream.Close();
        }

        public static void saveLmatFile(Material material, string savePath, DataManager.ComponentType type)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject.AddField("version", "LAYAMATERIAL:01");
            jSONObject.AddField("props", jSONObject2);
            string name = material.get_name();
            jSONObject2.AddField("name", name);
            string name2 = material.get_shader().get_name();
            string value = "Legacy Shaders/Transparent/Cutout/";
            int num = 1;
            if (name2 == "Particles/Additive" || name2 == "Mobile/Particles/Additive" || name2 == "Particles/Additive (Soft)")
            {
                num = 8;
            }
            else if (name2 == "Particles/Alpha Blended" || name2 == "Mobile/Particles/Alpha Blended")
            {
                num = 6;
            }
            else if (name2 == "Standard" || name2 == "Standard (Specular setup)")
            {
                if (material.get_shaderKeywords().Length == 0)
                {
                    num = 1;
                }
                else if (material.get_shaderKeywords()[0] == "_EMISSION" && material.GetInt("_SrcBlend") == 1 && material.GetInt("_DstBlend") == 0 && material.GetInt("_ZWrite") == 1)
                {
                    num = 1;
                }
                else if (material.get_shaderKeywords()[0] == "_ALPHATEST_ON" && material.GetInt("_SrcBlend") == 1 && material.GetInt("_DstBlend") == 0 && material.GetInt("_ZWrite") == 1)
                {
                    num = 3;
                }
                else if (material.get_shaderKeywords()[0] == "_ALPHABLEND_ON" && material.GetInt("_SrcBlend") == 5 && material.GetInt("_DstBlend") == 10 && material.GetInt("_ZWrite") == 0)
                {
                    num = 5;
                }
                else if (material.get_shaderKeywords()[0] == "_ALPHAPREMULTIPLY_ON" && material.GetInt("_SrcBlend") == 1 && material.GetInt("_DstBlend") == 10 && material.GetInt("_ZWrite") == 0)
                {
                    num = 13;
                }
            }
            else if (name2.IndexOf(value) > -1)
            {
                num = 3;
            }
            else if (name2 == "Mobile/Diffuse" || name2 == "Legacy Shaders/Diffuse")
            {
                num = 1;
            }
            else
            {
                num = 1;
            }
            switch (num)
            {
                case 1:
                    jSONObject2.AddField("cull", 2);
                    jSONObject2.AddField("blend", 0);
                    jSONObject2.AddField("srcBlend", 1);
                    jSONObject2.AddField("dstBlend", 0);
                    jSONObject2.AddField("alphaTest", false);
                    jSONObject2.AddField("depthWrite", true);
                    jSONObject2.AddField("renderQueue", 1);
                    goto IL_4FE;
                case 2:
                case 4:
                case 7:
                    break;
                case 3:
                    jSONObject2.AddField("cull", 0);
                    jSONObject2.AddField("blend", 0);
                    jSONObject2.AddField("srcBlend", 1);
                    jSONObject2.AddField("dstBlend", 0);
                    jSONObject2.AddField("alphaTest", true);
                    jSONObject2.AddField("depthWrite", true);
                    jSONObject2.AddField("renderQueue", 1);
                    goto IL_4FE;
                case 5:
                    jSONObject2.AddField("cull", 0);
                    jSONObject2.AddField("blend", 1);
                    jSONObject2.AddField("srcBlend", 770);
                    jSONObject2.AddField("dstBlend", 771);
                    jSONObject2.AddField("alphaTest", false);
                    jSONObject2.AddField("depthWrite", false);
                    jSONObject2.AddField("renderQueue", 2);
                    goto IL_4FE;
                case 6:
                    jSONObject2.AddField("cull", 0);
                    jSONObject2.AddField("blend", 1);
                    jSONObject2.AddField("srcBlend", 770);
                    jSONObject2.AddField("dstBlend", 771);
                    jSONObject2.AddField("alphaTest", false);
                    jSONObject2.AddField("depthWrite", false);
                    jSONObject2.AddField("renderQueue", 2);
                    goto IL_4FE;
                case 8:
                    jSONObject2.AddField("cull", 0);
                    jSONObject2.AddField("blend", 1);
                    jSONObject2.AddField("srcBlend", 770);
                    jSONObject2.AddField("dstBlend", 1);
                    jSONObject2.AddField("alphaTest", false);
                    jSONObject2.AddField("depthWrite", false);
                    jSONObject2.AddField("renderQueue", 2);
                    jSONObject5.Add("ADDTIVEFOG");
                    goto IL_4FE;
                default:
                    if (num == 13)
                    {
                        jSONObject2.AddField("cull", 2);
                        jSONObject2.AddField("blend", 1);
                        jSONObject2.AddField("srcBlend", 770);
                        jSONObject2.AddField("dstBlend", 771);
                        jSONObject2.AddField("alphaTest", false);
                        jSONObject2.AddField("depthWrite", true);
                        jSONObject2.AddField("renderQueue", 2);
                        goto IL_4FE;
                    }
                    break;
            }
            jSONObject2.AddField("cull", 2);
            jSONObject2.AddField("blend", 0);
            jSONObject2.AddField("srcBlend", 1);
            jSONObject2.AddField("dstBlend", 0);
            jSONObject2.AddField("alphaTest", false);
            jSONObject2.AddField("depthWrite", true);
            jSONObject2.AddField("renderQueue", 1);
        IL_4FE:
            jSONObject2.AddField("textures", jSONObject3);
            jSONObject2.AddField("vectors", jSONObject4);
            jSONObject2.AddField("defines", jSONObject5);
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject6.AddField("name", "diffuseTexture");
            if (material.HasProperty("_MainTex"))
            {
                Texture2D texture = (Texture2D)material.GetTexture("_MainTex");
                DataManager.saveTextureFile(jSONObject6, texture, savePath, name, "path");
            }
            else
            {
                jSONObject6.AddField("path", "");
            }
            jSONObject3.Add(jSONObject6);
            if (type == DataManager.ComponentType.ParticleSystem)
            {
                JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject7.AddField("name", "tintColor");
                JSONObject jSONObject8 = new JSONObject(JSONObject.Type.ARRAY);
                if (material.HasProperty("_TintColor"))
                {
                    Color color = material.GetColor("_TintColor");
                    jSONObject8.Add(color.r);
                    jSONObject8.Add(color.g);
                    jSONObject8.Add(color.b);
                    jSONObject8.Add(color.a);
                }
                else
                {
                    jSONObject8.Add(0.5f);
                    jSONObject8.Add(0.5f);
                    jSONObject8.Add(0.5f);
                    jSONObject8.Add(0.5f);
                }
                jSONObject7.AddField("value", jSONObject8);
                jSONObject4.Add(jSONObject7);
            }
            else
            {
                JSONObject jSONObject9 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject9.AddField("name", "normalTexture");
                if (material.HasProperty("_BumpMap"))
                {
                    Texture2D texture2 = (Texture2D)material.GetTexture("_BumpMap");
                    DataManager.saveTextureFile(jSONObject9, texture2, savePath, name, "path");
                }
                else
                {
                    jSONObject9.AddField("path", "");
                }
                jSONObject3.Add(jSONObject9);
                JSONObject jSONObject10 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject10.AddField("name", "specularTexture");
                if (material.HasProperty("_SpecGlossMap"))
                {
                    Texture2D texture3 = (Texture2D)material.GetTexture("_SpecGlossMap");
                    DataManager.saveTextureFile(jSONObject10, texture3, savePath, name, "path");
                }
                else
                {
                    jSONObject10.AddField("path", "");
                }
                jSONObject3.Add(jSONObject10);
                JSONObject jSONObject11 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject11.AddField("name", "emissiveTexture");
                if (material.HasProperty("_EmissionMap"))
                {
                    Texture2D texture4 = (Texture2D)material.GetTexture("_EmissionMap");
                    DataManager.saveTextureFile(jSONObject11, texture4, savePath, name, "path");
                }
                else
                {
                    jSONObject11.AddField("path", "");
                }
                jSONObject3.Add(jSONObject11);
                JSONObject jSONObject12 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject12.AddField("name", "ambientColor");
                JSONObject jSONObject13 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject13.Add(0f);
                jSONObject13.Add(0f);
                jSONObject13.Add(0f);
                jSONObject12.AddField("value", jSONObject13);
                jSONObject4.Add(jSONObject12);
                JSONObject jSONObject14 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject14.AddField("name", "albedo");
                JSONObject jSONObject15 = new JSONObject(JSONObject.Type.ARRAY);
                if (material.HasProperty("_Color"))
                {
                    Color color2 = material.GetColor("_Color");
                    jSONObject15.Add(color2.r);
                    jSONObject15.Add(color2.g);
                    jSONObject15.Add(color2.b);
                    jSONObject15.Add(color2.a);
                }
                else if (material.HasProperty("_TintColor"))
                {
                    Color color3 = material.GetColor("_TintColor");
                    jSONObject15.Add(color3.r * 2f);
                    jSONObject15.Add(color3.g * 2f);
                    jSONObject15.Add(color3.b * 2f);
                    jSONObject15.Add(color3.a * 2f);
                }
                else
                {
                    jSONObject15.Add(1f);
                    jSONObject15.Add(1f);
                    jSONObject15.Add(1f);
                    jSONObject15.Add(1f);
                }
                jSONObject14.AddField("value", jSONObject15);
                jSONObject4.Add(jSONObject14);
                JSONObject jSONObject16 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject16.AddField("name", "diffuseColor");
                JSONObject jSONObject17 = new JSONObject(JSONObject.Type.ARRAY);
                if (material.HasProperty("_DiffuseColor"))
                {
                    Color color4 = material.GetColor("_DiffuseColor");
                    jSONObject17.Add(color4.r);
                    jSONObject17.Add(color4.g);
                    jSONObject17.Add(color4.b);
                }
                else
                {
                    jSONObject17.Add(1f);
                    jSONObject17.Add(1f);
                    jSONObject17.Add(1f);
                }
                jSONObject16.AddField("value", jSONObject17);
                jSONObject4.Add(jSONObject16);
                JSONObject jSONObject18 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject18.AddField("name", "specularColor");
                JSONObject jSONObject19 = new JSONObject(JSONObject.Type.ARRAY);
                if (material.HasProperty("_SpecColor"))
                {
                    Color color5 = material.GetColor("_SpecColor");
                    jSONObject19.Add(color5.r);
                    jSONObject19.Add(color5.g);
                    jSONObject19.Add(color5.b);
                    jSONObject19.Add(color5.a);
                }
                else
                {
                    jSONObject19.Add(1f);
                    jSONObject19.Add(1f);
                    jSONObject19.Add(1f);
                    jSONObject19.Add(8f);
                }
                jSONObject18.AddField("value", jSONObject19);
                jSONObject4.Add(jSONObject18);
                JSONObject jSONObject20 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject20.AddField("name", "emissionColor");
                JSONObject jSONObject21 = new JSONObject(JSONObject.Type.ARRAY);
                if (material.HasProperty("_EmissionColor"))
                {
                    Color color6 = material.GetColor("_EmissionColor");
                    jSONObject21.Add(color6.r);
                    jSONObject21.Add(color6.g);
                    jSONObject21.Add(color6.b);
                }
                else
                {
                    jSONObject21.Add(0f);
                    jSONObject21.Add(0f);
                    jSONObject21.Add(0f);
                }
                jSONObject20.AddField("value", jSONObject21);
                jSONObject4.Add(jSONObject20);
            }
            FileUtil.saveFile(savePath, jSONObject);
        }

        public static void saveTerrainLmatData(GameObject gameObject, JSONObject obj)
        {
            TerrainData terrainData = gameObject.GetComponent<Terrain>().get_terrainData();
            string text = DataManager.cleanIllegalChar("terrain_" + gameObject.get_name(), true);
            string str = "terrain/" + text + ".lmat";
            string text2 = DataManager.SAVEPATH + "/" + str;
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject obj2 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject.AddField("version", "LAYAMATERIAL:01");
            jSONObject.AddField("props", jSONObject2);
            jSONObject2.AddField("name", text);
            jSONObject2.AddField("cull", 2);
            jSONObject2.AddField("blend", 0);
            jSONObject2.AddField("srcBlend", 1);
            jSONObject2.AddField("dstBlend", 0);
            jSONObject2.AddField("alphaTest", false);
            jSONObject2.AddField("depthWrite", true);
            jSONObject2.AddField("renderQueue", 1);
            jSONObject2.AddField("textures", jSONObject3);
            jSONObject2.AddField("vectors", jSONObject4);
            jSONObject2.AddField("defines", obj2);
            if (terrainData.get_alphamapTextures().Length > 0)
            {
                for (int i = 0; i < 1; i++)
                {
                    JSONObject jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject5.AddField("name", "splatAlphaTexture");
                    Color[] pixels = terrainData.get_alphamapTextures()[i].GetPixels();
                    int num = pixels.Length;
                    int expr_16C = (int)Mathf.Sqrt((float)num);
                    Texture2D texture2D = new Texture2D(expr_16C, expr_16C);
                    Color[] array = new Color[num];
                    for (int j = 0; j < num; j++)
                    {
                        array[j] = pixels[j];
                        if (array[j].a == 0f)
                        {
                            array[j].a = 0.03125f;
                        }
                    }
                    texture2D.SetPixels(array);
                    texture2D.Apply();
                    FileStream expr_1ED = File.Open(DataManager.SAVEPATH + "/terrain/splatAlphaTexture.png", FileMode.Create);
                    new BinaryWriter(expr_1ED).Write(texture2D.EncodeToPNG());
                    expr_1ED.Close();
                    jSONObject5.AddField("path", "splatAlphaTexture.png");
                    jSONObject3.Add(jSONObject5);
                }
            }
            int num2 = terrainData.get_splatPrototypes().Length;
            for (int k = 0; k < num2; k++)
            {
                SplatPrototype splatPrototype = terrainData.get_splatPrototypes()[k];
                JSONObject jSONObject6 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject6.AddField("name", "diffuseTexture" + (k + 1));
                DataManager.saveTextureFile(jSONObject6, splatPrototype.get_texture(), DataManager.cleanIllegalChar(text2, false), null, "path");
                jSONObject3.Add(jSONObject6);
                JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject7.AddField("name", "diffuseScaleOffset" + (k + 1));
                JSONObject jSONObject8 = new JSONObject(JSONObject.Type.ARRAY);
                jSONObject8.Add(terrainData.get_size().x / splatPrototype.get_tileSize().x);
                jSONObject8.Add(terrainData.get_size().z / splatPrototype.get_tileSize().y);
                jSONObject8.Add(splatPrototype.get_tileOffset().x);
                jSONObject8.Add(splatPrototype.get_tileOffset().y);
                jSONObject7.AddField("value", jSONObject8);
                jSONObject4.Add(jSONObject7);
            }
            JSONObject jSONObject9 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject9.AddField("name", "albedo");
            JSONObject jSONObject10 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject10.Add(1f);
            jSONObject10.Add(1f);
            jSONObject10.Add(1f);
            jSONObject10.Add(1f);
            jSONObject9.AddField("value", jSONObject10);
            jSONObject4.Add(jSONObject9);
            JSONObject jSONObject11 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject11.AddField("name", "ambientColor");
            JSONObject jSONObject12 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject12.Add(0f);
            jSONObject12.Add(0f);
            jSONObject12.Add(0f);
            jSONObject11.AddField("value", jSONObject12);
            jSONObject4.Add(jSONObject11);
            JSONObject jSONObject13 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject13.AddField("name", "diffuseColor");
            JSONObject jSONObject14 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject14.Add(1f);
            jSONObject14.Add(1f);
            jSONObject14.Add(1f);
            jSONObject13.AddField("value", jSONObject14);
            jSONObject4.Add(jSONObject13);
            JSONObject jSONObject15 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject15.AddField("name", "specularColor");
            JSONObject jSONObject16 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject16.Add(1f);
            jSONObject16.Add(1f);
            jSONObject16.Add(1f);
            jSONObject16.Add(8f);
            jSONObject15.AddField("value", jSONObject16);
            jSONObject4.Add(jSONObject15);
            FileUtil.saveFile(text2, jSONObject);
        }

        public static void saveLayaLmatData(Material material, string savePath)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject.AddField("version", "LAYAMATERIAL:01");
            jSONObject.AddField("props", jSONObject2);
            List<string> list = material.get_shaderKeywords().ToList<string>();
            string name = material.get_name();
            jSONObject2.AddField("name", name);
            jSONObject2.AddField("cull", material.GetInt("_Cull"));
            if (list.IndexOf("_ALPHABLEND_ON") != -1)
            {
                jSONObject2.AddField("blend", 1);
            }
            else
            {
                jSONObject2.AddField("blend", 0);
            }
            switch (material.GetInt("_SrcBlend"))
            {
                case 0:
                    jSONObject2.AddField("srcBlend", 0);
                    break;
                case 1:
                    jSONObject2.AddField("srcBlend", 1);
                    break;
                case 2:
                    jSONObject2.AddField("srcBlend", 774);
                    break;
                case 3:
                    jSONObject2.AddField("srcBlend", 768);
                    break;
                case 4:
                    jSONObject2.AddField("srcBlend", 775);
                    break;
                case 5:
                    jSONObject2.AddField("srcBlend", 770);
                    break;
                case 6:
                    jSONObject2.AddField("srcBlend", 769);
                    break;
                case 7:
                    jSONObject2.AddField("srcBlend", 772);
                    break;
                case 8:
                    jSONObject2.AddField("srcBlend", 773);
                    break;
                case 9:
                    jSONObject2.AddField("srcBlend", 776);
                    break;
                case 10:
                    jSONObject2.AddField("srcBlend", 771);
                    break;
                default:
                    jSONObject2.AddField("srcBlend", 1);
                    break;
            }
            switch (material.GetInt("_DstBlend"))
            {
                case 0:
                    jSONObject2.AddField("dstBlend", 0);
                    break;
                case 1:
                    jSONObject2.AddField("dstBlend", 1);
                    break;
                case 2:
                    jSONObject2.AddField("dstBlend", 774);
                    break;
                case 3:
                    jSONObject2.AddField("dstBlend", 768);
                    break;
                case 4:
                    jSONObject2.AddField("dstBlend", 775);
                    break;
                case 5:
                    jSONObject2.AddField("dstBlend", 770);
                    break;
                case 6:
                    jSONObject2.AddField("dstBlend", 769);
                    break;
                case 7:
                    jSONObject2.AddField("dstBlend", 772);
                    break;
                case 8:
                    jSONObject2.AddField("dstBlend", 773);
                    break;
                case 9:
                    jSONObject2.AddField("dstBlend", 776);
                    break;
                case 10:
                    jSONObject2.AddField("dstBlend", 771);
                    break;
                default:
                    jSONObject2.AddField("dstBlend", 0);
                    break;
            }
            if (list.IndexOf("_ALPHATEST_ON") != -1)
            {
                jSONObject2.AddField("alphaTest", true);
            }
            else
            {
                jSONObject2.AddField("alphaTest", false);
            }
            jSONObject2.AddField("alphaTestValue", material.GetFloat("_Cutoff"));
            if (material.GetInt("_ZWrite") == 1)
            {
                jSONObject2.AddField("depthWrite", true);
            }
            else
            {
                jSONObject2.AddField("depthWrite", false);
            }
            switch (material.GetInt("_ZTest"))
            {
                case 0:
                    jSONObject2.AddField("depthTest", 0);
                    break;
                case 1:
                    jSONObject2.AddField("depthTest", 512);
                    break;
                case 2:
                    jSONObject2.AddField("depthTest", 513);
                    break;
                case 3:
                    jSONObject2.AddField("depthTest", 514);
                    break;
                case 4:
                    jSONObject2.AddField("depthTest", 515);
                    break;
                case 5:
                    jSONObject2.AddField("depthTest", 516);
                    break;
                case 6:
                    jSONObject2.AddField("depthTest", 517);
                    break;
                case 7:
                    jSONObject2.AddField("depthTest", 518);
                    break;
                case 8:
                    jSONObject2.AddField("depthTest", 519);
                    break;
                default:
                    jSONObject2.AddField("depthTest", 0);
                    break;
            }
            if (list.IndexOf("_ALPHABLEND_ON") != -1)
            {
                jSONObject2.AddField("renderQueue", 2);
            }
            else
            {
                jSONObject2.AddField("renderQueue", 1);
            }
            if (material.HasProperty("_AlbedoIntensity"))
            {
                jSONObject2.AddField("albedoIntensity", material.GetFloat("_AlbedoIntensity"));
            }
            if (material.HasProperty("_Metallic"))
            {
                jSONObject2.AddField("metallic", material.GetFloat("_Metallic"));
            }
            if (material.HasProperty("_Glossiness"))
            {
                jSONObject2.AddField("smoothness", material.GetFloat("_Glossiness"));
            }
            if (material.HasProperty("_GlossMapScale"))
            {
                jSONObject2.AddField("smoothnessTextureScale", material.GetFloat("_GlossMapScale"));
            }
            if (material.HasProperty("_SmoothnessTextureChannel"))
            {
                jSONObject2.AddField("smoothnessSource", material.GetFloat("_SmoothnessTextureChannel"));
            }
            if (material.HasProperty("_BumpScale"))
            {
                jSONObject2.AddField("normalTextureScale", material.GetFloat("_BumpScale"));
            }
            if (material.HasProperty("_Parallax"))
            {
                jSONObject2.AddField("parallaxTextureScale", material.GetFloat("_Parallax"));
            }
            if (material.HasProperty("_OcclusionStrength"))
            {
                jSONObject2.AddField("occlusionTextureStrength", material.GetFloat("_OcclusionStrength"));
            }
            if (material.HasProperty("_Emission"))
            {
                if ((double)material.GetFloat("_Emission") == 1.0)
                {
                    jSONObject2.AddField("enableEmission", true);
                }
                else
                {
                    jSONObject2.AddField("enableEmission", false);
                }
            }
            if (material.HasProperty("_MainTex"))
            {
                Texture2D texture2D = (Texture2D)material.GetTexture("_MainTex");
                if (texture2D != null)
                {
                    JSONObject jSONObject6 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject6.AddField("name", "albedoTexture");
                    DataManager.saveTextureFile(jSONObject6, texture2D, savePath, name, "path");
                    jSONObject3.Add(jSONObject6);
                }
                JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject7.AddField("name", "tilingOffset");
                JSONObject jSONObject8 = new JSONObject(JSONObject.Type.ARRAY);
                Vector2 textureScale = material.GetTextureScale("_MainTex");
                Vector2 textureOffset = material.GetTextureOffset("_MainTex");
                jSONObject8.Add(textureScale.x);
                jSONObject8.Add(textureScale.y);
                jSONObject8.Add(textureOffset.x);
                jSONObject8.Add(textureOffset.y * -1f);
                jSONObject7.AddField("value", jSONObject8);
                jSONObject4.Add(jSONObject7);
            }
            if (material.HasProperty("_MetallicGlossMap"))
            {
                Texture2D texture2D2 = (Texture2D)material.GetTexture("_MetallicGlossMap");
                if (texture2D2 != null)
                {
                    JSONObject jSONObject9 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject9.AddField("name", "metallicGlossTexture");
                    DataManager.saveTextureFile(jSONObject9, texture2D2, savePath, name, "path");
                    jSONObject3.Add(jSONObject9);
                }
            }
            if (material.HasProperty("_Lighting"))
            {
                if ((double)material.GetFloat("_Lighting") == 0.0)
                {
                    jSONObject2.AddField("enableLighting", true);
                }
                else
                {
                    jSONObject2.AddField("enableLighting", false);
                }
            }
            if (!material.HasProperty("_Lighting") || (material.HasProperty("_Lighting") && (double)material.GetFloat("_Lighting") == 0.0))
            {
                if (material.HasProperty("_Shininess"))
                {
                    jSONObject2.AddField("shininess", material.GetFloat("_Shininess"));
                }
                if (material.HasProperty("_SpecGlossMap"))
                {
                    Texture2D texture2D3 = (Texture2D)material.GetTexture("_SpecGlossMap");
                    if (texture2D3 != null)
                    {
                        JSONObject jSONObject10 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject10.AddField("name", "specularTexture");
                        DataManager.saveTextureFile(jSONObject10, texture2D3, savePath, name, "path");
                        jSONObject3.Add(jSONObject10);
                    }
                }
                if (material.HasProperty("_BumpMap"))
                {
                    Texture2D texture2D4 = (Texture2D)material.GetTexture("_BumpMap");
                    if (texture2D4 != null)
                    {
                        JSONObject jSONObject11 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject11.AddField("name", "normalTexture");
                        DataManager.saveTextureFile(jSONObject11, texture2D4, savePath, name, "path");
                        jSONObject3.Add(jSONObject11);
                    }
                }
                JSONObject jSONObject12 = new JSONObject(JSONObject.Type.OBJECT);
                jSONObject12.AddField("name", "specularColor");
                JSONObject jSONObject13 = new JSONObject(JSONObject.Type.ARRAY);
                if (material.HasProperty("_SpecColor"))
                {
                    Color color = material.GetColor("_SpecColor");
                    jSONObject13.Add(color.r);
                    jSONObject13.Add(color.g);
                    jSONObject13.Add(color.b);
                    jSONObject12.AddField("value", jSONObject13);
                    jSONObject4.Add(jSONObject12);
                }
            }
            if (material.HasProperty("_ParallaxMap"))
            {
                Texture2D texture2D5 = (Texture2D)material.GetTexture("_ParallaxMap");
                if (texture2D5 != null)
                {
                    JSONObject jSONObject14 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject14.AddField("name", "parallaxTexture");
                    DataManager.saveTextureFile(jSONObject14, texture2D5, savePath, name, "path");
                    jSONObject3.Add(jSONObject14);
                }
            }
            if (material.HasProperty("_OcclusionMap"))
            {
                Texture2D texture2D6 = (Texture2D)material.GetTexture("_OcclusionMap");
                if (texture2D6 != null)
                {
                    JSONObject jSONObject15 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject15.AddField("name", "occlusionTexture");
                    DataManager.saveTextureFile(jSONObject15, texture2D6, savePath, name, "path");
                    jSONObject3.Add(jSONObject15);
                }
            }
            if (material.HasProperty("_EmissionMap"))
            {
                Texture2D texture2D7 = (Texture2D)material.GetTexture("_EmissionMap");
                if (texture2D7 != null)
                {
                    JSONObject jSONObject16 = new JSONObject(JSONObject.Type.OBJECT);
                    jSONObject16.AddField("name", "emissionTexture");
                    DataManager.saveTextureFile(jSONObject16, texture2D7, savePath, name, "path");
                    jSONObject3.Add(jSONObject16);
                }
            }
            JSONObject jSONObject17 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject17.AddField("name", "albedoColor");
            JSONObject jSONObject18 = new JSONObject(JSONObject.Type.ARRAY);
            if (material.HasProperty("_Color"))
            {
                Color color2 = material.GetColor("_Color");
                jSONObject18.Add(color2.r);
                jSONObject18.Add(color2.g);
                jSONObject18.Add(color2.b);
                jSONObject18.Add(color2.a);
                jSONObject17.AddField("value", jSONObject18);
                jSONObject4.Add(jSONObject17);
            }
            JSONObject jSONObject19 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject19.AddField("name", "emissionColor");
            JSONObject jSONObject20 = new JSONObject(JSONObject.Type.ARRAY);
            if (material.HasProperty("_EmissionColor"))
            {
                Color color3 = material.GetColor("_EmissionColor");
                jSONObject20.Add(color3.r);
                jSONObject20.Add(color3.g);
                jSONObject20.Add(color3.b);
                jSONObject20.Add(color3.a);
                jSONObject19.AddField("value", jSONObject20);
                jSONObject4.Add(jSONObject19);
            }
            if (material.GetInt("_Mode") == 2 || material.GetInt("_Mode") == 3)
            {
                jSONObject5.Add("ADDTIVEFOG");
            }
            jSONObject2.AddField("textures", jSONObject3);
            jSONObject2.AddField("vectors", jSONObject4);
            jSONObject2.AddField("defines", jSONObject5);
            FileUtil.saveFile(savePath, jSONObject);
        }

        public static void saveLayaParticleLmatData(Material material, string savePath)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject.AddField("version", "LAYAMATERIAL:01");
            jSONObject.AddField("props", jSONObject2);
            List<string> list = material.get_shaderKeywords().ToList<string>();
            string name = material.get_name();
            jSONObject2.AddField("name", name);
            jSONObject2.AddField("cull", material.GetInt("_Cull"));
            if (list.IndexOf("_ALPHABLEND_ON") != -1)
            {
                jSONObject2.AddField("blend", 1);
            }
            else
            {
                jSONObject2.AddField("blend", 0);
            }
            switch (material.GetInt("_SrcBlend"))
            {
                case 0:
                    jSONObject2.AddField("srcBlend", 0);
                    break;
                case 1:
                    jSONObject2.AddField("srcBlend", 1);
                    break;
                case 2:
                    jSONObject2.AddField("srcBlend", 774);
                    break;
                case 3:
                    jSONObject2.AddField("srcBlend", 768);
                    break;
                case 4:
                    jSONObject2.AddField("srcBlend", 775);
                    break;
                case 5:
                    jSONObject2.AddField("srcBlend", 770);
                    break;
                case 6:
                    jSONObject2.AddField("srcBlend", 769);
                    break;
                case 7:
                    jSONObject2.AddField("srcBlend", 772);
                    break;
                case 8:
                    jSONObject2.AddField("srcBlend", 773);
                    break;
                case 9:
                    jSONObject2.AddField("srcBlend", 776);
                    break;
                case 10:
                    jSONObject2.AddField("srcBlend", 771);
                    break;
                default:
                    jSONObject2.AddField("srcBlend", 1);
                    break;
            }
            switch (material.GetInt("_DstBlend"))
            {
                case 0:
                    jSONObject2.AddField("dstBlend", 0);
                    break;
                case 1:
                    jSONObject2.AddField("dstBlend", 1);
                    break;
                case 2:
                    jSONObject2.AddField("dstBlend", 774);
                    break;
                case 3:
                    jSONObject2.AddField("dstBlend", 768);
                    break;
                case 4:
                    jSONObject2.AddField("dstBlend", 775);
                    break;
                case 5:
                    jSONObject2.AddField("dstBlend", 770);
                    break;
                case 6:
                    jSONObject2.AddField("dstBlend", 769);
                    break;
                case 7:
                    jSONObject2.AddField("dstBlend", 772);
                    break;
                case 8:
                    jSONObject2.AddField("dstBlend", 773);
                    break;
                case 9:
                    jSONObject2.AddField("dstBlend", 776);
                    break;
                case 10:
                    jSONObject2.AddField("dstBlend", 771);
                    break;
                default:
                    jSONObject2.AddField("dstBlend", 0);
                    break;
            }
            if (list.IndexOf("_ALPHATEST_ON") != -1)
            {
                jSONObject2.AddField("alphaTest", true);
            }
            else
            {
                jSONObject2.AddField("alphaTest", false);
            }
            if (material.GetInt("_ZWrite") == 1)
            {
                jSONObject2.AddField("depthWrite", true);
            }
            else
            {
                jSONObject2.AddField("depthWrite", false);
            }
            switch (material.GetInt("_ZTest"))
            {
                case 0:
                    jSONObject2.AddField("depthTest", 0);
                    break;
                case 1:
                    jSONObject2.AddField("depthTest", 512);
                    break;
                case 2:
                    jSONObject2.AddField("depthTest", 513);
                    break;
                case 3:
                    jSONObject2.AddField("depthTest", 514);
                    break;
                case 4:
                    jSONObject2.AddField("depthTest", 515);
                    break;
                case 5:
                    jSONObject2.AddField("depthTest", 516);
                    break;
                case 6:
                    jSONObject2.AddField("depthTest", 517);
                    break;
                case 7:
                    jSONObject2.AddField("depthTest", 518);
                    break;
                case 8:
                    jSONObject2.AddField("depthTest", 519);
                    break;
                default:
                    jSONObject2.AddField("depthTest", 0);
                    break;
            }
            if (list.IndexOf("_ALPHABLEND_ON") != -1)
            {
                jSONObject2.AddField("renderQueue", 2);
            }
            else
            {
                jSONObject2.AddField("renderQueue", 1);
            }
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject6.AddField("name", "diffuseTexture");
            JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject7.AddField("name", "tilingOffset");
            if (material.HasProperty("_MainTex"))
            {
                Texture2D texture = (Texture2D)material.GetTexture("_MainTex");
                DataManager.saveTextureFile(jSONObject6, texture, savePath, name, "path");
                jSONObject3.Add(jSONObject6);
                JSONObject jSONObject8 = new JSONObject(JSONObject.Type.ARRAY);
                Vector2 textureScale = material.GetTextureScale("_MainTex");
                Vector2 textureOffset = material.GetTextureOffset("_MainTex");
                jSONObject8.Add(textureScale.x);
                jSONObject8.Add(textureScale.y);
                jSONObject8.Add(textureOffset.x);
                jSONObject8.Add(textureOffset.y * -1f);
                jSONObject7.AddField("value", jSONObject8);
                jSONObject4.Add(jSONObject7);
            }
            JSONObject jSONObject9 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject9.AddField("name", "tintColor");
            JSONObject jSONObject10 = new JSONObject(JSONObject.Type.ARRAY);
            if (material.HasProperty("_Color"))
            {
                Color color = material.GetColor("_Color");
                jSONObject10.Add(color.r);
                jSONObject10.Add(color.g);
                jSONObject10.Add(color.b);
                jSONObject10.Add(color.a);
                jSONObject9.AddField("value", jSONObject10);
                jSONObject4.Add(jSONObject9);
            }
            if (material.GetInt("_Mode") == 2 || material.GetInt("_Mode") == 3)
            {
                jSONObject5.Add("ADDTIVEFOG");
            }
            jSONObject2.AddField("textures", jSONObject3);
            jSONObject2.AddField("vectors", jSONObject4);
            jSONObject2.AddField("defines", jSONObject5);
            FileUtil.saveFile(savePath, jSONObject);
        }

        public static void saveLayaSkyBoxData(Material material, string savePath)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject.AddField("version", "LAYAMATERIAL:01");
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject.AddField("props", jSONObject2);
            if (material.HasProperty("_Exposure"))
            {
                jSONObject2.AddField("exposure", material.GetFloat("_Exposure"));
            }
            if (material.HasProperty("_Rotation"))
            {
                jSONObject2.AddField("rotation", material.GetFloat("_Rotation"));
            }
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.AddField("vectors", jSONObject3);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject4.AddField("name", "tintColor");
            JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
            if (material.HasProperty("_Tint"))
            {
                Color color = material.GetColor("_Tint");
                jSONObject5.Add(color.r);
                jSONObject5.Add(color.g);
                jSONObject5.Add(color.b);
                jSONObject5.Add(color.a);
                jSONObject4.AddField("value", jSONObject5);
                jSONObject3.Add(jSONObject4);
            }
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject2.AddField("textures", jSONObject6);
            JSONObject jSONObject7 = new JSONObject(JSONObject.Type.OBJECT);
            jSONObject6.Add(jSONObject7);
            new JSONObject(JSONObject.Type.OBJECT);
            jSONObject7.AddField("name", "textureCube");
            string str = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(material.GetInstanceID()).Split(new char[]
            {
                '.'
            })[0], false) + ".ltc";
            string text = DataManager.SAVEPATH + "/" + str;
            if (!File.Exists(text) || DataManager.CoverOriginalFile)
            {
                DataManager.saveTextureCubeFile(material, jSONObject7, text);
            }
            FileUtil.saveFile(savePath, jSONObject);
        }

        public static void saveLightMapFile(JSONObject customProps)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            customProps.AddField("lightmaps", jSONObject);
            LightmapData[] lightmaps = LightmapSettings.get_lightmaps();
            if (lightmaps != null && lightmaps.Length != 0)
            {
                for (int i = 0; i < lightmaps.Length; i++)
                {
                    Texture2D lightmapColor = lightmaps[i].get_lightmapColor();
                    if (lightmapColor != null)
                    {
                        string assetPath = AssetDatabase.GetAssetPath(lightmapColor.GetInstanceID());
                        string path = DataManager.SAVEPATH + "/" + Path.GetDirectoryName(assetPath);
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }
                        string text = DataManager.SAVEPATH + "/" + assetPath;
                        if (DataManager.ConvertLightMap)
                        {
                            if (DataManager.ConvertToPNG)
                            {
                                text = text.Split(new char[]
                                {
                                    '.'
                                })[0] + ".png";
                            }
                            else if (DataManager.ConvertToJPG)
                            {
                                text = text.Split(new char[]
                                {
                                    '.'
                                })[0] + ".jpg";
                            }
                            text = DataManager.cleanIllegalChar(text, false);
                            if (!File.Exists(text) || DataManager.CoverOriginalFile)
                            {
                                TextureImporter expr_10B = AssetImporter.GetAtPath(assetPath) as TextureImporter;
                                expr_10B.set_isReadable(true);
                                expr_10B.set_textureCompression(0);
                                AssetDatabase.ImportAsset(assetPath);
                                FileStream expr_128 = File.Open(text, FileMode.Create, FileAccess.ReadWrite);
                                BinaryWriter binaryWriter = new BinaryWriter(expr_128);
                                if (DataManager.ConvertToPNG)
                                {
                                    binaryWriter.Write(lightmapColor.EncodeToPNG());
                                }
                                else if (DataManager.ConvertToJPG)
                                {
                                    binaryWriter.Write(lightmapColor.EncodeToJPG((int)DataManager.ConvertQuality));
                                }
                                else
                                {
                                    binaryWriter.Write(lightmapColor.EncodeToPNG());
                                }
                                expr_128.Close();
                            }
                            if (DataManager.ConvertToPNG)
                            {
                                jSONObject.Add(assetPath.Split(new char[]
                                {
                                    '.'
                                })[0] + ".png");
                            }
                            else if (DataManager.ConvertToJPG)
                            {
                                jSONObject.Add(assetPath.Split(new char[]
                                {
                                    '.'
                                })[0] + ".jpg");
                            }
                        }
                        else
                        {
                            text = DataManager.SAVEPATH + "/" + assetPath;
                            text = DataManager.cleanIllegalChar(text, false);
                            if (!File.Exists(text) || DataManager.CoverOriginalFile)
                            {
                                File.Copy(assetPath, text, true);
                            }
                            jSONObject.Add(assetPath);
                        }
                    }
                }
            }
        }

        public static void saveTextureCubeFile(Material material, JSONObject obj, string savePath)
        {
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            string name = material.get_name();
            if (material.HasProperty("_FrontTex"))
            {
                Texture2D texture = (Texture2D)material.GetTexture("_FrontTex");
                DataManager.saveTextureFile(jSONObject, texture, savePath, name, "front");
            }
            if (material.HasProperty("_BackTex"))
            {
                Texture2D texture2 = (Texture2D)material.GetTexture("_BackTex");
                DataManager.saveTextureFile(jSONObject, texture2, savePath, name, "back");
            }
            if (material.HasProperty("_LeftTex"))
            {
                Texture2D texture3 = (Texture2D)material.GetTexture("_LeftTex");
                DataManager.saveTextureFile(jSONObject, texture3, savePath, name, "left");
            }
            if (material.HasProperty("_RightTex"))
            {
                Texture2D texture4 = (Texture2D)material.GetTexture("_RightTex");
                DataManager.saveTextureFile(jSONObject, texture4, savePath, name, "right");
            }
            if (material.HasProperty("_UpTex"))
            {
                Texture2D texture5 = (Texture2D)material.GetTexture("_UpTex");
                DataManager.saveTextureFile(jSONObject, texture5, savePath, name, "up");
            }
            if (material.HasProperty("_DownTex"))
            {
                Texture2D texture6 = (Texture2D)material.GetTexture("_DownTex");
                DataManager.saveTextureFile(jSONObject, texture6, savePath, name, "down");
            }
            string relativePath = FileUtil.getRelativePath(savePath, savePath);
            obj.AddField("path", relativePath);
            FileUtil.saveFile(savePath, jSONObject);
        }

        public static void saveTextureFile(JSONObject obj, Texture2D texture, string MaterialPath = null, string materialName = null, string nodeName = "path")
        {
            if (!(texture != null))
            {
                obj.AddField(nodeName, "");
                return;
            }
            string assetPath = AssetDatabase.GetAssetPath(texture.GetInstanceID());
            string text = DataManager.SAVEPATH + "/" + Path.GetDirectoryName(assetPath);
            text = DataManager.cleanIllegalChar(text, false);
            if (!Directory.Exists(text))
            {
                Directory.CreateDirectory(text);
            }
            TextureImporter textureImporter = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            string text2 = "";
            string[] array = (DataManager.SAVEPATH + "/" + assetPath).Split(new char[]
            {
                '.'
            });
            for (int i = 0; i < array.Length - 1; i++)
            {
                text2 += array[i];
                if (i < array.Length - 2)
                {
                    text2 += ".";
                }
            }
            if (DataManager.findStrsInCurString(assetPath, DataManager.ConvertOriginalTextureTypeList))
            {
                if (DataManager.ConvertToPNG)
                {
                    text2 += ".png";
                }
                else if (DataManager.ConvertToJPG)
                {
                    text2 += ".jpg";
                }
                text2 = DataManager.cleanIllegalChar(text2, false);
                if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                {
                    textureImporter.set_isReadable(true);
                    textureImporter.set_textureCompression(0);
                    AssetDatabase.ImportAsset(assetPath);
                    FileStream expr_11E = File.Open(text2, FileMode.Create, FileAccess.ReadWrite);
                    BinaryWriter binaryWriter = new BinaryWriter(expr_11E);
                    if (DataManager.ConvertToPNG)
                    {
                        binaryWriter.Write(texture.EncodeToPNG());
                    }
                    else if (DataManager.ConvertToJPG)
                    {
                        binaryWriter.Write(texture.EncodeToJPG((int)DataManager.ConvertQuality));
                    }
                    else
                    {
                        binaryWriter.Write(texture.EncodeToPNG());
                    }
                    expr_11E.Close();
                }
            }
            else
            {
                text2 = DataManager.SAVEPATH + "/" + assetPath;
                text2 = DataManager.cleanIllegalChar(text2, false);
                if (!File.Exists(text2) || DataManager.CoverOriginalFile)
                {
                    if (File.Exists(assetPath))
                    {
                        File.Copy(assetPath, text2, true);
                    }
                    else
                    {
                        Debug.LogWarning("LayaAir3D : " + materialName + "has texture can't find!");
                    }
                }
            }
            if (!File.Exists(assetPath))
            {
                obj.AddField(nodeName, "");
                return;
            }
            string relativePath = FileUtil.getRelativePath(MaterialPath, text2);
            obj.AddField(nodeName, relativePath);
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            obj.AddField("params", jSONObject);
            if (textureImporter != null)
            {
                jSONObject.AddField("mipmap", textureImporter.get_mipmapEnabled());
            }
            else
            {
                jSONObject.AddField("mipmap", false);
            }
            if (texture.get_filterMode() == null)
            {
                jSONObject.AddField("filterMode", 0);
            }
            else if (texture.get_filterMode() == 1)
            {
                jSONObject.AddField("filterMode", 1);
            }
            else if (texture.get_filterMode() == 2)
            {
                jSONObject.AddField("filterMode", 2);
            }
            else
            {
                jSONObject.AddField("filterMode", 1);
            }
            if (texture.get_wrapMode() == null)
            {
                jSONObject.AddField("wrapModeU", 0);
                jSONObject.AddField("wrapModeV", 0);
            }
            else if (texture.get_wrapMode() == 1)
            {
                jSONObject.AddField("wrapModeU", 1);
                jSONObject.AddField("wrapModeV", 1);
            }
            else
            {
                jSONObject.AddField("wrapModeU", 0);
                jSONObject.AddField("wrapModeV", 0);
            }
            if (textureImporter != null)
            {
                jSONObject.AddField("anisoLevel", texture.get_anisoLevel());
            }
            else
            {
                jSONObject.AddField("anisoLevel", 0);
            }
            if (texture.get_format().ToString() == "DXT1")
            {
                jSONObject.AddField("format", 0);
                return;
            }
            if (texture.get_format().ToString() == "DXT5")
            {
                jSONObject.AddField("format", 1);
                return;
            }
            jSONObject.AddField("format", 1);
        }

        public static void saveLaniData(GameObject gameObject, JSONObject obj)
        {
            List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject);
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            dictionary.Add("UnityEngine.Transform", "transform");
            dictionary.Add("UnityEngine.MeshRenderer", "meshRenderer");
            dictionary.Add("UnityEngine.SkinnedMeshRenderer", "skinnedMeshRender");
            dictionary.Add("UnityEngine.ParticleSystemRenderer", "particleRender");
            Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
            dictionary2.Add("m_LocalPosition", "localPosition");
            dictionary2.Add("m_LocalRotation", "localRotation");
            dictionary2.Add("m_LocalScale", "localScale");
            dictionary2.Add("localEulerAnglesRaw", "localRotationEuler");
            dictionary2.Add("material._MainTex_ST", "meshRender.sharedMaterial.tilingOffset|skinnedMeshRender.sharedMaterial.tilingOffset|particleRender.sharedMaterial.tilingOffset");
            dictionary2.Add("material._TintColor", "meshRender.sharedMaterial.albedoColor|skinnedMeshRender.sharedMaterial.albedoColor|particleRender.sharedMaterial.tintColor");
            dictionary2.Add("material._Color", "meshRender.sharedMaterial.albedoColor|skinnedMeshRender.sharedMaterial.albedoColor|particleRender.sharedMaterial.tintColor");
            dictionary2.Add("material._SpecularColor", "meshRender.sharedMaterial.specularColor|skinnedMeshRender.sharedMaterial.specularColor");
            Dictionary<string, byte> dictionary3 = new Dictionary<string, byte>();
            dictionary3.Add("m_LocalPosition", 12);
            dictionary3.Add("m_LocalRotation", 16);
            dictionary3.Add("m_LocalScale", 12);
            dictionary3.Add("localEulerAnglesRaw", 12);
            dictionary3.Add("material._MainTex_ST", 16);
            dictionary3.Add("material._TintColor", 16);
            dictionary3.Add("material._Color", 16);
            dictionary3.Add("material._SpecularColor", 16);
            Dictionary<string, int> dictionary4 = new Dictionary<string, int>();
            dictionary4.Add("m_LocalPosition", 3);
            dictionary4.Add("m_LocalRotation", 4);
            dictionary4.Add("m_LocalScale", 3);
            dictionary4.Add("localEulerAnglesRaw", 3);
            dictionary4.Add("material._MainTex_ST", 4);
            dictionary4.Add("material._TintColor", 4);
            dictionary4.Add("material._Color", 4);
            dictionary4.Add("material._SpecularColor", 4);
            List<string> list2 = new List<string>();
            list2.Add("x");
            list2.Add("y");
            list2.Add("z");
            List<string> list3 = new List<string>();
            list3.Add("x");
            list3.Add("y");
            list3.Add("z");
            list3.Add("w");
            List<string> list4 = new List<string>();
            list4.Add("r");
            list4.Add("g");
            list4.Add("b");
            list4.Add("a");
            Dictionary<string, List<string>> dictionary5 = new Dictionary<string, List<string>>();
            dictionary5.Add("m_LocalPosition", list2);
            dictionary5.Add("m_LocalRotation", list3);
            dictionary5.Add("m_LocalScale", list2);
            dictionary5.Add("localEulerAnglesRaw", list2);
            dictionary5.Add("material._MainTex_ST", list3);
            dictionary5.Add("material._TintColor", list4);
            dictionary5.Add("material._Color", list4);
            dictionary5.Add("material._SpecularColor", list4);
            List<ushort> list5 = new List<ushort>();
            list5.Add(12);
            list5.Add(16);
            RuntimeAnimatorController runtimeAnimatorController = gameObject.GetComponent<Animator>().get_runtimeAnimatorController();
            if (runtimeAnimatorController == null)
            {
                Debug.LogWarning("LayaUnityPlugin : " + gameObject.get_name() + "'s Animator Compoment must have a Controller!");
                return;
            }
            AnimationClip[] animationClips = runtimeAnimatorController.get_animationClips();
            for (int i = 0; i < animationClips.Length; i++)
            {
                AnimationClip animationClip = animationClips[i];
                List<double> list6 = new List<double>();
                List<string> list7 = new List<string>();
                list7.Add("ANIMATIONS");
                if (animationClip != null)
                {
                    string arg_350_0 = gameObject.get_name();
                    int num = (int)animationClip.get_frameRate();
                    string text = DataManager.cleanIllegalChar(animationClip.get_name(), true);
                    list7.Add(text);
                    string text2 = DataManager.cleanIllegalChar(AssetDatabase.GetAssetPath(animationClip.GetInstanceID()).Split(new char[]
                    {
                        '.'
                    })[0], false) + "-" + text + ".lani";
                    string text3 = DataManager.SAVEPATH + "/" + text2;
                    if (!File.Exists(text3) || DataManager.CoverOriginalFile)
                    {
                        obj.Add(text2);
                        EditorCurveBinding[] curveBindings = AnimationUtility.GetCurveBindings(animationClip);
                        AnimationClipCurveData[] array = new AnimationClipCurveData[curveBindings.Length];
                        for (int j = 0; j < curveBindings.Length; j++)
                        {
                            array[j] = new AnimationClipCurveData(curveBindings[j]);
                            array[j].curve = AnimationUtility.GetEditorCurve(animationClip, curveBindings[j]);
                            for (int k = 0; k < array[j].curve.get_keys().Length; k++)
                            {
                                AnimationUtility.SetKeyLeftTangentMode(array[j].curve, k, 2);
                            }
                        }
                        for (int l = 0; l < array.Length; l++)
                        {
                            Keyframe[] keys = array[l].curve.get_keys();
                            for (int m = 0; m < keys.Length; m++)
                            {
                                double item = Math.Round((double)keys[m].get_time(), 3);
                                if (list6.IndexOf(item) == -1)
                                {
                                    list6.Add(item);
                                }
                            }
                        }
                        list6.Sort();
                        List<string> list8 = new List<string>();
                        List<DataManager.CustomAnimationClipCurveData> list9 = new List<DataManager.CustomAnimationClipCurveData>();
                        for (int n = 0; n < array.Length; n++)
                        {
                            AnimationClipCurveData animationClipCurveData = array[n];
                            DataManager.CustomAnimationCurve curve;
                            curve.keys = animationClipCurveData.curve.get_keys();
                            DataManager.CustomAnimationClipCurveData item2;
                            item2.curve = curve;
                            item2.path = animationClipCurveData.path;
                            item2.propertyName = animationClipCurveData.propertyName;
                            item2.type = animationClipCurveData.type;
                            list9.Add(item2);
                        }
                        List<DataManager.CustomAnimationClipCurveData> list10 = new List<DataManager.CustomAnimationClipCurveData>();
                        List<DataManager.CustomAnimationClipCurveData> list11 = new List<DataManager.CustomAnimationClipCurveData>();
                        for (int num2 = 0; num2 < array.Length; num2++)
                        {
                            AnimationClipCurveData animationClipCurveData2 = array[num2];
                            DataManager.CustomAnimationCurve curve2;
                            curve2.keys = animationClipCurveData2.curve.get_keys();
                            DataManager.CustomAnimationClipCurveData customAnimationClipCurveData;
                            customAnimationClipCurveData.curve = curve2;
                            customAnimationClipCurveData.path = animationClipCurveData2.path;
                            customAnimationClipCurveData.propertyName = animationClipCurveData2.propertyName;
                            customAnimationClipCurveData.type = animationClipCurveData2.type;
                            if (customAnimationClipCurveData.propertyName.IndexOf(".") != -1)
                            {
                                string text4 = customAnimationClipCurveData.propertyName.Substring(0, customAnimationClipCurveData.propertyName.LastIndexOf('.'));
                                string path = customAnimationClipCurveData.path;
                                string item3 = text4 + "|" + path;
                                if (list8.IndexOf(item3) == -1)
                                {
                                    list8.Add(item3);
                                    list10 = new List<DataManager.CustomAnimationClipCurveData>();
                                    for (int num3 = 0; num3 < dictionary5[text4].Count; num3++)
                                    {
                                        string b = text4 + "." + dictionary5[text4][num3];
                                        for (int num4 = 0; num4 < list9.Count; num4++)
                                        {
                                            if (list9[num4].propertyName == b && list9[num4].path == path)
                                            {
                                                list10.Add(list9[num4]);
                                                list9.RemoveAt(list9.IndexOf(list9[num4]));
                                            }
                                        }
                                    }
                                    if (dictionary5[text4].Count != list10.Count)
                                    {
                                        List<DataManager.CustomAnimationClipCurveData> list12 = new List<DataManager.CustomAnimationClipCurveData>();
                                        for (int num5 = 0; num5 < dictionary5[text4].Count; num5++)
                                        {
                                            string text5 = text4 + "." + dictionary5[text4][num5];
                                            bool flag = false;
                                            for (int num6 = 0; num6 < list10.Count; num6++)
                                            {
                                                if (list10[num6].propertyName == text5)
                                                {
                                                    flag = true;
                                                    list12.Add(list10[num6]);
                                                }
                                            }
                                            if (!flag)
                                            {
                                                DataManager.CustomAnimationCurve curve3;
                                                curve3.keys = new Keyframe[0];
                                                DataManager.CustomAnimationClipCurveData item4;
                                                item4.path = list10[0].path;
                                                item4.propertyName = text5;
                                                item4.type = list10[0].type;
                                                item4.curve = curve3;
                                                list12.Add(item4);
                                            }
                                        }
                                        list10 = list12;
                                    }
                                    List<double> list13 = new List<double>();
                                    for (int num7 = 0; num7 < list10.Count; num7++)
                                    {
                                        Keyframe[] keys2 = list10[num7].curve.keys;
                                        for (int num8 = 0; num8 < keys2.Length; num8++)
                                        {
                                            bool flag2 = false;
                                            for (int num9 = 0; num9 < list13.Count; num9++)
                                            {
                                                if (Math.Round(list13[num9], 3) == Math.Round((double)keys2[num8].get_time(), 3))
                                                {
                                                    flag2 = true;
                                                }
                                            }
                                            if (!flag2)
                                            {
                                                list13.Add((double)keys2[num8].get_time());
                                            }
                                        }
                                    }
                                    list13.Sort();
                                    List<Keyframe> list14 = new List<Keyframe>();
                                    for (int num10 = 0; num10 < list13.Count; num10++)
                                    {
                                        Keyframe item5 = default(Keyframe);
                                        item5.set_inTangent(float.NaN);
                                        item5.set_outTangent(float.NaN);
                                        item5.set_time((float)list13[num10]);
                                        item5.set_value(float.NaN);
                                        list14.Add(item5);
                                    }
                                    for (int num11 = 0; num11 < list10.Count; num11++)
                                    {
                                        List<Keyframe> list15 = list10[num11].curve.keys.ToList<Keyframe>();
                                        List<Keyframe> list16 = new List<Keyframe>();
                                        for (int num12 = 0; num12 < list13.Count; num12++)
                                        {
                                            bool flag3 = false;
                                            for (int num13 = 0; num13 < list15.Count; num13++)
                                            {
                                                if (Math.Round((double)list15[num13].get_time(), 3) == Math.Round(list13[num12], 3))
                                                {
                                                    flag3 = true;
                                                    list16.Add(list15[num13]);
                                                }
                                            }
                                            if (!flag3)
                                            {
                                                list16.Add(list14[num12]);
                                            }
                                        }
                                        for (int num14 = 0; num14 < list13.Count; num14++)
                                        {
                                            if (float.IsNaN(list16[num14].get_value()))
                                            {
                                                bool flag4 = false;
                                                bool flag5 = false;
                                                int index = -1;
                                                int index2 = -1;
                                                for (int num15 = num14 - 1; num15 >= 0; num15--)
                                                {
                                                    if (!float.IsNaN(list16[num15].get_value()))
                                                    {
                                                        flag4 = true;
                                                        index = num15;
                                                        break;
                                                    }
                                                }
                                                for (int num16 = num14 + 1; num16 < list13.Count; num16++)
                                                {
                                                    if (!float.IsNaN(list16[num16].get_value()))
                                                    {
                                                        flag5 = true;
                                                        index2 = num16;
                                                        break;
                                                    }
                                                }
                                                if (flag4 & flag5)
                                                {
                                                    float num17 = list16[index2].get_time() - list16[index].get_time();
                                                    float t = (float)((list13[num14] - list13[index]) / (list13[index2] - list13[index]));
                                                    float num18;
                                                    float value = MathUtil.Interpolate((float)list13[index], (float)list13[index2], list16[index].get_value(), list16[index2].get_value(), list16[index].get_outTangent() * num17, list16[index2].get_inTangent() * num17, t, out num18);
                                                    Keyframe value2 = default(Keyframe);
                                                    float inTangent;
                                                    value2.set_outTangent(inTangent = num18);
                                                    value2.set_inTangent(inTangent);
                                                    value2.set_value(value);
                                                    value2.set_time((float)list13[num14]);
                                                    list16[num14] = value2;
                                                }
                                                else if (flag4 && !flag5)
                                                {
                                                    Keyframe value3 = default(Keyframe);
                                                    float inTangent;
                                                    value3.set_outTangent(inTangent = 0f);
                                                    value3.set_inTangent(inTangent);
                                                    value3.set_value(list16[index].get_value());
                                                    value3.set_time((float)list13[num14]);
                                                    list16[num14] = value3;
                                                }
                                                else if (!flag4 & flag5)
                                                {
                                                    Keyframe value4 = default(Keyframe);
                                                    float inTangent;
                                                    value4.set_outTangent(inTangent = 0f);
                                                    value4.set_inTangent(inTangent);
                                                    value4.set_value(list16[index2].get_value());
                                                    value4.set_time((float)list13[num14]);
                                                    list16[num14] = value4;
                                                }
                                                else
                                                {
                                                    Debug.LogWarning(string.Concat(new string[]
                                                    {
                                                        gameObject.get_name(),
                                                        "'s Animator ",
                                                        gameObject.get_name(),
                                                        "/",
                                                        list10[num11].path,
                                                        " ",
                                                        list10[num11].propertyName,
                                                        " keyFrame data can't be null!"
                                                    }));
                                                }
                                            }
                                        }
                                        DataManager.CustomAnimationCurve curve4;
                                        curve4.keys = list16.ToArray();
                                        DataManager.CustomAnimationClipCurveData value5;
                                        value5.curve = curve4;
                                        value5.path = list10[num11].path;
                                        value5.propertyName = list10[num11].propertyName;
                                        value5.type = list10[num11].type;
                                        list10[num11] = value5;
                                    }
                                    for (int num19 = 0; num19 < list10.Count; num19++)
                                    {
                                        list11.Add(list10[num19]);
                                    }
                                }
                            }
                        }
                        List<DataManager.AniNodeData> list17 = new List<DataManager.AniNodeData>();
                        short conpomentTypeIndex = -1;
                        int num23;
                        for (int num20 = 0; num20 < list11.Count; num20 += num23)
                        {
                            DataManager.CustomAnimationClipCurveData customAnimationClipCurveData2 = list11[num20];
                            int num21 = 0;
                            List<ushort> list18 = new List<ushort>();
                            string[] array2 = customAnimationClipCurveData2.path.Split(new char[]
                            {
                                '/'
                            });
                            for (int num22 = 0; num22 < array2.Length; num22++)
                            {
                                if (list7.IndexOf(array2[num22]) == -1)
                                {
                                    list7.Add(array2[num22]);
                                }
                                list18.Add((ushort)list7.IndexOf(array2[num22]));
                            }
                            DataManager.AniNodeData aniNodeData;
                            aniNodeData.pathLength = (ushort)list18.Count;
                            aniNodeData.pathIndex = list18;
                            string a = dictionary[customAnimationClipCurveData2.type.ToString()];
                            aniNodeData.conpomentTypeIndex = conpomentTypeIndex;
                            string text6 = customAnimationClipCurveData2.propertyName.Substring(0, customAnimationClipCurveData2.propertyName.LastIndexOf('.'));
                            num23 = dictionary4[text6];
                            byte item6 = dictionary3[text6];
                            if (a == "meshRenderer")
                            {
                                text6 = dictionary2[text6].Split(new char[]
                                {
                                    '|'
                                })[0];
                            }
                            else if (a == "skinnedMeshRender")
                            {
                                text6 = dictionary2[text6].Split(new char[]
                                {
                                    '|'
                                })[1];
                            }
                            else if (a == "particleRender")
                            {
                                text6 = dictionary2[text6].Split(new char[]
                                {
                                    '|'
                                })[2];
                            }
                            else
                            {
                                text6 = dictionary2[text6];
                            }
                            if (list7.IndexOf(text6) == -1)
                            {
                                list7.Add(text6);
                            }
                            ushort propertyNameIndex = (ushort)list7.IndexOf(text6);
                            aniNodeData.propertyNameIndex = propertyNameIndex;
                            aniNodeData.frameDataLengthIndex = (byte)list5.IndexOf((ushort)item6);
                            List<DataManager.AniNodeFrameData> list19 = new List<DataManager.AniNodeFrameData>();
                            Keyframe[] keys3 = customAnimationClipCurveData2.curve.keys;
                            for (int num24 = 0; num24 < keys3.Length; num24++)
                            {
                                float time = keys3[num24].get_time();
                                DataManager.AniNodeFrameData item7;
                                item7.startTimeIndex = (ushort)list6.IndexOf(Math.Round((double)time, 3));
                                List<float> list20 = new List<float>();
                                List<float> list21 = new List<float>();
                                List<float> list22 = new List<float>();
                                int num25 = 0;
                                for (int num26 = num20; num26 < num20 + num23; num26++)
                                {
                                    Keyframe keyframe = list11[num26].curve.keys[num24];
                                    if (text6 == "localPosition")
                                    {
                                        if (num25 == 0)
                                        {
                                            list20.Add(keyframe.get_value() * -1f);
                                            list21.Add(keyframe.get_inTangent() * -1f);
                                            list22.Add(keyframe.get_outTangent() * -1f);
                                        }
                                        else
                                        {
                                            list20.Add(keyframe.get_value());
                                            list21.Add(keyframe.get_inTangent());
                                            list22.Add(keyframe.get_outTangent());
                                        }
                                    }
                                    else if (text6 == "localRotation")
                                    {
                                        if (num25 == 0 || num25 == 3)
                                        {
                                            list20.Add(keyframe.get_value() * -1f);
                                            list21.Add(keyframe.get_inTangent() * -1f);
                                            list22.Add(keyframe.get_outTangent() * -1f);
                                        }
                                        else
                                        {
                                            list20.Add(keyframe.get_value());
                                            list21.Add(keyframe.get_inTangent());
                                            list22.Add(keyframe.get_outTangent());
                                        }
                                    }
                                    else if (text6 == "localRotationEuler")
                                    {
                                        if (list.IndexOf(DataManager.ComponentType.Camera) != -1)
                                        {
                                            if (num25 == 0)
                                            {
                                                list20.Add(keyframe.get_value() * -1f);
                                                list21.Add(keyframe.get_inTangent() * -1f);
                                                list22.Add(keyframe.get_outTangent() * -1f);
                                            }
                                            else if (num25 == 1)
                                            {
                                                list20.Add(180f - keyframe.get_value());
                                                list21.Add(keyframe.get_inTangent() * -1f);
                                                list22.Add(keyframe.get_outTangent() * -1f);
                                            }
                                            else
                                            {
                                                list20.Add(keyframe.get_value());
                                                list21.Add(keyframe.get_inTangent());
                                                list22.Add(keyframe.get_outTangent());
                                            }
                                        }
                                        else if (num25 == 1 || num25 == 2)
                                        {
                                            list20.Add(keyframe.get_value() * -1f);
                                            list21.Add(keyframe.get_inTangent() * -1f);
                                            list22.Add(keyframe.get_outTangent() * -1f);
                                        }
                                        else
                                        {
                                            list20.Add(keyframe.get_value());
                                            list21.Add(keyframe.get_inTangent());
                                            list22.Add(keyframe.get_outTangent());
                                        }
                                    }
                                    else if (text6 == "meshRender.sharedMaterial.tilingOffset" || text6 == "skinnedMeshRender.sharedMaterial.tilingOffset" || text6 == "particleRender.sharedMaterial.tilingOffset")
                                    {
                                        if (num25 == 3)
                                        {
                                            list20.Add(keyframe.get_value() * -1f);
                                            list21.Add(keyframe.get_inTangent() * -1f);
                                            list22.Add(keyframe.get_outTangent() * -1f);
                                        }
                                        else
                                        {
                                            list20.Add(keyframe.get_value());
                                            list21.Add(keyframe.get_inTangent());
                                            list22.Add(keyframe.get_outTangent());
                                        }
                                    }
                                    else if (text6 == "meshRender.sharedMaterial.albedoColor" || text6 == "skinnedMeshRender.sharedMaterial.albedoColor")
                                    {
                                        list20.Add(keyframe.get_value() * DataManager.ScaleFactor);
                                        list21.Add(keyframe.get_inTangent());
                                        list22.Add(keyframe.get_outTangent());
                                    }
                                    else
                                    {
                                        list20.Add(keyframe.get_value());
                                        list21.Add(keyframe.get_inTangent());
                                        list22.Add(keyframe.get_outTangent());
                                    }
                                    num25++;
                                }
                                item7.valueNumbers = list20;
                                item7.inTangentNumbers = list21;
                                item7.outTangentNumbers = list22;
                                list19.Add(item7);
                            }
                            aniNodeData.keyFrameCount = (ushort)(keys3.Length + num21);
                            aniNodeData.aniNodeFrameDatas = list19;
                            list17.Add(aniNodeData);
                        }
                        FileStream fileStream = FileUtil.saveFile(text3, null);
                        string data = "LAYAANIMATION:02";
                        FileUtil.WriteData(fileStream, data);
                        long position = fileStream.Position;
                        FileUtil.WriteData(fileStream, new uint[1]);
                        FileUtil.WriteData(fileStream, new uint[1]);
                        long position2 = fileStream.Position;
                        int num27 = 1;
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)num27
                        });
                        for (int num28 = 0; num28 < num27; num28++)
                        {
                            FileUtil.WriteData(fileStream, new uint[1]);
                            FileUtil.WriteData(fileStream, new uint[1]);
                        }
                        long position3 = fileStream.Position;
                        FileUtil.WriteData(fileStream, new uint[1]);
                        FileUtil.WriteData(fileStream, new ushort[1]);
                        long position4 = fileStream.Position;
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list7.IndexOf("ANIMATIONS")
                        });
                        FileUtil.WriteData(fileStream, new byte[]
                        {
                            (byte)list5.Count
                        });
                        for (int num29 = 0; num29 < list5.Count; num29++)
                        {
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                list5[num29]
                            });
                        }
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list6.Count
                        });
                        for (int num30 = 0; num30 < list6.Count; num30++)
                        {
                            FileUtil.WriteData(fileStream, new float[]
                            {
                                (float)list6[num30]
                            });
                        }
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list7.IndexOf(text)
                        });
                        FileUtil.WriteData(fileStream, new float[]
                        {
                            (float)list6[list6.Count - 1]
                        });
                        FileUtil.WriteData(fileStream, new bool[]
                        {
                            animationClip.get_isLooping()
                        });
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)num
                        });
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list17.Count
                        });
                        for (int num31 = 0; num31 < list17.Count; num31++)
                        {
                            DataManager.AniNodeData aniNodeData = list17[num31];
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                aniNodeData.pathLength
                            });
                            for (int num32 = 0; num32 < (int)aniNodeData.pathLength; num32++)
                            {
                                FileUtil.WriteData(fileStream, new ushort[]
                                {
                                    aniNodeData.pathIndex[num32]
                                });
                            }
                            FileUtil.WriteData(fileStream, new short[]
                            {
                                aniNodeData.conpomentTypeIndex
                            });
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                aniNodeData.propertyNameIndex
                            });
                            FileUtil.WriteData(fileStream, new byte[]
                            {
                                aniNodeData.frameDataLengthIndex
                            });
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                aniNodeData.keyFrameCount
                            });
                            for (int num33 = 0; num33 < (int)aniNodeData.keyFrameCount; num33++)
                            {
                                FileUtil.WriteData(fileStream, new ushort[]
                                {
                                    aniNodeData.aniNodeFrameDatas[num33].startTimeIndex
                                });
                                List<float> valueNumbers = aniNodeData.aniNodeFrameDatas[num33].valueNumbers;
                                List<float> inTangentNumbers = aniNodeData.aniNodeFrameDatas[num33].inTangentNumbers;
                                List<float> outTangentNumbers = aniNodeData.aniNodeFrameDatas[num33].outTangentNumbers;
                                for (int num34 = 0; num34 < inTangentNumbers.Count; num34++)
                                {
                                    FileUtil.WriteData(fileStream, new float[]
                                    {
                                        inTangentNumbers[num34]
                                    });
                                }
                                for (int num35 = 0; num35 < outTangentNumbers.Count; num35++)
                                {
                                    FileUtil.WriteData(fileStream, new float[]
                                    {
                                        outTangentNumbers[num35]
                                    });
                                }
                                for (int num36 = 0; num36 < valueNumbers.Count; num36++)
                                {
                                    FileUtil.WriteData(fileStream, new float[]
                                    {
                                        valueNumbers[num36]
                                    });
                                }
                            }
                        }
                        AnimationEvent[] events = animationClip.get_events();
                        int num37 = events.Length;
                        FileUtil.WriteData(fileStream, new short[]
                        {
                            (short)num37
                        });
                        for (int num38 = 0; num38 < num37; num38++)
                        {
                            AnimationEvent animationEvent = events[num38];
                            FileUtil.WriteData(fileStream, new float[]
                            {
                                animationEvent.get_time()
                            });
                            string functionName = animationEvent.get_functionName();
                            if (list7.IndexOf(functionName) == -1)
                            {
                                list7.Add(functionName);
                            }
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                (ushort)list7.IndexOf(functionName)
                            });
                            ushort num39 = 3;
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                num39
                            });
                            for (int num40 = 0; num40 < 1; num40++)
                            {
                                FileUtil.WriteData(fileStream, new byte[]
                                {
                                    2
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    animationEvent.get_floatParameter()
                                });
                                FileUtil.WriteData(fileStream, new byte[]
                                {
                                    1
                                });
                                FileUtil.WriteData(fileStream, new int[]
                                {
                                    animationEvent.get_intParameter()
                                });
                                FileUtil.WriteData(fileStream, new byte[]
                                {
                                    3
                                });
                                string stringParameter = animationEvent.get_stringParameter();
                                if (list7.IndexOf(stringParameter) == -1)
                                {
                                    list7.Add(stringParameter);
                                }
                                FileUtil.WriteData(fileStream, new ushort[]
                                {
                                    (ushort)list7.IndexOf(stringParameter)
                                });
                            }
                        }
                        long position5 = fileStream.Position;
                        for (int num41 = 0; num41 < list7.Count; num41++)
                        {
                            FileUtil.WriteData(fileStream, list7[num41]);
                        }
                        long position6 = fileStream.Position;
                        fileStream.Position = position3 + 4L;
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list7.Count
                        });
                        fileStream.Position = position2 + 2L + 4L;
                        FileUtil.WriteData(fileStream, new uint[]
                        {
                            (uint)(position5 - position4)
                        });
                        fileStream.Position = position;
                        FileUtil.WriteData(fileStream, new uint[]
                        {
                            (uint)position5
                        });
                        FileUtil.WriteData(fileStream, new uint[]
                        {
                            (uint)(position6 - position5)
                        });
                        fileStream.Close();
                    }
                }
            }
        }

        public static void saveLsaniData(GameObject gameObject)
        {
            Transform transform = gameObject.get_transform();
            Animation component = gameObject.GetComponent<Animation>();
            List<Transform> list = new List<Transform>();
            list.Add(transform);
            List<Transform> list2 = new List<Transform>();
            list2.Add(transform);
            Transform[] componentsInChildren = component.get_gameObject().GetComponentsInChildren<Transform>();
            for (int i = 0; i < componentsInChildren.Length; i++)
            {
                Transform transform2 = componentsInChildren[i];
                if (list.IndexOf(transform2) == -1 && DataManager.componentsOnGameObject(transform2.get_gameObject()).Count <= 1)
                {
                    list.Add(transform2);
                    list2.Add(transform2);
                }
            }
            if (DataManager.SimplifyBone)
            {
                List<Transform> list3 = new List<Transform>();
                SkinnedMeshRenderer[] componentsInChildren2 = gameObject.GetComponentsInChildren<SkinnedMeshRenderer>();
                for (int j = 0; j < componentsInChildren2.Length; j++)
                {
                    SkinnedMeshRenderer skinnedMeshRenderer = componentsInChildren2[j];
                    for (int k = 0; k < skinnedMeshRenderer.get_bones().Length; k++)
                    {
                        Transform item = skinnedMeshRenderer.get_bones()[k];
                        if (list3.IndexOf(item) == -1)
                        {
                            list3.Add(item);
                        }
                    }
                }
                List<Transform> list4 = new List<Transform>();
                for (int l = 0; l < list.Count; l++)
                {
                    list4.Add(list[l]);
                }
                for (int m = 0; m < list4.Count; m++)
                {
                    Transform transform3 = list4[m];
                    for (int n = 0; n < list3.Count; n++)
                    {
                        Transform skinBone = list3[n];
                        if (DataManager.checkChildBoneIsLegal(gameObject.get_transform(), transform3, skinBone, list4.Count))
                        {
                            break;
                        }
                        if (n == list3.Count - 1)
                        {
                            list.Remove(transform3);
                        }
                    }
                }
            }
            List<int> list5 = new List<int>();
            list5.Add(-1);
            for (int num = 1; num < list.Count; num++)
            {
                list5.Add(list.IndexOf(list[num].get_parent().get_transform()));
            }
            foreach (AnimationState animationState in component)
            {
                List<string> list6 = new List<string>();
                list6.Add("ANIMATIONS");
                for (int num2 = 0; num2 < list.Count; num2++)
                {
                    list6.Add(list[num2].get_name());
                }
                AnimationClip clip = animationState.get_clip();
                if (clip != null)
                {
                    string arg_23B_0 = gameObject.get_name();
                    int num3 = (int)animationState.get_clip().get_frameRate();
                    string name = clip.get_name();
                    list6.Add(name);
                    string assetPath = AssetDatabase.GetAssetPath(clip.GetInstanceID());
                    string text = string.Concat(new string[]
                    {
                        DataManager.SAVEPATH,
                        "/",
                        assetPath.Split(new char[]
                        {
                            '.'
                        })[0],
                        "-",
                        name,
                        ".lsani"
                    });
                    if (!File.Exists(text) || DataManager.CoverOriginalFile)
                    {
                        List<int> list7 = new List<int>();
                        EditorCurveBinding[] curveBindings = AnimationUtility.GetCurveBindings(clip);
                        AnimationCurve[] array = new AnimationCurve[curveBindings.Length];
                        for (int num4 = 0; num4 < curveBindings.Length; num4++)
                        {
                            array[num4] = AnimationUtility.GetEditorCurve(clip, curveBindings[num4]);
                        }
                        AnimationCurve[] array2 = array;
                        for (int num5 = 0; num5 < array2.Length; num5++)
                        {
                            Keyframe[] keys = array2[num5].get_keys();
                            for (int num6 = 0; num6 < keys.Length; num6++)
                            {
                                Keyframe keyframe = keys[num6];
                                int item2 = (int)Math.Floor((double)(keyframe.get_time() * (float)num3));
                                if (list7.IndexOf(item2) == -1)
                                {
                                    list7.Add(item2);
                                }
                            }
                        }
                        list7.Sort();
                        Dictionary<int, List<DataManager.FrameData>> dictionary = new Dictionary<int, List<DataManager.FrameData>>();
                        Dictionary<int, List<float>> dictionary2 = new Dictionary<int, List<float>>();
                        animationState.set_enabled(true);
                        animationState.set_weight(1f);
                        animationState.set_speed(1f);
                        int num7 = list7[list7.Count - 1];
                        float num8 = (float)num7 * 1000f / 30f;
                        float num9 = 33.3333321f;
                        Matrix4x4 matrix4x = default(Matrix4x4);
                        for (int num10 = 0; num10 < list7.Count; num10++)
                        {
                            int num11 = list7[num10];
                            animationState.set_normalizedTime((float)num11 / (float)num7);
                            component.Sample();
                            Transform[] array3 = list2.ToArray();
                            for (int num12 = 0; num12 < array3.Length; num12++)
                            {
                                Transform transform4 = array3[num12];
                                if (list.IndexOf(transform4) != -1)
                                {
                                    matrix4x.SetTRS(new Vector3(0f, 0f, 0f), transform4.get_localRotation(), new Vector3(1f, 1f, 1f));
                                    matrix4x = matrix4x.get_inverse();
                                    Quaternion quaternion = Quaternion.LookRotation(matrix4x.GetColumn(2), matrix4x.GetColumn(1));
                                    DataManager.FrameData item3;
                                    item3.localPosition = quaternion * transform4.get_localPosition();
                                    item3.localRotation = transform4.get_localRotation();
                                    item3.localScale = transform4.get_localScale();
                                    if (num10 == 0)
                                    {
                                        List<DataManager.FrameData> list8 = new List<DataManager.FrameData>();
                                        List<float> list9 = new List<float>();
                                        list8.Add(item3);
                                        list9.Add(0f);
                                        dictionary.Add(list.IndexOf(transform4), list8);
                                        dictionary2.Add(list.IndexOf(transform4), list9);
                                    }
                                    foreach (KeyValuePair<int, List<DataManager.FrameData>> current in dictionary)
                                    {
                                        if (current.Key == list.IndexOf(transform4))
                                        {
                                            current.Value.Add(item3);
                                            dictionary2[list.IndexOf(transform4)].Add((float)num11 * num9);
                                        }
                                    }
                                    if (num10 == list7.Count - 1)
                                    {
                                        foreach (KeyValuePair<int, List<DataManager.FrameData>> current2 in dictionary)
                                        {
                                            if (current2.Key == list.IndexOf(transform4))
                                            {
                                                List<DataManager.FrameData> value = current2.Value;
                                                List<float> list10 = dictionary2[list.IndexOf(transform4)];
                                                if (num8 != list10[list10.Count - 1])
                                                {
                                                    value.Add(item3);
                                                    list10.Add(num8);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        foreach (KeyValuePair<int, List<DataManager.FrameData>> current3 in dictionary)
                        {
                            int key = current3.Key;
                            List<DataManager.FrameData> value2 = current3.Value;
                            List<float> list11 = dictionary2[key];
                            for (int num13 = 1; num13 < value2.Count - 1; num13++)
                            {
                                if (DataManager.frameDataIsEquals(value2[num13], value2[num13 - 1]) && DataManager.frameDataIsEquals(value2[num13], value2[num13 + 1]))
                                {
                                    value2.RemoveAt(num13);
                                    list11.RemoveAt(num13);
                                }
                            }
                        }
                        animationState.set_enabled(false);
                        animationState.set_normalizedTime(0f);
                        component.Sample();
                        FileStream fileStream = FileUtil.saveFile(text, null);
                        string data = "LAYAANIMATION:02";
                        FileUtil.WriteData(fileStream, data);
                        long position = fileStream.Position;
                        FileUtil.WriteData(fileStream, new uint[1]);
                        FileUtil.WriteData(fileStream, new uint[1]);
                        long position2 = fileStream.Position;
                        int num14 = 1;
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)num14
                        });
                        for (int num15 = 0; num15 < num14; num15++)
                        {
                            FileUtil.WriteData(fileStream, new uint[1]);
                            FileUtil.WriteData(fileStream, new uint[1]);
                        }
                        long arg_78C_0 = fileStream.Position;
                        FileUtil.WriteData(fileStream, new uint[1]);
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list6.Count
                        });
                        long position3 = fileStream.Position;
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list6.IndexOf("ANIMATIONS")
                        });
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            10
                        });
                        FileUtil.WriteData(fileStream, new sbyte[1]);
                        FileUtil.WriteData(fileStream, new sbyte[1]);
                        FileUtil.WriteData(fileStream, new sbyte[1]);
                        FileUtil.WriteData(fileStream, new sbyte[]
                        {
                            1
                        });
                        FileUtil.WriteData(fileStream, new sbyte[]
                        {
                            1
                        });
                        FileUtil.WriteData(fileStream, new sbyte[]
                        {
                            1
                        });
                        FileUtil.WriteData(fileStream, new sbyte[]
                        {
                            1
                        });
                        FileUtil.WriteData(fileStream, new sbyte[1]);
                        FileUtil.WriteData(fileStream, new sbyte[1]);
                        FileUtil.WriteData(fileStream, new sbyte[1]);
                        FileUtil.WriteData(fileStream, new byte[]
                        {
                            1
                        });
                        FileUtil.WriteData(fileStream, new ushort[]
                        {
                            (ushort)list6.IndexOf(name)
                        });
                        FileUtil.WriteData(fileStream, new float[]
                        {
                            (float)num7 * 1000f / 30f
                        });
                        FileUtil.WriteData(fileStream, new short[]
                        {
                            (short)list.Count
                        });
                        long position4 = fileStream.Position;
                        for (int num16 = 0; num16 < list.Count; num16++)
                        {
                            List<float> list12 = dictionary2[num16];
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                (ushort)list6.IndexOf(list[num16].get_name())
                            });
                            FileUtil.WriteData(fileStream, new short[]
                            {
                                (short)list5[num16]
                            });
                            FileUtil.WriteData(fileStream, new ushort[]
                            {
                                (ushort)list12.Count
                            });
                            for (int num17 = 0; num17 < list12.Count; num17++)
                            {
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list12[num17]
                                });
                                FileUtil.WriteData(fileStream, new uint[1]);
                            }
                        }
                        long position5 = fileStream.Position;
                        for (int num18 = 0; num18 < list6.Count; num18++)
                        {
                            FileUtil.WriteData(fileStream, list6[num18]);
                        }
                        long num19 = fileStream.Position - position5;
                        long arg_9E3_0 = fileStream.Position;
                        for (int num20 = 0; num20 < list.Count; num20++)
                        {
                            List<DataManager.FrameData> list13 = dictionary[num20];
                            for (int num21 = 0; num21 < list13.Count; num21++)
                            {
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localPosition.x * -1f
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localPosition.y
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localPosition.z
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localRotation.x * -1f
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localRotation.y
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localRotation.z
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localRotation.w * -1f
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localScale.x
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localScale.y
                                });
                                FileUtil.WriteData(fileStream, new float[]
                                {
                                    list13[num21].localScale.z
                                });
                            }
                        }
                        long position6 = fileStream.Position;
                        long num22 = num19;
                        fileStream.Position = position4;
                        for (int num23 = 0; num23 < list.Count; num23++)
                        {
                            fileStream.Position += 6L;
                            List<DataManager.FrameData> list14 = dictionary[num23];
                            for (int num24 = 0; num24 < list14.Count; num24++)
                            {
                                fileStream.Position += 4L;
                                FileUtil.WriteData(fileStream, new uint[]
                                {
                                    (uint)num22
                                });
                                num22 += 40L;
                            }
                        }
                        fileStream.Position = position2 + 2L + 4L;
                        FileUtil.WriteData(fileStream, new uint[]
                        {
                            (uint)(position5 - position3)
                        });
                        fileStream.Position = position;
                        FileUtil.WriteData(fileStream, new uint[]
                        {
                            (uint)position5
                        });
                        FileUtil.WriteData(fileStream, new uint[]
                        {
                            (uint)(position6 - position5)
                        });
                        fileStream.Close();
                    }
                }
            }
        }

        public static void saveTerrainData(string savePath, JSONObject obj, GameObject gameObject = null)
        {
            LayaTerrainExporter.ExportAllTerrian(savePath, obj);
        }

        public static void saveParticleFrameData(ParticleSystem.MinMaxCurve minMaxCurve, JSONObject obj, string str1, string str2, int type, float curveMultiplier, float convert)
        {
            AnimationCurve animationCurve;
            if (type == -1)
            {
                animationCurve = minMaxCurve.get_curveMin();
            }
            else if (type == 1)
            {
                animationCurve = minMaxCurve.get_curveMax();
            }
            else
            {
                animationCurve = minMaxCurve.get_curve();
            }
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            obj.AddField(str1, jSONObject);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            if (animationCurve != null && animationCurve.get_length() != 0)
            {
                int length = animationCurve.get_length();
                for (int i = 0; i < length; i++)
                {
                    Keyframe keyframe = animationCurve.get_Item(i);
                    if (i == 0)
                    {
                        jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject3.AddField("key", 0f);
                        jSONObject3.AddField("value", keyframe.get_value() * curveMultiplier * convert);
                        jSONObject2.Add(jSONObject3);
                        if (keyframe.get_time() - DataManager.precision > 0f && (double)keyframe.get_time() < 0.5)
                        {
                            jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                            jSONObject3.AddField("key", keyframe.get_time());
                            jSONObject3.AddField("value", keyframe.get_value() * curveMultiplier * convert);
                            jSONObject2.Add(jSONObject3);
                        }
                    }
                    if (i != 0 && i != length - 1)
                    {
                        jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject3.AddField("key", keyframe.get_time());
                        jSONObject3.AddField("value", keyframe.get_value() * curveMultiplier * convert);
                        jSONObject2.Add(jSONObject3);
                    }
                    if (i == length - 1)
                    {
                        if (keyframe.get_time() + DataManager.precision < 1f && (double)keyframe.get_time() >= 0.5)
                        {
                            jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                            jSONObject3.AddField("key", keyframe.get_time());
                            jSONObject3.AddField("value", keyframe.get_value() * curveMultiplier * convert);
                            jSONObject2.Add(jSONObject3);
                        }
                        jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject3.AddField("key", 1f);
                        jSONObject3.AddField("value", keyframe.get_value() * curveMultiplier * convert);
                        jSONObject2.Add(jSONObject3);
                    }
                }
            }
            jSONObject.AddField(str2, jSONObject2);
        }

        public static void saveParticleFrameData(Gradient gradient, JSONObject obj, string str)
        {
            if (gradient == null)
            {
                return;
            }
            GradientAlphaKey[] alphaKeys = gradient.get_alphaKeys();
            GradientColorKey[] colorKeys = gradient.get_colorKeys();
            JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
            obj.AddField(str, jSONObject);
            JSONObject jSONObject2 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
            if (alphaKeys != null && alphaKeys.Length != 0)
            {
                int num = alphaKeys.Length;
                for (int i = 0; i < num; i++)
                {
                    GradientAlphaKey gradientAlphaKey = alphaKeys[i];
                    if (i == 0)
                    {
                        jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject3.AddField("key", 0f);
                        jSONObject3.AddField("value", gradientAlphaKey.alpha);
                        jSONObject2.Add(jSONObject3);
                        if (gradientAlphaKey.time - DataManager.precision > 0f && (double)gradientAlphaKey.time < 0.5)
                        {
                            jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                            jSONObject3.AddField("key", gradientAlphaKey.time);
                            jSONObject3.AddField("value", gradientAlphaKey.alpha);
                            jSONObject2.Add(jSONObject3);
                        }
                    }
                    if (i != 0 && i != num - 1)
                    {
                        jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject3.AddField("key", gradientAlphaKey.time);
                        jSONObject3.AddField("value", gradientAlphaKey.alpha);
                        jSONObject2.Add(jSONObject3);
                    }
                    if (i == num - 1)
                    {
                        if (gradientAlphaKey.time + DataManager.precision < 1f && (double)gradientAlphaKey.time >= 0.5)
                        {
                            jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                            jSONObject3.AddField("key", gradientAlphaKey.time);
                            jSONObject3.AddField("value", gradientAlphaKey.alpha);
                            jSONObject2.Add(jSONObject3);
                        }
                        jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject3.AddField("key", 1f);
                        jSONObject3.AddField("value", gradientAlphaKey.alpha);
                        jSONObject2.Add(jSONObject3);
                    }
                }
            }
            jSONObject.AddField("alphas", jSONObject2);
            JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
            JSONObject jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
            JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
            if (colorKeys != null && colorKeys.Length != 0)
            {
                int num2 = colorKeys.Length;
                for (int j = 0; j < num2; j++)
                {
                    GradientColorKey gradientColorKey = colorKeys[j];
                    if (j == 0)
                    {
                        jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject5.AddField("key", 0f);
                        jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject6.Add(gradientColorKey.color.r);
                        jSONObject6.Add(gradientColorKey.color.g);
                        jSONObject6.Add(gradientColorKey.color.b);
                        jSONObject5.AddField("value", jSONObject6);
                        jSONObject4.Add(jSONObject5);
                        if (gradientColorKey.time - DataManager.precision > 0f && (double)gradientColorKey.time < 0.5)
                        {
                            jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                            jSONObject5.AddField("key", gradientColorKey.time);
                            jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                            jSONObject6.Add(gradientColorKey.color.r);
                            jSONObject6.Add(gradientColorKey.color.g);
                            jSONObject6.Add(gradientColorKey.color.b);
                            jSONObject5.AddField("value", jSONObject6);
                            jSONObject4.Add(jSONObject5);
                        }
                    }
                    if (j != 0 && j != num2 - 1)
                    {
                        jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject5.AddField("key", gradientColorKey.time);
                        jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject6.Add(gradientColorKey.color.r);
                        jSONObject6.Add(gradientColorKey.color.g);
                        jSONObject6.Add(gradientColorKey.color.b);
                        jSONObject5.AddField("value", jSONObject6);
                        jSONObject4.Add(jSONObject5);
                    }
                    if (j == num2 - 1)
                    {
                        if (gradientColorKey.time + DataManager.precision < 1f && (double)gradientColorKey.time >= 0.5)
                        {
                            jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                            jSONObject5.AddField("key", gradientColorKey.time);
                            jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                            jSONObject6.Add(gradientColorKey.color.r);
                            jSONObject6.Add(gradientColorKey.color.g);
                            jSONObject6.Add(gradientColorKey.color.b);
                            jSONObject5.AddField("value", jSONObject6);
                            jSONObject4.Add(jSONObject5);
                        }
                        jSONObject5 = new JSONObject(JSONObject.Type.OBJECT);
                        jSONObject5.AddField("key", 1f);
                        jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
                        jSONObject6.Add(gradientColorKey.color.r);
                        jSONObject6.Add(gradientColorKey.color.g);
                        jSONObject6.Add(gradientColorKey.color.b);
                        jSONObject5.AddField("value", jSONObject6);
                        jSONObject4.Add(jSONObject5);
                    }
                }
            }
            jSONObject.AddField("rgbs", jSONObject4);
        }

        public static DataManager.VertexData getVertexData(Mesh mesh, int index)
        {
            DataManager.VertexData result;
            result.index = index;
            result.vertice = mesh.get_vertices()[index];
            if (DataManager.VertexStructure[1] == 1)
            {
                result.normal = mesh.get_normals()[index];
            }
            else
            {
                result.normal = default(Vector3);
            }
            if (DataManager.VertexStructure[2] == 1)
            {
                result.color = mesh.get_colors()[index];
            }
            else
            {
                result.color = default(Color);
            }
            if (DataManager.VertexStructure[3] == 1)
            {
                result.uv = mesh.get_uv()[index];
            }
            else
            {
                result.uv = default(Vector2);
            }
            if (DataManager.VertexStructure[4] == 1)
            {
                result.uv2 = mesh.get_uv2()[index];
            }
            else
            {
                result.uv2 = default(Vector2);
            }
            if (DataManager.VertexStructure[5] == 1)
            {
                BoneWeight boneWeight = mesh.get_boneWeights()[index];
                result.boneWeight.x = boneWeight.get_weight0();
                result.boneWeight.y = boneWeight.get_weight1();
                result.boneWeight.z = boneWeight.get_weight2();
                result.boneWeight.w = boneWeight.get_weight3();
                result.boneIndex.x = (float)boneWeight.get_boneIndex0();
                result.boneIndex.y = (float)boneWeight.get_boneIndex1();
                result.boneIndex.z = (float)boneWeight.get_boneIndex2();
                result.boneIndex.w = (float)boneWeight.get_boneIndex3();
            }
            else
            {
                result.boneWeight = default(Vector4);
                result.boneIndex = default(Vector4);
            }
            if (DataManager.VertexStructure[6] == 1)
            {
                result.tangent = mesh.get_tangents()[index];
            }
            else
            {
                result.tangent = default(Vector4);
            }
            return result;
        }

        public static void getTerrainGameObjectData(GameObject gameObject, JSONObject parentsChildNodes)
        {
            TerrainData expr_0B = gameObject.GetComponent<Terrain>().get_terrainData();
            int num = expr_0B.get_heightmapWidth();
            int num2 = expr_0B.get_heightmapHeight();
            Vector3 size = expr_0B.get_size();
            int num3 = 64;
            size = new Vector3(size.x / (float)(num - 1) * (float)num3, size.y, size.z / (float)(num2 - 1) * (float)num3);
            Vector2 vector = new Vector2(1f / (float)(num - 1), 1f / (float)(num2 - 1));
            float[,] heights = expr_0B.GetHeights(0, 0, num, num2);
            num = (num - 1) / num3 + 1;
            num2 = (num2 - 1) / num3 + 1;
            int num4 = 2;
            List<List<Vector3>> list = new List<List<Vector3>>();
            List<List<Vector3>> list2 = new List<List<Vector3>>();
            List<List<Vector2>> list3 = new List<List<Vector2>>();
            for (int i = 0; i < num4 * num4; i++)
            {
                list.Add(new List<Vector3>());
                list2.Add(new List<Vector3>());
                list3.Add(new List<Vector2>());
            }
            for (int j = 0; j < num2; j++)
            {
                for (int k = 0; k < num; k++)
                {
                    Vector3 item = Quaternion.Euler(0f, 0f, 0f) * Vector3.Scale(size, new Vector3((float)j, heights[k * num3, j * num3], (float)k));
                    Vector2 vector2 = Vector2.Scale(new Vector2((float)(k * num3), (float)(1 - j * num3)), vector);
                    vector2 = new Vector2(vector2.x * Mathf.Cos(1.57079637f) - vector2.y * Mathf.Sin(1.57079637f), vector2.x * Mathf.Sin(1.57079637f) + vector2.y * Mathf.Cos(1.57079637f));
                    if (j <= (num2 - 1) / 2 && k <= (num - 1) / 2)
                    {
                        list[0].Add(item);
                        list3[0].Add(vector2);
                    }
                    if (j <= (num2 - 1) / 2 && k >= (num - 1) / 2)
                    {
                        list[1].Add(item);
                        list3[1].Add(vector2);
                    }
                    if (j >= (num2 - 1) / 2 && k <= (num - 1) / 2)
                    {
                        list[2].Add(item);
                        list3[2].Add(vector2);
                    }
                    if (j >= (num2 - 1) / 2 && k >= (num - 1) / 2)
                    {
                        list[3].Add(item);
                        list3[3].Add(vector2);
                    }
                }
            }
            num = (num - 1) / num4;
            num2 = (num2 - 1) / num4;
            int[] array = new int[num * num2 * 6];
            int num5 = 0;
            for (int l = 0; l < num2; l++)
            {
                for (int m = 0; m < num; m++)
                {
                    array[num5++] = (l + 1) * (num + 1) + m;
                    array[num5++] = l * (num + 1) + m;
                    array[num5++] = (l + 1) * (num + 1) + m + 1;
                    array[num5++] = l * (num + 1) + m;
                    array[num5++] = l * (num + 1) + m + 1;
                    array[num5++] = (l + 1) * (num + 1) + m + 1;
                }
            }
            for (int n = 0; n < list.Count; n++)
            {
                for (int num6 = 0; num6 < list[n].Count; num6++)
                {
                    List<Vector3> list4 = new List<Vector3>();
                    for (int num7 = 0; num7 < array.Length; num7 += 3)
                    {
                        if (array[num7] == num6 || array[num7 + 1] == num6 || array[num7 + 2] == num6)
                        {
                            list4.Add(list[n][array[num7]]);
                            list4.Add(list[n][array[num7 + 1]]);
                            list4.Add(list[n][array[num7 + 2]]);
                        }
                    }
                    float num8 = 0f;
                    List<float> list5 = new List<float>();
                    List<Vector3> list6 = new List<Vector3>();
                    for (int num9 = 0; num9 < list4.Count; num9 += 3)
                    {
                        Vector3 vector3 = list4[num9] - list4[num9 + 1];
                        Vector3 vector4 = list4[num9] - list4[num9 + 2];
                        float num10 = Mathf.Sqrt(Mathf.Pow(list4[num9].x - list4[num9 + 1].x, 2f) + Mathf.Pow(list4[num9].y - list4[num9 + 1].y, 2f) + Mathf.Pow(list4[num9].z - list4[num9 + 1].z, 2f));
                        float num11 = Mathf.Sqrt(Mathf.Pow(list4[num9].x - list4[num9 + 2].x, 2f) + Mathf.Pow(list4[num9].y - list4[num9 + 2].y, 2f) + Mathf.Pow(list4[num9].z - list4[num9 + 2].z, 2f));
                        float num12 = Mathf.Sqrt(Mathf.Pow(list4[num9 + 2].x - list4[num9 + 1].x, 2f) + Mathf.Pow(list4[num9 + 2].y - list4[num9 + 1].y, 2f) + Mathf.Pow(list4[num9 + 2].z - list4[num9 + 1].z, 2f));
                        float num13 = (num10 + num11 + num12) / 2f;
                        float num14 = Mathf.Sqrt(num13 * (num13 - num10) * (num13 - num11) * (num13 - num12));
                        list5.Add(num14);
                        num8 += num14;
                        list6.Add(Vector3.Cross(vector3, vector4).get_normalized());
                    }
                    Vector3 vector5 = default(Vector3);
                    for (int num15 = 0; num15 < list6.Count; num15++)
                    {
                        vector5 += list6[num15] * list5[num15] / num8;
                    }
                    list2[n].Add(vector5.get_normalized());
                }
            }
        }

        public static bool isHasChildByType(GameObject gameObject, DataManager.ComponentType type, bool onlySon, bool isCheckParent)
        {
            GameObject gameObject2 = gameObject;
            if (isCheckParent)
            {
                gameObject2 = gameObject.get_transform().get_parent().get_gameObject();
            }
            List<GameObject> list = new List<GameObject>();
            DataManager.selectChildByType(gameObject2, type, list, onlySon);
            return list.Count > 0;
        }

        public static void selectChildByType(GameObject gameObject, DataManager.ComponentType type, List<GameObject> selectGameObjects, bool onlySon)
        {
            if (gameObject.get_transform().get_childCount() > 0)
            {
                for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                {
                    GameObject gameObject2 = gameObject.get_transform().GetChild(i).get_gameObject();
                    if (DataManager.componentsOnGameObject(gameObject2).IndexOf(type) != -1)
                    {
                        selectGameObjects.Add(gameObject2);
                    }
                    if (!onlySon)
                    {
                        DataManager.selectChildByType(gameObject2, type, selectGameObjects, onlySon);
                    }
                }
            }
        }

        public static GameObject selectParentbyType(GameObject gameObject, DataManager.ComponentType type)
        {
            if (gameObject.get_transform().get_parent() == null)
            {
                return null;
            }
            GameObject gameObject2 = gameObject.get_transform().get_parent().get_gameObject();
            if (DataManager.componentsOnGameObject(gameObject2).IndexOf(type) != -1)
            {
                return gameObject2;
            }
            return DataManager.selectParentbyType(gameObject2, type);
        }

        public static bool isHasLegalChild(GameObject gameObject)
        {
            for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
            {
                GameObject gameObject2 = gameObject.get_transform().GetChild(i).get_gameObject();
                if (DataManager.componentsOnGameObject(gameObject2).Count > 1 && gameObject2.get_activeInHierarchy())
                {
                    return true;
                }
            }
            return false;
        }

        public static void checkChildHasLocalParticle(GameObject gameObject, bool isTopNode)
        {
            if (isTopNode)
            {
                DataManager.curNodeHasLocalParticleChild = false;
            }
            if (gameObject.get_transform().get_childCount() > 0)
            {
                for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                {
                    GameObject gameObject2 = gameObject.get_transform().GetChild(i).get_gameObject();
                    if (DataManager.componentsOnGameObject(gameObject2).IndexOf(DataManager.ComponentType.ParticleSystem) != -1 && gameObject2.GetComponent<ParticleSystem>().get_main().get_scalingMode().ToString() == "Local")
                    {
                        DataManager.curNodeHasLocalParticleChild = true;
                    }
                    DataManager.checkChildHasLocalParticle(gameObject2, false);
                }
            }
        }

        public static void checkChildIsNotLegal(GameObject gameObject, bool isTopNode)
        {
            if (isTopNode)
            {
                DataManager.curNodeHasNotLegalChild = false;
            }
            if (DataManager.componentsOnGameObject(gameObject).Count <= 1)
            {
                DataManager.curNodeHasNotLegalChild = true;
            }
            if (gameObject.get_transform().get_childCount() > 0)
            {
                for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                {
                    GameObject expr_40 = gameObject.get_transform().GetChild(i).get_gameObject();
                    if (DataManager.componentsOnGameObject(expr_40).Count <= 1)
                    {
                        DataManager.curNodeHasNotLegalChild = true;
                    }
                    DataManager.checkChildIsNotLegal(expr_40, false);
                }
            }
        }

        public static void checkChildIsLegal(GameObject gameObject, bool isTopNode)
        {
            if (isTopNode)
            {
                DataManager.curNodeHasLegalChild = false;
            }
            if (gameObject.get_transform().get_childCount() > 0)
            {
                for (int i = 0; i < gameObject.get_transform().get_childCount(); i++)
                {
                    GameObject expr_2C = gameObject.get_transform().GetChild(i).get_gameObject();
                    if (DataManager.componentsOnGameObject(expr_2C).Count > 1)
                    {
                        DataManager.curNodeHasLegalChild = true;
                    }
                    DataManager.checkChildIsLegal(expr_2C, false);
                }
            }
        }

        public static bool checkChildBoneIsLegal(Transform root, Transform bone, Transform skinBone, int count)
        {
            if (root == bone)
            {
                return true;
            }
            for (int i = 0; i < count; i++)
            {
                if (skinBone == root)
                {
                    return false;
                }
                if (bone == skinBone)
                {
                    return true;
                }
                skinBone = skinBone.get_parent();
            }
            return false;
        }

        public static List<DataManager.ComponentType> componentsOnGameObject(GameObject gameObject)
        {
            gameObject.GetComponent<Transform>();
            List<DataManager.ComponentType> list = new List<DataManager.ComponentType>();
            Camera component = gameObject.GetComponent<Camera>();
            Light component2 = gameObject.GetComponent<Light>();
            MeshFilter component3 = gameObject.GetComponent<MeshFilter>();
            MeshRenderer component4 = gameObject.GetComponent<MeshRenderer>();
            SkinnedMeshRenderer component5 = gameObject.GetComponent<SkinnedMeshRenderer>();
            Animation component6 = gameObject.GetComponent<Animation>();
            Object arg_C9_0 = gameObject.GetComponent<Animator>();
            ParticleSystem component7 = gameObject.GetComponent<ParticleSystem>();
            Terrain component8 = gameObject.GetComponent<Terrain>();
            Object arg_84_0 = gameObject.GetComponent<BoxCollider>();
            SphereCollider component9 = gameObject.GetComponent<SphereCollider>();
            Rigidbody component10 = gameObject.GetComponent<Rigidbody>();
            Object arg_74_0 = gameObject.GetComponent<TrailRenderer>();
            list.Add(DataManager.ComponentType.Transform);
            if (arg_74_0 != null)
            {
                list.Add(DataManager.ComponentType.TrailRenderer);
            }
            if (arg_84_0 != null)
            {
                list.Add(DataManager.ComponentType.BoxCollider);
            }
            if (component9 != null)
            {
                list.Add(DataManager.ComponentType.SphereCollider);
            }
            if (component10 != null)
            {
                list.Add(DataManager.ComponentType.Rigidbody);
            }
            if (component6 != null)
            {
                list.Add(DataManager.ComponentType.Animation);
            }
            if (arg_C9_0 != null)
            {
                if (component6 == null)
                {
                    list.Add(DataManager.ComponentType.Animator);
                }
                else if (component6 != null)
                {
                    Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " Animation and Animator can't exist at the same time !");
                }
            }
            if (component != null)
            {
                list.Add(DataManager.ComponentType.Camera);
            }
            if (component2 != null && component2.get_type() == 1)
            {
                list.Add(DataManager.ComponentType.DirectionalLight);
            }
            if (component3 != null)
            {
                if (component == null)
                {
                    list.Add(DataManager.ComponentType.MeshFilter);
                    if (component4 == null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " need a MeshRenderer ComponentType !");
                    }
                }
                else if (component != null)
                {
                    Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " Camera and MeshFilter can't exist at the same time !");
                }
            }
            if (component4 != null)
            {
                if (component == null)
                {
                    list.Add(DataManager.ComponentType.MeshRenderer);
                    if (component3 == null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " need a meshFilter ComponentType !");
                    }
                }
                else if (component != null)
                {
                    Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " Camera and MeshRenderer can't exist at the same time !");
                }
            }
            if (component5 != null)
            {
                if (component == null && component3 == null && component4 == null)
                {
                    list.Add(DataManager.ComponentType.SkinnedMeshRenderer);
                }
                else
                {
                    if (component != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " Camera and SkinnedMeshRenderer can't exist at the same time !");
                    }
                    if (component3 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " MeshFilter and SkinnedMeshRenderer can't exist at the same time !");
                    }
                    if (component4 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " MeshRenderer and SkinnedMeshRenderer can't exist at the same time !");
                    }
                }
            }
            if (component7 != null)
            {
                if (component == null && component3 == null && component4 == null && component5 == null)
                {
                    list.Add(DataManager.ComponentType.ParticleSystem);
                }
                else
                {
                    if (component != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " Camera and ParticleSystem can't exist at the same time !");
                    }
                    if (component3 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " MeshFilter and ParticleSystem can't exist at the same time !");
                    }
                    if (component4 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " MeshRenderer and ParticleSystem can't exist at the same time !");
                    }
                    if (component5 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " SkinnedMeshRenderer and ParticleSystem can't exist at the same time !");
                    }
                }
            }
            if (component8 != null)
            {
                if (component == null && component3 == null && component4 == null && component5 == null && component7 == null)
                {
                    list.Add(DataManager.ComponentType.Terrain);
                }
                else
                {
                    if (component != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " Camera and Terrain can't exist at the same time !");
                    }
                    if (component3 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " MeshFilter and Terrain can't exist at the same time !");
                    }
                    if (component4 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " MeshRenderer and Terrain can't exist at the same time !");
                    }
                    if (component5 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " SkinnedMeshRenderer and Terrain can't exist at the same time !");
                    }
                    if (component7 != null)
                    {
                        Debug.LogWarning("LayaAir3D : " + gameObject.get_name() + " ParticleSystem and Terrain can't exist at the same time !");
                    }
                }
            }
            return list;
        }

        public static bool frameDataIsEquals(DataManager.FrameData f1, DataManager.FrameData f2)
        {
            Vector3 localPosition = f1.localPosition;
            Quaternion localRotation = f1.localRotation;
            Vector3 localScale = f1.localScale;
            Vector3 localPosition2 = f2.localPosition;
            Quaternion localRotation2 = f2.localRotation;
            Vector3 localScale2 = f2.localScale;
            return MathUtil.isSimilar(localPosition.x, localPosition2.x) && MathUtil.isSimilar(localPosition.y, localPosition2.y) && MathUtil.isSimilar(localPosition.z, localPosition2.z) && MathUtil.isSimilar(localRotation.x, localRotation2.x) && MathUtil.isSimilar(localRotation.y, localRotation2.y) && MathUtil.isSimilar(localRotation.z, localRotation2.z) && MathUtil.isSimilar(localRotation.w, localRotation2.w) && MathUtil.isSimilar(localScale.x, localScale2.x) && MathUtil.isSimilar(localScale.y, localScale2.y) && MathUtil.isSimilar(localScale.z, localScale2.z);
        }

        public static string cleanIllegalChar(string str, bool heightLevel)
        {
            str = str.Replace("<", "_");
            str = str.Replace(">", "_");
            str = str.Replace("\"", "_");
            str = str.Replace("|", "_");
            str = str.Replace("?", "_");
            str = str.Replace("*", "_");
            str = str.Replace("#", "_");
            if (heightLevel)
            {
                str = str.Replace("/", "_");
                str = str.Replace(":", "_");
            }
            return str;
        }

        public static bool findStrsInCurString(string curString, List<string> strs)
        {
            int num = curString.Length - 4;
            for (int i = 0; i < strs.Count; i++)
            {
                if (curString.IndexOf(strs[i]) == num)
                {
                    return true;
                }
            }
            return false;
        }

        public static void recodeLayaJSFile(string pathName)
        {
            FileStream expr_16 = new FileStream(Application.get_dataPath() + "/WebPlayerTemplates/LayaDemo/LayaAir3DSample.js", FileMode.Create, FileAccess.ReadWrite);
            StreamWriter streamWriter = new StreamWriter(expr_16);
            streamWriter.WriteLine("Laya3D.init(0, 0, true);");
            streamWriter.WriteLine("Laya.stage.scaleMode = Laya.Stage.SCALE_FULL;");
            streamWriter.WriteLine("Laya.stage.screenMode = Laya.Stage.SCREEN_NONE;");
            streamWriter.WriteLine("Laya.Stat.show();");
            if (DataManager.Type == 0)
            {
                streamWriter.WriteLine("var scene = Laya.stage.addChild(Laya.Scene.load('res" + pathName + ".ls'));");
            }
            else
            {
                streamWriter.WriteLine("var scene = Laya.stage.addChild(new Laya.Scene());");
                streamWriter.WriteLine("var sprite3D = scene.addChild(Laya.Sprite3D.load('res" + pathName + ".lh'));");
            }
            streamWriter.Close();
            expr_16.Close();
        }

        public static long GetTimeStamp()
        {
            return Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds);
        }

        public static void SwitchToLayaShader()
        {
            GameObject[] rootGameObjects = SceneManager.GetActiveScene().GetRootGameObjects();
            if (rootGameObjects.Length != 0)
            {
                for (int i = 0; i < rootGameObjects.Length; i++)
                {
                    DataManager.SwitchToLayaShader(rootGameObjects[i].get_gameObject());
                }
            }
        }

        public static void SwitchToLayaShader(GameObject gameObject)
        {
            List<DataManager.ComponentType> list = DataManager.componentsOnGameObject(gameObject);
            Shader shader = Shader.Find("LayaAir3D/BlinnPhong");
            Shader shader2 = Shader.Find("LayaAir3D/ShurikenParticle");
            if (list.IndexOf(DataManager.ComponentType.MeshRenderer) != -1)
            {
                Material[] sharedMaterials = gameObject.GetComponent<MeshRenderer>().get_sharedMaterials();
                for (int i = 0; i < sharedMaterials.Length; i++)
                {
                    Material material = sharedMaterials[i];
                    if (!(material == null))
                    {
                        material.set_shader(shader);
                        DataManager.onChangeLayaBlinnPhong(material);
                    }
                }
            }
            if (list.IndexOf(DataManager.ComponentType.SkinnedMeshRenderer) != -1)
            {
                Material[] sharedMaterials2 = gameObject.GetComponent<SkinnedMeshRenderer>().get_sharedMaterials();
                for (int j = 0; j < sharedMaterials2.Length; j++)
                {
                    Material material2 = sharedMaterials2[j];
                    if (!(material2 == null))
                    {
                        material2.set_shader(shader);
                        DataManager.onChangeLayaBlinnPhong(material2);
                    }
                }
            }
            if (list.IndexOf(DataManager.ComponentType.ParticleSystem) != -1)
            {
                Material sharedMaterial = gameObject.GetComponent<Renderer>().get_sharedMaterial();
                if (sharedMaterial != null)
                {
                    sharedMaterial.set_shader(shader2);
                    DataManager.onChangeLayaParticle(sharedMaterial);
                }
            }
            if (gameObject.get_transform().get_childCount() > 0)
            {
                for (int k = 0; k < gameObject.get_transform().get_childCount(); k++)
                {
                    DataManager.SwitchToLayaShader(gameObject.get_transform().GetChild(k).get_gameObject());
                }
            }
        }

        public static void onChangeLayaBlinnPhong(Material material)
        {
            switch (material.GetInt("_Mode"))
            {
                case 0:
                    material.SetInt("_AlphaTest", 0);
                    material.SetInt("_AlphaBlend", 0);
                    material.SetInt("_SrcBlend", 1);
                    material.SetInt("_DstBlend", 0);
                    material.SetInt("_ZWrite", 1);
                    material.SetInt("_ZTest", 2);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("EnableAlphaCutoff");
                    material.set_renderQueue(2000);
                    material.SetInt("_RenderQueue", 0);
                    return;
                case 1:
                    material.SetInt("_AlphaTest", 1);
                    material.SetInt("_AlphaBlend", 0);
                    material.SetInt("_SrcBlend", 1);
                    material.SetInt("_DstBlend", 0);
                    material.SetInt("_ZWrite", 1);
                    material.SetInt("_ZTest", 2);
                    material.EnableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.EnableKeyword("EnableAlphaCutoff");
                    material.set_renderQueue(2450);
                    material.SetInt("_RenderQueue", 1);
                    return;
                case 2:
                    material.SetInt("_AlphaTest", 0);
                    material.SetInt("_AlphaBlend", 1);
                    material.SetInt("_SrcBlend", 5);
                    material.SetInt("_DstBlend", 10);
                    material.SetInt("_ZWrite", 0);
                    material.SetInt("_ZTest", 2);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.EnableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("EnableAlphaCutoff");
                    material.set_renderQueue(3000);
                    material.SetInt("_RenderQueue", 2);
                    return;
                case 3:
                    material.SetInt("_AlphaTest", 0);
                    material.SetInt("_AlphaBlend", 1);
                    material.SetInt("_SrcBlend", 5);
                    material.SetInt("_DstBlend", 1);
                    material.SetInt("_ZWrite", 0);
                    material.SetInt("_ZTest", 2);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.EnableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("EnableAlphaCutoff");
                    material.set_renderQueue(3000);
                    material.SetInt("_RenderQueue", 2);
                    return;
                default:
                    material.SetInt("_AlphaTest", 0);
                    material.SetInt("_AlphaBlend", 0);
                    material.SetInt("_SrcBlend", 1);
                    material.SetInt("_DstBlend", 0);
                    material.SetInt("_ZWrite", 1);
                    material.SetInt("_ZTest", 2);
                    material.DisableKeyword("_ALPHATEST_ON");
                    material.DisableKeyword("_ALPHABLEND_ON");
                    material.DisableKeyword("EnableAlphaCutoff");
                    material.set_renderQueue(2000);
                    material.SetInt("_RenderQueue", 0);
                    return;
            }
        }

        public static void onChangeLayaParticle(Material material)
        {
            int @int = material.GetInt("_Mode");
            if (@int == 0)
            {
                material.SetInt("_AlphaTest", 0);
                material.SetInt("_AlphaBlend", 1);
                material.SetInt("_SrcBlend", 5);
                material.SetInt("_DstBlend", 1);
                material.SetInt("_ZWrite", 0);
                material.SetInt("_ZTest", 2);
                material.DisableKeyword("_ALPHATEST_ON");
                material.EnableKeyword("_ALPHABLEND_ON");
                material.set_renderQueue(3000);
                material.SetInt("_RenderQueue", 2);
                return;
            }
            if (@int != 1)
            {
                material.SetInt("_AlphaTest", 0);
                material.SetInt("_AlphaBlend", 1);
                material.SetInt("_SrcBlend", 5);
                material.SetInt("_DstBlend", 10);
                material.SetInt("_ZWrite", 0);
                material.SetInt("_ZTest", 2);
                material.DisableKeyword("_ALPHATEST_ON");
                material.EnableKeyword("_ALPHABLEND_ON");
                material.set_renderQueue(3000);
                material.SetInt("_RenderQueue", 2);
                return;
            }
            material.SetInt("_AlphaTest", 0);
            material.SetInt("_AlphaBlend", 1);
            material.SetInt("_SrcBlend", 5);
            material.SetInt("_DstBlend", 10);
            material.SetInt("_ZWrite", 0);
            material.SetInt("_ZTest", 2);
            material.DisableKeyword("_ALPHATEST_ON");
            material.EnableKeyword("_ALPHABLEND_ON");
            material.set_renderQueue(3000);
            material.SetInt("_RenderQueue", 2);
        }
    }
}
