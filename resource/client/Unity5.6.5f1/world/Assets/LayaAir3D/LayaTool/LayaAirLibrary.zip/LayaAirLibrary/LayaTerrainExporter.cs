using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class LayaTerrainExporter
{
    private static int CHUNK_GRID_NUM = 64;

    private static int LEAF_GRID_NUM = 32;

    private static int m_splatIndex = 0;

    private static int m_alphaIndex = 0;

    private static int m_channelIndex = 0;

    private static Color[] m_alphaBlock = null;

    private static JSONObject m_detailID = null;

    private static List<KeyValuePair<string, Color[]>> m_alphamapDataList = new List<KeyValuePair<string, Color[]>>();

    private static Terrain m_terrain;

    private static string m_saveLocation;

    private static JSONObject m_alphamapArrayNode = null;

    private static JSONObject m_detailIDArrayNode = null;

    private static JSONObject m_chunkNode = null;

    private static JSONObject m_chunkInfoNode = null;

    private static string m_alphaBlockName = "";

    private static bool m_debug = false;

    private static bool cameraCoordinateInverse = true;

    public static void ExportAllTerrian(string savePath, JSONObject obj)
    {
        LayaTerrainExporter.m_saveLocation = savePath + "/terrain";
        Terrain[] activeTerrains = Terrain.get_activeTerrains();
        for (int i = 0; i < activeTerrains.Length; i++)
        {
            Terrain arg_22_0 = activeTerrains[i];
            LayaTerrainExporter.Clean();
            LayaTerrainExporter.m_terrain = arg_22_0;
            obj.AddField("dataPath", "terrain/" + LayaTerrainExporter.m_terrain.get_name().ToLower() + ".lt");
            LayaTerrainExporter.ExportTerrain();
        }
    }

    public static void saveLightMapData(JSONObject obj)
    {
        if (LayaTerrainExporter.m_terrain != null && LayaTerrainExporter.m_terrain.get_lightmapIndex() > -1)
        {
            obj.AddField("lightmapIndex", LayaTerrainExporter.m_terrain.get_lightmapIndex());
            JSONObject jSONObject = new JSONObject(JSONObject.Type.ARRAY);
            obj.AddField("lightmapScaleOffset", jSONObject);
            jSONObject.Add(LayaTerrainExporter.m_terrain.get_lightmapScaleOffset().x);
            jSONObject.Add(LayaTerrainExporter.m_terrain.get_lightmapScaleOffset().y);
            jSONObject.Add(LayaTerrainExporter.m_terrain.get_lightmapScaleOffset().z);
            jSONObject.Add(-LayaTerrainExporter.m_terrain.get_lightmapScaleOffset().w);
        }
    }

    private static void ExportTerrain()
    {
        if (!Directory.Exists(LayaTerrainExporter.m_saveLocation))
        {
            Directory.CreateDirectory(LayaTerrainExporter.m_saveLocation);
        }
        JSONObject jSONObject = new JSONObject(JSONObject.Type.OBJECT);
        jSONObject.AddField("version", "1.0");
        jSONObject.AddField("cameraCoordinateInverse", LayaTerrainExporter.cameraCoordinateInverse);
        float num = LayaTerrainExporter.m_terrain.get_terrainData().get_size().x / (float)(LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() - 1);
        jSONObject.AddField("gridSize", num);
        if ((LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() - 1) % LayaTerrainExporter.CHUNK_GRID_NUM != 0)
        {
            Debug.LogError("�߶�ͼ�Ŀ���ȥһ������" + LayaTerrainExporter.CHUNK_GRID_NUM + "�ı���");
            return;
        }
        if ((LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1) % LayaTerrainExporter.CHUNK_GRID_NUM != 0)
        {
            Debug.LogError("�߶�ͼ�ĸ߼�ȥһ������" + LayaTerrainExporter.CHUNK_GRID_NUM + "�ı���");
            return;
        }
        int num2 = (LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() - 1) / LayaTerrainExporter.CHUNK_GRID_NUM;
        int num3 = (LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1) / LayaTerrainExporter.CHUNK_GRID_NUM;
        jSONObject.AddField("chunkNumX", num2);
        jSONObject.AddField("chunkNumZ", num3);
        JSONObject jSONObject2 = new JSONObject(JSONObject.Type.OBJECT);
        jSONObject2.AddField("numX", LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth());
        jSONObject2.AddField("numZ", LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight());
        jSONObject2.AddField("bitType", 16);
        jSONObject2.AddField("value", LayaTerrainExporter.m_terrain.get_terrainData().get_size().y);
        jSONObject2.AddField("url", LayaTerrainExporter.m_terrain.get_name().ToLower() + "_heightmap.thdata");
        jSONObject.AddField("heightData", jSONObject2);
        JSONObject jSONObject3 = new JSONObject(JSONObject.Type.OBJECT);
        jSONObject.AddField("material", jSONObject3);
        JSONObject jSONObject4 = new JSONObject(JSONObject.Type.ARRAY);
        jSONObject4.Add(0f);
        jSONObject4.Add(0f);
        jSONObject4.Add(0f);
        jSONObject3.AddField("ambient", jSONObject4);
        JSONObject jSONObject5 = new JSONObject(JSONObject.Type.ARRAY);
        jSONObject5.Add(1f);
        jSONObject5.Add(1f);
        jSONObject5.Add(1f);
        jSONObject3.AddField("diffuse", jSONObject5);
        JSONObject jSONObject6 = new JSONObject(JSONObject.Type.ARRAY);
        jSONObject6.Add(0.2f);
        jSONObject6.Add(0.2f);
        jSONObject6.Add(0.2f);
        jSONObject6.Add(32f);
        jSONObject3.AddField("specular", jSONObject6);
        JSONObject jSONObject7 = new JSONObject(JSONObject.Type.ARRAY);
        jSONObject.AddField("detailTexture", jSONObject7);
        int num4 = LayaTerrainExporter.m_terrain.get_terrainData().get_splatPrototypes().Length;
        for (int i = 0; i < num4; i++)
        {
            JSONObject jSONObject8 = new JSONObject(JSONObject.Type.OBJECT);
            SplatPrototype splatPrototype = LayaTerrainExporter.m_terrain.get_terrainData().get_splatPrototypes()[i];
            jSONObject8.AddField("diffuse", splatPrototype.get_texture().get_name().ToLower() + ".jpg");
            if (splatPrototype.get_normalMap() != null)
            {
                jSONObject8.AddField("normal", splatPrototype.get_normalMap().get_name().ToLower() + ".jpg");
            }
            JSONObject jSONObject9 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject9.Add(splatPrototype.get_tileSize().x / num);
            jSONObject9.Add(splatPrototype.get_tileSize().y / num);
            jSONObject8.AddField("scale", jSONObject9);
            JSONObject jSONObject10 = new JSONObject(JSONObject.Type.ARRAY);
            jSONObject10.Add(splatPrototype.get_tileOffset().x);
            jSONObject10.Add(splatPrototype.get_tileOffset().y);
            jSONObject8.AddField("offset", jSONObject10);
            jSONObject7.Add(jSONObject8);
        }
        LayaTerrainExporter.m_chunkInfoNode = new JSONObject(JSONObject.Type.ARRAY);
        jSONObject.AddField("chunkInfo", LayaTerrainExporter.m_chunkInfoNode);
        float[,] heightsData = LayaTerrainExporter.GetHeightsData();
        Texture2D texture2D = LayaTerrainExporter.ExportNormal(LayaTerrainExporter.calcNormalOfTriangle(heightsData, num2 * LayaTerrainExporter.LEAF_GRID_NUM * num3 * LayaTerrainExporter.LEAF_GRID_NUM * 2, num));
        JSONObject jSONObject11 = new JSONObject(JSONObject.Type.ARRAY);
        jSONObject11.Add(texture2D.get_name().ToLower() + ".png");
        jSONObject.AddField("normalMap", jSONObject11);
        int num5 = 0;
        int num6 = 0;
        TextureFormat format = 0;
        for (int j = 0; j < num3; j++)
        {
            for (int k = 0; k < num2; k++)
            {
                num4 = LayaTerrainExporter.m_terrain.get_terrainData().get_alphamapTextures().Length;
                LayaTerrainExporter.m_chunkNode = new JSONObject(JSONObject.Type.OBJECT);
                LayaTerrainExporter.m_alphamapArrayNode = new JSONObject(JSONObject.Type.ARRAY);
                LayaTerrainExporter.m_detailIDArrayNode = new JSONObject(JSONObject.Type.ARRAY);
                LayaTerrainExporter.m_splatIndex = 0;
                for (int l = 0; l < num4; l++)
                {
                    Texture2D texture2D2 = LayaTerrainExporter.m_terrain.get_terrainData().get_alphamapTextures()[l];
                    if (texture2D2.get_width() % num2 != 0)
                    {
                        Debug.LogError("Control Texture(alpha map) �Ŀ�������" + num2 + "�ı���");
                        return;
                    }
                    if (texture2D2.get_height() % num3 != 0)
                    {
                        Debug.LogError("Control Texture(alpha map) �ĸ߱�����" + num3 + "�ı���");
                        return;
                    }
                    num5 = texture2D2.get_width() / num2;
                    num6 = texture2D2.get_height() / num3;
                    int num7 = k * num5;
                    int num8 = texture2D2.get_height() - (j + 1) * num6;
                    Color[] pixels = texture2D2.GetPixels(num7, num8, num5, num6);
                    format = texture2D2.get_format();
                    LayaTerrainExporter.MergeAlphaMap(string.Concat(new object[]
                    {
                        LayaTerrainExporter.m_terrain.get_name().ToLower(),
                        "_splatalpha{0}_",
                        k,
                        "_",
                        j,
                        LayaTerrainExporter.m_debug ? ".jpg" : ".png"
                    }), format, num5, num6, pixels);
                }
                LayaTerrainExporter.AfterMergeAlphaMap(string.Concat(new object[]
                {
                    LayaTerrainExporter.m_terrain.get_name().ToLower(),
                    "_splatalpha{0}_",
                    k,
                    "_",
                    j,
                    LayaTerrainExporter.m_debug ? ".jpg" : ".png"
                }), format, num5, num6);
                LayaTerrainExporter.m_chunkNode.AddField("normalMap", 0);
            }
            LayaTerrainExporter.ExportSplat();
            LayaTerrainExporter.ExportHeightmap16(heightsData);
            LayaTerrainExporter.ExportAlphamap();
        }
        JSONObject jSONObject12 = new JSONObject(JSONObject.Type.ARRAY);
        for (int m = 0; m < LayaTerrainExporter.m_alphamapDataList.Count; m++)
        {
            jSONObject12.Add(LayaTerrainExporter.m_alphamapDataList[m].Key.ToLower());
        }
        jSONObject.AddField("alphaMap", jSONObject12);
        LayaTerrainExporter.saveData(jSONObject);
    }

    private static void Clean()
    {
        LayaTerrainExporter.m_splatIndex = 0;
        LayaTerrainExporter.m_alphaIndex = 0;
        LayaTerrainExporter.m_channelIndex = 0;
        LayaTerrainExporter.m_alphaBlock = null;
        LayaTerrainExporter.m_detailID = null;
        LayaTerrainExporter.m_alphamapDataList.Clear();
        LayaTerrainExporter.m_terrain = null;
        LayaTerrainExporter.m_alphamapArrayNode = null;
        LayaTerrainExporter.m_detailIDArrayNode = null;
        LayaTerrainExporter.m_chunkInfoNode = null;
        LayaTerrainExporter.m_alphaBlockName = "";
    }

    private static void SaveAlphaMap(string fileName, TextureFormat format, int width, int height)
    {
        if (LayaTerrainExporter.m_alphaIndex <= 0 || !LayaTerrainExporter.IsAlphaMapEmpty(LayaTerrainExporter.m_alphaBlock))
        {
            int num = LayaTerrainExporter.GetAlphaMapCached(LayaTerrainExporter.m_alphaBlock, LayaTerrainExporter.m_alphamapDataList);
            if (num == -1)
            {
                Texture2D texture2D = new Texture2D(width, height, format, false);
                Color[] array = new Color[LayaTerrainExporter.m_alphaBlock.Length];
                for (int i = 0; i < LayaTerrainExporter.m_alphaBlock.Length; i++)
                {
                    float arg_C6_0 = LayaTerrainExporter.m_alphaBlock[i].r;
                    float g = LayaTerrainExporter.m_alphaBlock[i].g;
                    float b = LayaTerrainExporter.m_alphaBlock[i].b;
                    float a = LayaTerrainExporter.m_alphaBlock[i].a;
                    array[i].r = g;
                    array[i].g = b;
                    array[i].b = a;
                    float num2 = arg_C6_0 + g + b + a;
                    array[i].a = ((num2 > 1f) ? 1f : num2);
                }
                texture2D.SetPixels(array);
                texture2D.Apply();
                string text = string.Format(fileName, LayaTerrainExporter.m_alphaIndex).ToLower();
                File.WriteAllBytes(LayaTerrainExporter.m_saveLocation + "/" + text, LayaTerrainExporter.m_debug ? texture2D.EncodeToJPG() : texture2D.EncodeToPNG());
                LayaTerrainExporter.m_alphamapDataList.Add(new KeyValuePair<string, Color[]>(text, LayaTerrainExporter.m_alphaBlock));
                num = LayaTerrainExporter.m_alphamapDataList.Count - 1;
            }
            LayaTerrainExporter.m_alphamapArrayNode.Add(num);
            LayaTerrainExporter.m_detailIDArrayNode.Add(LayaTerrainExporter.m_detailID);
        }
        LayaTerrainExporter.m_alphaIndex++;
        LayaTerrainExporter.m_alphaBlock = null;
        LayaTerrainExporter.m_channelIndex = 0;
    }

    private static void AfterMergeAlphaMap(string fileName, TextureFormat format, int width, int height)
    {
        if (LayaTerrainExporter.m_alphaBlock != null)
        {
            LayaTerrainExporter.SaveAlphaMap(fileName, format, width, height);
        }
        LayaTerrainExporter.m_alphaIndex = 0;
        LayaTerrainExporter.m_alphaBlockName = "";
        LayaTerrainExporter.m_chunkNode.AddField("alphaMap", LayaTerrainExporter.m_alphamapArrayNode);
        LayaTerrainExporter.m_chunkNode.AddField("detailID", LayaTerrainExporter.m_detailIDArrayNode);
        LayaTerrainExporter.m_chunkInfoNode.Add(LayaTerrainExporter.m_chunkNode);
    }

    private static void MergeAlphaMap(string fileName, TextureFormat format, int width, int height, Color[] color)
    {
        for (int i = 0; i < 4; i++)
        {
            if (LayaTerrainExporter.m_alphaBlock == null)
            {
                LayaTerrainExporter.m_detailID = new JSONObject(JSONObject.Type.ARRAY);
                LayaTerrainExporter.m_alphaBlockName = fileName;
                LayaTerrainExporter.m_alphaBlock = new Color[color.Length];
                for (int j = 0; j < LayaTerrainExporter.m_alphaBlock.Length; j++)
                {
                    LayaTerrainExporter.m_alphaBlock[j] = new Color(0f, 0f, 0f, 0f);
                }
            }
            bool flag = true;
            for (int k = 0; k < color.Length; k++)
            {
                float num = color[k].get_Item(i);
                LayaTerrainExporter.m_alphaBlock[k].set_Item(LayaTerrainExporter.m_channelIndex, num);
                if (num != 0f)
                {
                    flag = false;
                }
            }
            if (!flag)
            {
                LayaTerrainExporter.m_detailID.Add(LayaTerrainExporter.m_splatIndex);
                LayaTerrainExporter.m_channelIndex++;
                if (LayaTerrainExporter.m_channelIndex > 3)
                {
                    LayaTerrainExporter.SaveAlphaMap(LayaTerrainExporter.m_alphaBlockName, format, width, height);
                }
            }
            LayaTerrainExporter.m_splatIndex++;
        }
    }

    private static bool IsAlphaMapEmpty(Color[] color)
    {
        for (int i = 0; i < color.Length; i++)
        {
            if (color[i] != Color.get_clear())
            {
                return false;
            }
        }
        return true;
    }

    private static int GetAlphaMapCached(Color[] color, List<KeyValuePair<string, Color[]>> alphamapDataList)
    {
        for (int i = 0; i < alphamapDataList.Count; i++)
        {
            bool flag = true;
            for (int j = 0; j < color.Length; j++)
            {
                if (color[j] != alphamapDataList[i].Value[j])
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                return i;
            }
        }
        return -1;
    }

    private static void ExportHeightmap16(float[,] heightsData)
    {
        byte[] array = new byte[LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() * LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() * 2];
        float num = 65536f;
        int num2 = 0;
        for (int i = 0; i < LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight(); i++)
        {
            for (int j = 0; j < LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(); j++)
            {
                byte[] bytes = BitConverter.GetBytes((ushort)Mathf.Clamp(Mathf.RoundToInt(heightsData[i, j] * num), 0, 65535));
                array[num2 * 2] = bytes[0];
                array[num2 * 2 + 1] = bytes[1];
                num2++;
            }
        }
        FileStream expr_CB = new FileStream(LayaTerrainExporter.m_saveLocation + "/" + LayaTerrainExporter.m_terrain.get_name().ToLower() + "_heightmap.thdata", FileMode.Create);
        expr_CB.Write(array, 0, array.Length);
        expr_CB.Close();
    }

    private static void ExportAlphamap()
    {
        int num = LayaTerrainExporter.m_terrain.get_terrainData().get_alphamapTextures().Length;
        for (int i = 0; i < num; i++)
        {
            Texture2D texture2D = LayaTerrainExporter.m_terrain.get_terrainData().get_alphamapTextures()[i];
            FileStream expr_4D = File.Open(LayaTerrainExporter.m_saveLocation + "/" + texture2D.get_name().ToLower() + ".png", FileMode.Create);
            new BinaryWriter(expr_4D).Write(texture2D.EncodeToPNG());
            expr_4D.Close();
        }
    }

    private static float[,] GetHeightsData()
    {
        float[,] heights = LayaTerrainExporter.m_terrain.get_terrainData().GetHeights(0, 0, LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(), LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight());
        float[,] array = new float[LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(), LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight()];
        for (int i = LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1; i >= 0; i--)
        {
            for (int j = 0; j < LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(); j++)
            {
                array[LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1 - i, j] = heights[i, j];
            }
        }
        return array;
    }

    private static void ExportSplat()
    {
        int num = LayaTerrainExporter.m_terrain.get_terrainData().get_splatPrototypes().Length;
        for (int i = 0; i < num; i++)
        {
            SplatPrototype splatPrototype = LayaTerrainExporter.m_terrain.get_terrainData().get_splatPrototypes()[i];
            Texture2D texture2D = splatPrototype.get_texture();
            string expr_3D = AssetDatabase.GetAssetPath(texture2D.GetInstanceID());
            TextureImporter expr_48 = AssetImporter.GetAtPath(expr_3D) as TextureImporter;
            expr_48.set_isReadable(true);
            expr_48.set_textureCompression(0);
            AssetDatabase.ImportAsset(expr_3D);
            FileStream expr_7F = File.Open(LayaTerrainExporter.m_saveLocation + "/" + texture2D.get_name().ToLower() + ".jpg", FileMode.Create);
            new BinaryWriter(expr_7F).Write(texture2D.EncodeToJPG());
            expr_7F.Close();
            if (splatPrototype.get_normalMap() != null)
            {
                texture2D = splatPrototype.get_normalMap();
                string expr_B5 = AssetDatabase.GetAssetPath(texture2D.GetInstanceID());
                TextureImporter expr_C0 = AssetImporter.GetAtPath(expr_B5) as TextureImporter;
                expr_C0.set_isReadable(true);
                expr_C0.set_textureCompression(0);
                AssetDatabase.ImportAsset(expr_B5);
                FileStream expr_F7 = File.Open(LayaTerrainExporter.m_saveLocation + "/" + texture2D.get_name().ToLower() + ".jpg", FileMode.Create);
                new BinaryWriter(expr_F7).Write(texture2D.EncodeToJPG());
                expr_F7.Close();
            }
        }
    }

    private static Vector3[] calcNormalOfTriangle(float[,] heightsData, int size, float girdSize)
    {
        Vector3[] array = new Vector3[(LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() - 1) * (LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1) * 2];
        Vector3 vector = default(Vector3);
        Vector3 vector2 = default(Vector3);
        Vector3 vector3 = default(Vector3);
        Vector3 vector4 = default(Vector3);
        float[] array2 = new float[LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() * LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight()];
        float num = 65536f;
        int num2 = 0;
        for (int i = 0; i < LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight(); i++)
        {
            for (int j = 0; j < LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(); j++)
            {
                ushort num3 = (ushort)Mathf.Clamp(Mathf.RoundToInt(heightsData[i, j] * num), 0, 65535);
                array2[num2] = (float)num3 * 1f / 32766f * LayaTerrainExporter.m_terrain.get_terrainData().get_size().y * 0.5f;
                num2++;
            }
        }
        int heightmapWidth = LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth();
        int heightmapHeight = LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight();
        int num4 = 0;
        Matrix4x4 matrix4x = default(Matrix4x4);
        matrix4x.SetTRS(Vector3.get_zero(), Quaternion.AngleAxis(180f, Vector3.get_up()), Vector3.get_one());
        Matrix4x4 matrix4x2 = default(Matrix4x4);
        matrix4x2.SetTRS(new Vector3(0f, 0f, LayaTerrainExporter.m_terrain.get_terrainData().get_size().y), Quaternion.get_identity(), Vector3.get_one());
        Matrix4x4 matrix4x3 = matrix4x2 * matrix4x;
        for (int k = 0; k < heightmapHeight - 1; k++)
        {
            for (int l = 0; l < heightmapWidth - 1; l++)
            {
                vector.x = (float)l * girdSize;
                vector.y = array2[(k + 1) * heightmapWidth + l];
                vector.z = (float)(k + 1) * girdSize;
                if (LayaTerrainExporter.cameraCoordinateInverse)
                {
                    vector = matrix4x3.MultiplyPoint(vector);
                }
                vector2.x = (float)(l + 1) * girdSize;
                vector2.y = array2[(k + 1) * heightmapWidth + l + 1];
                vector2.z = (float)(k + 1) * girdSize;
                if (LayaTerrainExporter.cameraCoordinateInverse)
                {
                    vector2 = matrix4x3.MultiplyPoint(vector2);
                }
                vector3.x = (float)l * girdSize;
                vector3.y = array2[k * heightmapWidth + l];
                vector3.z = (float)k * girdSize;
                if (LayaTerrainExporter.cameraCoordinateInverse)
                {
                    vector3 = matrix4x3.MultiplyPoint(vector3);
                }
                vector4.x = (float)(l + 1) * girdSize;
                vector4.y = array2[k * heightmapWidth + l + 1];
                vector4.z = (float)k * girdSize;
                if (LayaTerrainExporter.cameraCoordinateInverse)
                {
                    vector4 = matrix4x3.MultiplyPoint(vector4);
                }
                Vector3 vector5 = Vector3.Cross(vector - vector3, vector4 - vector3);
                vector5.Normalize();
                array[num4] = vector5;
                num4++;
                Vector3 vector6 = Vector3.Cross(vector4 - vector2, vector - vector2);
                vector6.Normalize();
                array[num4] = vector6;
                num4++;
            }
        }
        return array;
    }

    private static Vector3 calcVertextNorml1(int x, int z, Vector3[] normalTriangle, int terrainXNum, int terrainZNum)
    {
        int num = z - 1;
        int num2 = x - 1;
        int[] array = new int[]
        {
            (num * terrainXNum + num2) * 2 + 1,
            (z * terrainXNum + num2) * 2,
            (z * terrainXNum + num2) * 2 + 1,
            (z * terrainXNum + x) * 2,
            (num * terrainXNum + x) * 2 + 1,
            (num * terrainXNum + x) * 2
        };
        if (num < 0)
        {
            array[0] = (array[4] = (array[5] = -1));
        }
        if (z >= terrainZNum)
        {
            array[1] = -1;
            array[2] = -1;
            array[3] = -1;
        }
        if (num2 < 0)
        {
            array[0] = (array[1] = (array[2] = -1));
        }
        if (x >= terrainXNum)
        {
            array[3] = -1;
            array[4] = -1;
            array[5] = -1;
        }
        float num3 = 0f;
        float num4 = 0f;
        float num5 = 0f;
        float num6 = 0f;
        for (int i = 0; i < array.Length; i++)
        {
            int num7 = array[i];
            if (array[i] >= 0)
            {
                num3 += normalTriangle[num7].x;
                num4 += normalTriangle[num7].y;
                num5 += normalTriangle[num7].z;
                num6 += 1f;
            }
        }
        Vector3 result = new Vector3(num3 / num6, num4 / num6, num5 / num6);
        result.Normalize();
        return result;
    }

    private static Texture2D ExportNormal(Vector3[] normalTriangle)
    {
        Color[] array = new Color[LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() * LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight()];
        int num = 0;
        for (int i = LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1; i >= 0; i--)
        {
            for (int j = 0; j < LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(); j++)
            {
                Vector3 vector = LayaTerrainExporter.calcVertextNorml1(j, i, normalTriangle, LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth() - 1, LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight() - 1);
                vector.x = (vector.x + 1f) * 0.5f;
                vector.y = (vector.y + 1f) * 0.5f;
                vector.z = (vector.z + 1f) * 0.5f;
                array[num] = new Color(vector.x, vector.y, vector.z, 1f);
                num++;
            }
        }
        Texture2D texture2D = new Texture2D(LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapWidth(), LayaTerrainExporter.m_terrain.get_terrainData().get_heightmapHeight(), 4, false);
        texture2D.SetPixels(array);
        texture2D.Apply();
        texture2D.set_name(LayaTerrainExporter.m_terrain.get_name().ToLower() + "_normalMap");
        File.WriteAllBytes(LayaTerrainExporter.m_saveLocation + "/" + texture2D.get_name() + ".png", texture2D.EncodeToPNG());
        return texture2D;
    }

    public static void saveData(JSONObject node)
    {
        string value = node.Print(true);
        StreamWriter expr_37 = new StreamWriter(new FileStream(LayaTerrainExporter.m_saveLocation + "/" + LayaTerrainExporter.m_terrain.get_name().ToLower() + ".lt", FileMode.Create, FileAccess.Write));
        expr_37.Write(value);
        expr_37.Close();
    }
}
