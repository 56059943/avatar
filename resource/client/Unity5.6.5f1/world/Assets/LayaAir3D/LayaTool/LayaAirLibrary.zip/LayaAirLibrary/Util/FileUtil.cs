using System;
using System.IO;
using System.Text;

namespace Util
{
    public class FileUtil
    {
        public static FileStream saveFile(string fileName, JSONObject node = null)
        {
            string directoryName = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(directoryName))
            {
                Directory.CreateDirectory(directoryName);
            }
            FileStream fileStream = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            if (node == null)
            {
                return fileStream;
            }
            StreamWriter arg_32_0 = new StreamWriter(fileStream);
            string value = node.Print(true);
            arg_32_0.Write(value);
            arg_32_0.Close();
            return fileStream;
        }

        public static string getRelativePath(string path1, string path2)
        {
            string text = "";
            string[] array = path1.Split(new char[]
            {
                '/'
            });
            string[] array2 = path2.Split(new char[]
            {
                '/'
            });
            int num = 0;
            int num2 = 0;
            while (num2 < array.Length - 1 && !(array[num2] != array2[num2]))
            {
                num++;
                num2++;
            }
            for (int i = 0; i < array.Length - num - 1; i++)
            {
                text += "../";
            }
            for (int j = num; j < array2.Length; j++)
            {
                text += array2[j];
                if (j < array2.Length - 1)
                {
                    text += "/";
                }
            }
            return text;
        }

        public static void WriteData(FileStream fs, params int[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params long[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params byte[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte value = datas[i];
                fs.WriteByte(value);
            }
        }

        public static void WriteData(FileStream fs, params ushort[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params short[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params uint[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params sbyte[] datas)
        {
            BinaryWriter binaryWriter = new BinaryWriter(fs);
            for (int i = 0; i < datas.Length; i++)
            {
                sbyte value = datas[i];
                binaryWriter.Write(value);
            }
        }

        public static void WriteData(FileStream fs, params float[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params double[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, params bool[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {
                byte[] bytes = BitConverter.GetBytes(datas[i]);
                fs.Write(bytes, 0, bytes.Length);
            }
        }

        public static void WriteData(FileStream fs, string data)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(data);
            short num = (short)bytes.Length;
            FileUtil.WriteData(fs, new short[]
            {
                num
            });
            fs.Write(bytes, 0, bytes.Length);
        }
    }
}
